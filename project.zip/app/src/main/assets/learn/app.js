(function(){
'use strict';
var D=window.D||{};['lessons','notes','problems','errors','mcq','shortcuts','glossary','typing'].forEach(function(k){D[k]=D[k]||[]});
var $=function(s,r){return (r||document).querySelector(s)};
var main=$('#main');
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function inl(s){return esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>')}
function hsh(s){var h=5381,i;for(i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return 'q'+(h>>>0).toString(36)}
function shuffle(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t}return a}
/* ---------- storage ---------- */
var P={done:{},quiz:{},typing:{},wrong:{},prob:{},fs:16};
try{var raw=localStorage.getItem('learncs_v1');if(raw)P=Object.assign(P,JSON.parse(raw))}catch(e){}
function save(){try{localStorage.setItem('learncs_v1',JSON.stringify(P))}catch(e){}}
function applyFs(){document.documentElement.style.setProperty('--fs',P.fs+'px')}
applyFs();
/* ---------- bridge ---------- */
var B=window.AndroidLearn||null;
function toast(m){var t=document.createElement('div');t.className='toast';t.textContent=m;document.body.appendChild(t);setTimeout(function(){t.remove()},1800)}
function copy(t){if(B&&B.copy){B.copy(t);toast('Copy ho gaya');return}try{navigator.clipboard.writeText(t);toast('Copy ho gaya')}catch(e){toast('Copy nahi hua')}}
var PLAY={py:'py',c:'c',java:'java',js:'js',html:'web'};
function openCode(lang,code,name){if(B&&B.openCode){B.openCode(PLAY[lang]||'py',code,name||'')}else{toast('Playground sirf app me khulta hai')}}
/* ---------- highlight ---------- */
var KW={py:'False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case',
c:'auto break case const continue default do else enum extern for goto if inline register return sizeof static struct switch typedef union volatile while #include #define #ifdef #ifndef #endif #if #else',
java:'abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while var record true false null',
js:'async await break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new of return static super switch this throw try typeof var void while with yield true false null undefined',
sql:'SELECT FROM WHERE INSERT INTO VALUES UPDATE SET DELETE CREATE TABLE DROP ALTER ADD PRIMARY KEY FOREIGN REFERENCES NOT NULL UNIQUE DEFAULT CHECK AND OR IN LIKE BETWEEN ORDER BY GROUP HAVING LIMIT JOIN INNER LEFT RIGHT FULL OUTER ON AS DISTINCT COUNT SUM AVG MIN MAX ASC DESC UNION CASE WHEN THEN ELSE END IS EXISTS DATABASE INDEX VIEW AUTO_INCREMENT select from where insert into values update set delete create table drop alter add primary key foreign references not null unique default check and or in like between order by group having limit join inner left right full outer on as distinct count sum avg min max asc desc union case when then else end is exists',
css:'',html:'',sh:'',text:''};
var TY={py:'int float str bool list dict set tuple print input len range type open self object Exception',c:'int float double char long short unsigned signed void FILE size_t NULL printf scanf malloc free',java:'String Integer Double Boolean System out println Math List ArrayList Map HashMap Scanner Object Exception',js:'console document window Math Array Object String Number JSON Promise'};
function hl(code,lang){
 var kw={},ty={};(KW[lang]||'').split(' ').forEach(function(w){if(w)kw[w]=1});(TY[lang]||'').split(' ').forEach(function(w){if(w)ty[w]=1});
 var re;
 if(lang==='html')re=/(<!--[\s\S]*?-->)|(<\/?[a-zA-Z][\w-]*)|("[^"]*"|'[^']*')|(\/?>)|([\w-]+)(?==)/g;
 else if(lang==='css')re=/(\/\*[\s\S]*?\*\/)|("[^"]*"|'[^']*')|(#[0-9a-fA-F]{3,8}\b|\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s)?)|([.#]?[a-zA-Z-]+)(?=\s*[:{,])/g;
 else if(lang==='sh'||lang==='text')return esc(code);
 else{var cm=lang==='py'?'#[^\\n]*':lang==='sql'?'--[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/':'\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/';
  if(lang==='c')cm='\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/';
  re=new RegExp('('+cm+')|("""[\\s\\S]*?"""|\'\'\'[\\s\\S]*?\'\'\'|"(?:\\\\.|[^"\\\\\\n])*"|\'(?:\\\\.|[^\'\\\\\\n])*\'|`[^`]*`)|(\\b\\d+(?:\\.\\d+)?\\b)|(#?[A-Za-z_][A-Za-z0-9_]*)','g');}
 var out='',last=0,m;
 while((m=re.exec(code))){out+=esc(code.slice(last,m.index));last=re.lastIndex;var t=m[0],c;
  if(lang==='html'){c=m[1]?'c1':m[2]?'k2':m[3]?'s1':m[4]?'k2':'n1';}
  else if(lang==='css'){c=m[1]?'c1':m[2]?'s1':m[3]?'n1':'k2';}
  else{if(m[1])c='c1';else if(m[2])c='s1';else if(m[3])c='n1';else{var w=m[4];var nx=code.charAt(last);c=kw[w]?'k1':ty[w]?'k2':(nx==='('?'f1':'')}}
  out+=c?'<span class="'+c+'">'+esc(t)+'</span>':esc(t)}
 return out+esc(code.slice(last))}
/* ---------- blocks renderer ---------- */
var CALL={tip:'💡 Tip',warn:'⚠️ Dhyan',note:'📝 Note',yaad:'⭐ Yaad rakho'};
var cbStore=[];
function codeBlock(b){var id=cbStore.length;cbStore.push(b);var lg={py:'Python',c:'C',java:'Java',js:'JavaScript',html:'HTML',css:'CSS',sql:'SQL',sh:'Shell',text:'Text'}[b.lang]||b.lang;
 var h='<div class="cb"><div class="hd"><span class="tt">'+esc(b.title||'Code')+'</span><span class="lg">'+lg+'</span></div><pre>'+hl(b.code,b.lang)+'</pre>';
 if(b.stdin)h+='<div class="io in"><span class="l">Input (Playground me Input button se do)</span>'+esc(b.stdin)+'</div>';
 if(b.out!=null&&b.out!=='')h+='<div class="io '+(b.isErr?'er':'out')+'"><span class="l">'+(b.isErr?'Error aayega':'Output')+'</span>'+esc(b.out)+'</div>';
 h+='<div class="acts">';if(PLAY[b.lang])h+='<button class="btn s" data-a="run" data-i="'+id+'">▶ Playground me kholo</button>';
 h+='<button class="btn s g" data-a="cp" data-i="'+id+'">📋 Copy</button></div></div>';return h}
function qBlock(b,k){var h='<div class="q" data-qa="'+b.a+'"><div class="qq">'+inl(b.q)+'</div>';b.o.forEach(function(o,i){h+='<button class="opt" data-a="mq" data-i="'+i+'">'+'ABCD'.charAt(i)+'. '+inl(o)+'</button>'});return h+'<div class="ex" hidden>'+inl(b.e)+'</div></div>'}
function blocks(bl){var h='';bl.forEach(function(b){switch(b.t){
 case 'h':h+='<h3>'+inl(b.x)+'</h3>';break;
 case 'p':h+='<p>'+inl(b.x)+'</p>';break;
 case 'ul':h+='<ul>'+b.items.map(function(x){return '<li>'+inl(x)+'</li>'}).join('')+'</ul>';break;
 case 'ol':h+='<ol>'+b.items.map(function(x){return '<li>'+inl(x)+'</li>'}).join('')+'</ol>';break;
 case 'call':h+='<div class="call '+b.k+'"><span class="k">'+CALL[b.k]+':</span>'+inl(b.x)+'</div>';break;
 case 'code':h+=codeBlock(b);break;
 case 'table':h+='<table class="t"><tr>'+b.head.map(function(x){return '<th>'+inl(x)+'</th>'}).join('')+'</tr>'+b.rows.map(function(r){return '<tr>'+r.map(function(x){return '<td>'+inl(x)+'</td>'}).join('')+'</tr>'}).join('')+'</table>';break;
 case 'q':h+=qBlock(b);break}});return h}
/* ---------- chrome ---------- */
function setTop(t,s){$('#t1').textContent=t;$('#t2').textContent=s||'';}
function go(h){location.hash=h}
$('#bk').onclick=function(){var h=location.hash;if(!h||h==='#/'||h==='#'){if(B&&B.close)B.close();else history.back()}else history.back()};
$('#fz').onclick=function(){P.fs=P.fs>=22?14:P.fs+2;applyFs();save();toast('Text size: '+P.fs)};
window.csBack=function(){var h=location.hash;if(!h||h==='#/'||h==='#')return false;history.back();return true};
/* ---------- tracks ---------- */
var TR=[{id:'py',n:'Python',ic:'🐍',s:'Zero se advanced tak'},{id:'c',n:'C Language',ic:'🔧',s:'Basics se pointers tak'},{id:'java',n:'Java',ic:'☕',s:'OOP aur collections'},{id:'web',n:'HTML / CSS / JS',ic:'🌐',s:'Website banana seekho'},{id:'sql',n:'SQL / Database',ic:'🗄️',s:'Queries aur design'}];
function trackOf(id){return id.split('-')[0]}
function lessonsOf(t){return D.lessons.filter(function(l){return trackOf(l.id)===t}).sort(function(a,b){return a.id<b.id?-1:a.id>b.id?1:0})}
function lvBadge(l){var c=/begin/i.test(l)?'b':/inter/i.test(l)?'i':'a';return '<span class="badge '+c+'">'+esc(l)+'</span>'}
/* ---------- views ---------- */
var V={};
V.home=function(){setTop('Learn CS','Computer Science seekho, practice karo');
 var done=Object.keys(P.done).length,tot=D.lessons.length,qs=0,qb=0;Object.keys(P.quiz).forEach(function(k){qs+=P.quiz[k].n||0;qb=Math.max(qb,P.quiz[k].best||0)});
 var wpm=0;Object.keys(P.typing).forEach(function(k){wpm=Math.max(wpm,P.typing[k].wpm||0)});
 var h='<input type="search" id="gs" placeholder="🔍 Sab kuch search karo (lesson, shortcut, term...)" autocomplete="off">';
 h+='<div class="stat" style="margin-top:12px"><div><b>'+done+'/'+tot+'</b><span>Lessons done</span></div><div><b>'+qb+'%</b><span>Best quiz</span></div><div><b>'+wpm+'</b><span>Best WPM</span></div></div>';
 h+='<h2 class="sec">Programming seekho</h2><div class="grid">';
 TR.forEach(function(t){var ls=lessonsOf(t.id),d=ls.filter(function(l){return P.done[l.id]}).length;h+='<button class="tile" data-go="#/lessons/'+t.id+'"><span class="ic">'+t.ic+'</span><span class="nm">'+t.n+'</span><span class="sb">'+ls.length+' lessons · '+d+' done</span></button>'});
 h+='<button class="tile" data-go="#/practice"><span class="ic">💡</span><span class="nm">Practice Sawal</span><span class="sb">'+D.problems.length+' coding sawal + solution</span></button></div>';
 h+='<h2 class="sec">Exam ki taiyari</h2><div class="grid">';
 h+='<button class="tile" data-go="#/quiz"><span class="ic">🧠</span><span class="nm">MCQ Quiz</span><span class="sb">'+D.mcq.length+' sawal</span></button>';
 h+='<button class="tile" data-go="#/shortcuts"><span class="ic">⌨️</span><span class="nm">Shortcut Keys</span><span class="sb">'+D.shortcuts.length+' shortcuts + test</span></button>';
 h+='<button class="tile" data-go="#/glossary"><span class="ic">📖</span><span class="nm">Glossary</span><span class="sb">'+D.glossary.length+' terms + flashcards</span></button>';
 h+='<button class="tile" data-go="#/notes"><span class="ic">📝</span><span class="nm">Notes / Cheat Sheet</span><span class="sb">'+D.notes.length+' quick notes</span></button></div>';
 h+='<h2 class="sec">Tools aur practice</h2><div class="grid">';
 h+='<button class="tile" data-go="#/errors"><span class="ic">🐞</span><span class="nm">Error Guide</span><span class="sb">'+D.errors.length+' errors, kaise theek karein</span></button>';
 h+='<button class="tile" data-go="#/gates"><span class="ic">🔌</span><span class="nm">Logic Gates & Digital</span><span class="sb">Gates, Boolean, number system</span></button>';
 h+='<button class="tile" data-go="#/typing"><span class="ic">⌨</span><span class="nm">Typing Practice</span><span class="sb">English, Hindi, Code</span></button>';
 h+='<button class="tile" data-go="#/flow"><span class="ic">🧩</span><span class="nm">Flowchart / Algorithm</span><span class="sb">Symbols, examples, builder</span></button></div>';
 main.innerHTML=h;$('#gs').addEventListener('input',function(e){if(e.target.value.trim().length>=2)go('#/search/'+encodeURIComponent(e.target.value.trim()))})};
V.lessons=function(t){var tr=TR.filter(function(x){return x.id===t})[0]||TR[0];setTop(tr.n,'Lessons');var ls=lessonsOf(tr.id),d=ls.filter(function(l){return P.done[l.id]}).length;
 var h='<div class="mut">'+d+' / '+ls.length+' complete</div><div class="bar"><i style="width:'+(ls.length?d*100/ls.length:0)+'%"></i></div>';
 if(!ls.length)h+='<div class="empty">Abhi lessons add ho rahe hain.</div>';
 ls.forEach(function(l,i){h+='<button class="row" data-go="#/lesson/'+l.id+'"><span class="ic">'+(P.done[l.id]?'✅':(i+1))+'</span><span class="bd"><div class="nm">'+esc(l.title)+'</div><div class="sb">'+lvBadge(l.level)+' '+esc(l.min)+' min</div></span><span class="go">›</span></button>'});main.innerHTML=h};
function find(arr,id){for(var i=0;i<arr.length;i++)if(arr[i].id===id)return i;return -1}
V.lesson=function(id){var i=find(D.lessons,id);if(i<0){main.innerHTML='<div class="empty">Lesson nahi mila</div>';return}var l=D.lessons[i],t=trackOf(id),tr=TR.filter(function(x){return x.id===t})[0]||TR[0];setTop(l.title,tr.n+' · '+l.level+' · '+l.min+' min');
 cbStore=[];var ls=lessonsOf(t),k=find(ls,id);
 var h='<div class="lesson">'+blocks(l.blocks)+'</div>';
 h+='<button class="btn w '+(P.done[id]?'g':'ok')+'" data-a="done" data-id="'+id+'">'+(P.done[id]?'✅ Complete (hatane ke liye tap karo)':'Maine ye lesson padh liya ✔')+'</button>';
 h+='<div class="nav2">'+(k>0?'<button class="btn g" data-go="#/lesson/'+ls[k-1].id+'">‹ Pichla</button>':'')+(k<ls.length-1?'<button class="btn" data-go="#/lesson/'+ls[k+1].id+'">Agla ›</button>':'')+'</div>';
 main.innerHTML=h;window.scrollTo(0,0)};
/* ---- quiz ---- */
var QZ=null;
V.quiz=function(){setTop('MCQ Quiz',D.mcq.length+' sawal');var cnt={};D.mcq.forEach(function(q){cnt[q.t]=(cnt[q.t]||0)+1});var tops=Object.keys(cnt).sort();
 var nw=Object.keys(P.wrong).filter(function(k){return D.mcq.some(function(q){return hsh(q.q)===k})}).length;
 var h='<div class="card"><b>Quiz setup</b><div class="mut" style="margin:4px 0 10px">Topic chuno, kitne sawal chahiye batao, aur shuru karo.</div>';
 h+='<div class="mut">Sawal ki sankhya</div><div class="chips" id="qn">'+[10,20,30,50,0].map(function(n,i){return '<span class="chip'+(i==0?' on':'')+'" data-n="'+n+'">'+(n||'Sab')+'</span>'}).join('')+'</div>';
 h+='<div class="mut">Topic</div><div class="chips" id="qt"><span class="chip on" data-t="*">Sab mix ('+D.mcq.length+')</span>'+(nw?'<span class="chip" data-t="!w">Galat jawab revise ('+nw+')</span>':'')+tops.map(function(t){return '<span class="chip" data-t="'+esc(t)+'">'+esc(t)+' ('+cnt[t]+')</span>'}).join('')+'</div>';
 h+='<button class="btn w" data-a="qstart" style="margin-top:8px">Quiz shuru karo ▶</button></div>';
 var hist=Object.keys(P.quiz);if(hist.length){h+='<h2 class="sec">Tumhara record</h2>';hist.forEach(function(k){var r=P.quiz[k];h+='<div class="row" style="cursor:default"><span class="bd"><div class="nm">'+esc(k==='*'?'Sab mix':k)+'</div><div class="sb">Best '+r.best+'% · '+r.n+' sawal solve kiye</div></span></div>'})}
 main.innerHTML=h;var sel={n:10,t:'*'};
 main.querySelectorAll('#qn .chip').forEach(function(c){c.onclick=function(){main.querySelectorAll('#qn .chip').forEach(function(x){x.classList.remove('on')});c.classList.add('on');sel.n=+c.dataset.n}});
 main.querySelectorAll('#qt .chip').forEach(function(c){c.onclick=function(){main.querySelectorAll('#qt .chip').forEach(function(x){x.classList.remove('on')});c.classList.add('on');sel.t=c.dataset.t}});
 V._qsel=sel};
function qStart(pool,topic,n){if(!pool.length){toast('Is topic me sawal nahi hain');return}pool=shuffle(pool);if(n&&n<pool.length)pool=pool.slice(0,n);
 QZ={pool:pool,i:0,sc:0,wrong:[],topic:topic,ans:null};go('#/quizrun')}
V.quizrun=function(){if(!QZ){go('#/quiz');return}setTop('Quiz',QZ.topic==='*'?'Sab mix':QZ.topic==='!w'?'Galat revise':QZ.topic);
 if(QZ.i>=QZ.pool.length){var pc=Math.round(QZ.sc*100/QZ.pool.length);var key=QZ.topic==='!w'?'Revise':QZ.topic;var r=P.quiz[key]||{best:0,n:0};r.best=Math.max(r.best,pc);r.n+=QZ.pool.length;P.quiz[key]=r;save();
  var h='<div class="card" style="text-align:center"><div style="font-size:42px">'+(pc>=80?'🏆':pc>=50?'👍':'📚')+'</div><div style="font-size:30px;font-weight:800">'+QZ.sc+' / '+QZ.pool.length+'</div><div class="mut">'+pc+'% sahi</div></div>';
  if(QZ.wrong.length){h+='<h2 class="sec">Galat jawab ('+QZ.wrong.length+')</h2>';QZ.wrong.forEach(function(w){h+='<div class="q"><div class="qq">'+inl(w.q)+'</div><div class="opt no">Tumhara: '+inl(w.o[w.mine])+'</div><div class="opt ok">Sahi: '+inl(w.o[w.a])+'</div><div class="ex">'+inl(w.e)+'</div></div>'})}
  h+='<div class="nav2"><button class="btn g" data-go="#/quiz">Naya quiz</button>'+(QZ.wrong.length?'<button class="btn" data-a="qretry">Galat dobara</button>':'')+'</div>';main.innerHTML=h;return}
 var q=QZ.pool[QZ.i];var h='<div class="mut">Sawal '+(QZ.i+1)+' / '+QZ.pool.length+' · Score '+QZ.sc+'</div><div class="bar"><i style="width:'+(QZ.i*100/QZ.pool.length)+'%"></i></div>';
 h+='<div class="q" data-qa="'+q.a+'"><div class="qq">'+inl(q.q)+'</div><div class="chips" style="margin:0 0 8px"><span class="badge">'+esc(q.t)+'</span></div>';
 q.o.forEach(function(o,i){h+='<button class="opt" data-a="qa" data-i="'+i+'">'+'ABCD'.charAt(i)+'. '+inl(o)+'</button>'});
 h+='<div class="ex" hidden>'+inl(q.e)+'</div></div><div class="nav2"><button class="btn" id="qnext" hidden data-a="qnext">'+(QZ.i+1>=QZ.pool.length?'Result dekho':'Agla sawal ›')+'</button></div>';main.innerHTML=h;window.scrollTo(0,0)};
/* ---- shortcuts ---- */
var SCST={app:'*',q:'',test:null};
V.shortcuts=function(){setTop('Shortcut Keys',D.shortcuts.length+' shortcuts');var apps=[];D.shortcuts.forEach(function(s){if(apps.indexOf(s.a)<0)apps.push(s.a)});
 var h='<input type="search" id="sq" placeholder="🔍 Search: copy, save, bold..." value="'+esc(SCST.q)+'"><div class="chips" style="margin-top:10px"><span class="chip'+(SCST.app==='*'?' on':'')+'" data-app="*">Sab</span>'+apps.map(function(a){return '<span class="chip'+(SCST.app===a?' on':'')+'" data-app="'+esc(a)+'">'+esc(a)+'</span>'}).join('')+'</div>';
 h+='<button class="btn w g" data-a="sctest" style="margin-bottom:12px">🎯 Apni jaankari test karo ('+(SCST.app==='*'?'sab':esc(SCST.app))+')</button><div id="sl"></div>';main.innerHTML=h;
 function list(){var q=SCST.q.toLowerCase(),r=D.shortcuts.filter(function(s){return (SCST.app==='*'||s.a===SCST.app)&&(!q||(s.k+' '+s.w+' '+s.a).toLowerCase().indexOf(q)>=0)});
  var o='<div class="mut" style="margin-bottom:8px">'+r.length+' mile</div>';if(!r.length)o+='<div class="empty">Kuch nahi mila</div>';
  r.slice(0,300).forEach(function(s){o+='<div class="row" style="cursor:default"><span class="bd"><div class="nm">'+kcaps(s.k)+'</div><div class="sb">'+esc(s.w)+(SCST.app==='*'?' · '+esc(s.a):'')+'</div></span></div>'});if(r.length>300)o+='<div class="mut">Pehle 300 dikhaye, search se chhota karo.</div>';$('#sl').innerHTML=o}
 list();$('#sq').addEventListener('input',function(e){SCST.q=e.target.value;list()});
 main.querySelectorAll('[data-app]').forEach(function(c){c.onclick=function(){SCST.app=c.dataset.app;V.shortcuts()}})};
function kcaps(k){return k.split(' / ').map(function(alt){return alt.split(' + ').map(function(x){return '<span class="kcap">'+esc(x.trim())+'</span>'}).join('+')}).join(' <span class="mut">ya</span> ')}
V.sctest=function(){var pool=D.shortcuts.filter(function(s){return SCST.app==='*'||s.a===SCST.app});if(pool.length<4){go('#/shortcuts');return}
 setTop('Shortcut Test',SCST.app==='*'?'Sab apps':SCST.app);if(!SCST.test||SCST.test.i>=SCST.test.n)SCST.test={i:0,n:10,sc:0,qs:shuffle(pool).slice(0,10)};
 var T=SCST.test;if(T.i>=T.n){main.innerHTML='<div class="card" style="text-align:center"><div style="font-size:42px">'+(T.sc>=8?'🏆':T.sc>=5?'👍':'📚')+'</div><div style="font-size:30px;font-weight:800">'+T.sc+' / '+T.n+'</div></div><div class="nav2"><button class="btn" data-a="sctest2">Dobara</button><button class="btn g" data-go="#/shortcuts">Wapas</button></div>';return}
 var s=T.qs[T.i],wr=shuffle(pool.filter(function(x){return x.k!==s.k&&x.a===s.a})),ops=shuffle([s].concat(wr.slice(0,3)));if(ops.length<4)ops=shuffle([s].concat(shuffle(pool.filter(function(x){return x.k!==s.k})).slice(0,3)));
 T.cur=ops;var h='<div class="mut">Sawal '+(T.i+1)+' / '+T.n+' · Score '+T.sc+'</div><div class="bar"><i style="width:'+(T.i*10)+'%"></i></div><div class="q" data-qa="'+ops.indexOf(s)+'"><div class="qq">'+esc(s.a)+' me <b>'+esc(s.w)+'</b> ka shortcut kaunsa hai?</div>';
 ops.forEach(function(o,i){h+='<button class="opt" data-a="sa" data-i="'+i+'">'+kcaps(o.k)+'</button>'});h+='</div><div class="nav2"><button class="btn" id="qnext" hidden data-a="snext">Agla ›</button></div>';main.innerHTML=h};
/* ---- glossary ---- */
var GST={q:'',c:'*',fc:false,i:0,show:false};
V.glossary=function(){setTop('Glossary',D.glossary.length+' terms');var cats=[];D.glossary.forEach(function(g){if(cats.indexOf(g.c)<0)cats.push(g.c)});cats.sort();
 var h='<input type="search" id="gq" placeholder="🔍 Term search karo" value="'+esc(GST.q)+'"><div class="chips" style="margin-top:10px"><span class="chip'+(GST.c==='*'?' on':'')+'" data-c="*">Sab</span>'+cats.map(function(c){return '<span class="chip'+(GST.c===c?' on':'')+'" data-c="'+esc(c)+'">'+esc(c)+'</span>'}).join('')+'</div>';
 h+='<div class="flex" style="margin-bottom:12px"><button class="btn s '+(GST.fc?'':'g')+'" data-a="gmode" data-v="0">📖 List</button><button class="btn s '+(GST.fc?'g':'')+'" data-a="gmode" data-v="1" style="'+(GST.fc?'background:var(--pr);color:#fff':'')+'">🃏 Flashcards</button></div><div id="gl"></div>';main.innerHTML=h;
 function filt(){var q=GST.q.toLowerCase();return D.glossary.filter(function(g){return (GST.c==='*'||g.c===GST.c)&&(!q||(g.t+' '+g.f+' '+g.m).toLowerCase().indexOf(q)>=0)}).sort(function(a,b){return a.t.toLowerCase()<b.t.toLowerCase()?-1:1})}
 function list(){var r=filt();var o='';if(GST.fc){if(!r.length){o='<div class="empty">Kuch nahi mila</div>'}else{var g=r[GST.i%r.length];o='<div class="mut">Card '+(GST.i%r.length+1)+' / '+r.length+'</div><button class="card" id="fcard" style="width:100%;text-align:center;min-height:170px;display:flex;flex-direction:column;align-items:center;justify-content:center"><div style="font-size:26px;font-weight:800">'+esc(g.t)+'</div>'+(GST.show?'<div class="mut" style="margin-top:8px">'+esc(g.f)+'</div><div style="margin-top:10px">'+esc(g.m)+'</div>':'<div class="mut" style="margin-top:10px">Matlab dekhne ke liye tap karo</div>')+'</button><div class="nav2"><button class="btn g" data-a="gprev">‹ Pichla</button><button class="btn" data-a="gnext">Agla ›</button></div>'}}
  else{o='<div class="mut" style="margin-bottom:8px">'+r.length+' terms</div>';if(!r.length)o+='<div class="empty">Kuch nahi mila</div>';r.slice(0,250).forEach(function(g){o+='<div class="card"><div class="flex"><b style="font-size:17px">'+esc(g.t)+'</b><span class="sp"></span><span class="badge">'+esc(g.c)+'</span></div>'+(g.f?'<div class="mut" style="margin:2px 0 6px">'+esc(g.f)+'</div>':'')+'<div>'+esc(g.m)+'</div></div>'});if(r.length>250)o+='<div class="mut">Pehle 250 dikhaye, search karo.</div>'}
  $('#gl').innerHTML=o;var fc=$('#fcard');if(fc)fc.onclick=function(){GST.show=!GST.show;list()}}
 V._glist=list;list();$('#gq').addEventListener('input',function(e){GST.q=e.target.value;GST.i=0;list()});
 main.querySelectorAll('[data-c]').forEach(function(c){c.onclick=function(){GST.c=c.dataset.c;GST.i=0;V.glossary()}});V._gfilt=filt};
/* ---- practice ---- */
var PRS={lang:'*',lv:'*'};
V.practice=function(){setTop('Practice Sawal',D.problems.length+' coding sawal');var h='<div class="chips">'+[['*','Sab'],['py','Python'],['c','C'],['java','Java']].map(function(x){return '<span class="chip'+(PRS.lang===x[0]?' on':'')+'" data-l="'+x[0]+'">'+x[1]+'</span>'}).join('')+'</div><div class="chips">'+['*','Easy','Medium','Hard'].map(function(x){return '<span class="chip'+(PRS.lv===x?' on':'')+'" data-v="'+x+'">'+(x==='*'?'Sab level':x)+'</span>'}).join('')+'</div>';
 var r=D.problems.filter(function(p){return (PRS.lang==='*'||p.lang===PRS.lang)&&(PRS.lv==='*'||p.level===PRS.lv)});var d=r.filter(function(p){return P.prob[p.id]}).length;
 h+='<div class="mut">'+d+' / '+r.length+' solve kiye</div><div class="bar"><i style="width:'+(r.length?d*100/r.length:0)+'%"></i></div>';
 if(!r.length)h+='<div class="empty">Is filter me sawal nahi hain.</div>';
 r.forEach(function(p,i){h+='<button class="row" data-go="#/problem/'+p.id+'"><span class="ic">'+(P.prob[p.id]?'✅':(i+1))+'</span><span class="bd"><div class="nm">'+esc(p.title)+'</div><div class="sb">'+lvBadge(p.level==='Easy'?'Beginner':p.level==='Medium'?'Intermediate':'Advanced').replace(/Beginner|Intermediate|Advanced/,p.level)+' <span class="badge">'+({py:'Python',c:'C',java:'Java'}[p.lang]||p.lang)+'</span></div></span><span class="go">›</span></button>'});
 main.innerHTML=h;main.querySelectorAll('[data-l]').forEach(function(c){c.onclick=function(){PRS.lang=c.dataset.l;V.practice()}});main.querySelectorAll('[data-v]').forEach(function(c){c.onclick=function(){PRS.lv=c.dataset.v;V.practice()}})};
V.problem=function(id){var i=find(D.problems,id);if(i<0){main.innerHTML='<div class="empty">Sawal nahi mila</div>';return}var p=D.problems[i];setTop(p.title,p.level+' · '+({py:'Python',c:'C',java:'Java'}[p.lang]||p.lang));cbStore=[];
 var sol=[],stmt=[],seenCode=false;p.blocks.forEach(function(b){if(b.t==='code'&&!seenCode){seenCode=true;sol.push(b)}else if(seenCode)sol.push(b);else stmt.push(b)});
 var h='<div class="lesson">'+blocks(stmt)+'</div>';var starter='# '+p.title+'\n# Yaha apna code likho\n';if(p.lang==='c')starter='#include <stdio.h>\n\nint main() {\n    // '+p.title+'\n    return 0;\n}\n';if(p.lang==='java')starter='public class Main {\n    public static void main(String[] args) {\n        // '+p.title+'\n    }\n}\n';
 h+='<button class="btn w" data-a="try" data-lang="'+p.lang+'" data-id="'+p.id+'">✍️ Khud try karo (Playground)</button><button class="btn w g" id="shsol" style="margin-top:10px">👁 Solution dekho</button><div id="sol" hidden style="margin-top:14px"><div class="lesson">'+blocks(sol)+'</div></div>';
 h+='<button class="btn w '+(P.prob[id]?'g':'ok')+'" data-a="pdone" data-id="'+id+'" style="margin-top:12px">'+(P.prob[id]?'✅ Solve kiya (hatane ke liye tap)':'Maine solve kar liya ✔')+'</button>';
 main.innerHTML=h;$('#shsol').onclick=function(){var s=$('#sol');s.hidden=!s.hidden;this.textContent=s.hidden?'👁 Solution dekho':'🙈 Solution chhupao'};V._starter=starter};
/* ---- notes & errors ---- */
V.notes=function(){setTop('Notes / Cheat Sheet',D.notes.length+' notes');var groups={};D.notes.forEach(function(n){(groups[n.group]=groups[n.group]||[]).push(n)});var h='<input type="search" id="nq" placeholder="🔍 Notes search karo" autocomplete="off"><div id="nl"></div>';main.innerHTML=h;
 function list(q){q=(q||'').toLowerCase();var o='';Object.keys(groups).sort().forEach(function(g){var r=groups[g].filter(function(n){return !q||(n.title+' '+g).toLowerCase().indexOf(q)>=0});if(!r.length)return;o+='<h2 class="sec">'+esc(g)+'</h2>';r.forEach(function(n){o+='<button class="row" data-go="#/note/'+n.id+'"><span class="ic">📄</span><span class="bd"><div class="nm">'+esc(n.title)+'</div></span><span class="go">›</span></button>'})});$('#nl').innerHTML=o||'<div class="empty">Kuch nahi mila</div>'}
 list();$('#nq').addEventListener('input',function(e){list(e.target.value)})};
V.note=function(id){var i=find(D.notes,id);if(i<0){main.innerHTML='<div class="empty">Note nahi mila</div>';return}var n=D.notes[i];setTop(n.title,n.group);cbStore=[];main.innerHTML='<div class="lesson">'+blocks(n.blocks)+'</div>';window.scrollTo(0,0)};
var ERS={lang:'*'};
V.errors=function(){setTop('Error Guide',D.errors.length+' errors');var h='<div class="chips">'+[['*','Sab'],['py','Python'],['c','C'],['java','Java']].map(function(x){return '<span class="chip'+(ERS.lang===x[0]?' on':'')+'" data-l="'+x[0]+'">'+x[1]+'</span>'}).join('')+'</div>';
 D.errors.filter(function(e){return ERS.lang==='*'||e.lang===ERS.lang}).forEach(function(e){h+='<button class="row" data-go="#/error/'+e.id+'"><span class="ic">🐞</span><span class="bd"><div class="nm">'+esc(e.title)+'</div><div class="sb">'+({py:'Python',c:'C',java:'Java'}[e.lang]||e.lang)+'</div></span><span class="go">›</span></button>'});
 main.innerHTML=h;main.querySelectorAll('[data-l]').forEach(function(c){c.onclick=function(){ERS.lang=c.dataset.l;V.errors()}})};
V.error=function(id){var i=find(D.errors,id);if(i<0){main.innerHTML='<div class="empty">Nahi mila</div>';return}var n=D.errors[i];setTop(n.title,'Error Guide');cbStore=[];main.innerHTML='<div class="lesson">'+blocks(n.blocks)+'</div>';window.scrollTo(0,0)};
/* ---- search ---- */
V.search=function(q){q=decodeURIComponent(q||'');setTop('Search',q);var ql=q.toLowerCase(),o='';
 function txt(bl){return bl.map(function(b){return (b.x||'')+' '+(b.items||[]).join(' ')}).join(' ')}
 var sets=[['Lessons',D.lessons.filter(function(l){return (l.title+' '+txt(l.blocks)).toLowerCase().indexOf(ql)>=0}).slice(0,15),function(l){return '<button class="row" data-go="#/lesson/'+l.id+'"><span class="ic">📘</span><span class="bd"><div class="nm">'+esc(l.title)+'</div></span><span class="go">›</span></button>'}],
 ['Notes',D.notes.filter(function(l){return (l.title+' '+txt(l.blocks)).toLowerCase().indexOf(ql)>=0}).slice(0,10),function(l){return '<button class="row" data-go="#/note/'+l.id+'"><span class="ic">📄</span><span class="bd"><div class="nm">'+esc(l.title)+'</div></span><span class="go">›</span></button>'}],
 ['Practice',D.problems.filter(function(l){return (l.title+' '+txt(l.blocks)).toLowerCase().indexOf(ql)>=0}).slice(0,10),function(l){return '<button class="row" data-go="#/problem/'+l.id+'"><span class="ic">💡</span><span class="bd"><div class="nm">'+esc(l.title)+'</div></span><span class="go">›</span></button>'}],
 ['Errors',D.errors.filter(function(l){return (l.title+' '+txt(l.blocks)).toLowerCase().indexOf(ql)>=0}).slice(0,8),function(l){return '<button class="row" data-go="#/error/'+l.id+'"><span class="ic">🐞</span><span class="bd"><div class="nm">'+esc(l.title)+'</div></span><span class="go">›</span></button>'}],
 ['Glossary',D.glossary.filter(function(g){return (g.t+' '+g.f+' '+g.m).toLowerCase().indexOf(ql)>=0}).slice(0,12),function(g){return '<div class="card"><b>'+esc(g.t)+'</b> <span class="mut">'+esc(g.f)+'</span><div>'+esc(g.m)+'</div></div>'}],
 ['Shortcuts',D.shortcuts.filter(function(s){return (s.k+' '+s.w+' '+s.a).toLowerCase().indexOf(ql)>=0}).slice(0,12),function(s){return '<div class="row" style="cursor:default"><span class="bd"><div class="nm">'+kcaps(s.k)+'</div><div class="sb">'+esc(s.w)+' · '+esc(s.a)+'</div></span></div>'}],
 ['MCQ',D.mcq.filter(function(m){return (m.q+' '+m.o.join(' ')).toLowerCase().indexOf(ql)>=0}).slice(0,6),function(m){return '<div class="card"><div>'+inl(m.q)+'</div><div class="mut">Jawab: '+inl(m.o[m.a])+'</div></div>'}]];
 sets.forEach(function(s){if(s[1].length){o+='<h2 class="sec">'+s[0]+'</h2>'+s[1].map(s[2]).join('')}});main.innerHTML='<input type="search" id="gs2" value="'+esc(q)+'">'+(o||'<div class="empty">Kuch nahi mila. Doosra shabd try karo.</div>')+'<div style="height:1px"></div>';
 $('#gs2').addEventListener('change',function(e){var v=e.target.value.trim();if(v)location.replace('#/search/'+encodeURIComponent(v))})};
/* ---- typing ---- */
var TS={lang:'en',cur:null};
V.typing=function(){setTop('Typing Practice',D.typing.length+' passages');var h='<div class="chips">'+[['en','English'],['hi','हिंदी'],['code','Code']].map(function(x){return '<span class="chip'+(TS.lang===x[0]?' on':'')+'" data-l="'+x[0]+'">'+x[1]+'</span>'}).join('')+'</div>';
 var r=D.typing.filter(function(t){return t.l===TS.lang});if(!r.length)h+='<div class="empty">Is bhasha me abhi passages nahi hain.</div>';
 r.forEach(function(t,i){var k=t.l+':'+t.t,b=P.typing[k];h+='<button class="row" data-go="#/typetest/'+D.typing.indexOf(t)+'"><span class="ic">⌨</span><span class="bd"><div class="nm">'+esc(t.t)+'</div><div class="sb">'+esc(t.v)+' · '+t.x.length+' characters'+(b?' · Best '+b.wpm+' WPM / '+b.acc+'%':'')+'</div></span><span class="go">›</span></button>'});
 main.innerHTML=h;main.querySelectorAll('[data-l]').forEach(function(c){c.onclick=function(){TS.lang=c.dataset.l;V.typing()}})};
V.typetest=function(n){var t=D.typing[+n];if(!t){go('#/typing');return}setTop('Typing Test',t.t);var txt=t.x;
 var h='<div class="stat"><div><b id="tw">0</b><span>WPM</span></div><div><b id="ta">100%</b><span>Accuracy</span></div><div><b id="tt">0:00</b><span>Time</span></div></div><div class="tt-t" id="ttx">'+Array.prototype.map.call(txt,function(c){return '<span>'+esc(c)+'</span>'}).join('')+'</div>';
 h+='<textarea id="tin" rows="3" placeholder="Yaha type karo..." autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" style="font-family:inherit"></textarea><div class="nav2"><button class="btn g" data-a="treset" data-n="'+n+'">🔄 Dobara</button></div><div id="tres"></div>';main.innerHTML=h;
 var ta=$('#tin'),spans=main.querySelectorAll('#ttx span'),start=0,done=false,timer=null;
 function upd(){var v=ta.value,ok=0,i;for(i=0;i<spans.length;i++){var c=spans[i];if(i<v.length){var g=v.charAt(i)===txt.charAt(i);c.className=g?'ok':'bad';if(g)ok++}else c.className=(i===v.length)?'cur':''}
  var el=start?(Date.now()-start)/1000:0,w=el>1?Math.round(ok/5/(el/60)):0;$('#tw').textContent=w;$('#ta').textContent=(v.length?Math.round(ok*100/v.length):100)+'%';$('#tt').textContent=Math.floor(el/60)+':'+('0'+Math.floor(el%60)).slice(-2);
  if(v.length>=txt.length&&!done){done=true;clearInterval(timer);ta.disabled=true;var acc=Math.round(ok*100/txt.length),secs=Math.max(1,(Date.now()-start)/1000),wpm=Math.round(ok/5/(secs/60));var key=t.l+':'+t.t,b=P.typing[key];var rec=!b||wpm>b.wpm;if(rec){P.typing[key]={wpm:wpm,acc:acc};save()}
   $('#tres').innerHTML='<div class="card" style="text-align:center"><div style="font-size:38px">'+(acc>=95?'🏆':acc>=85?'👍':'📚')+'</div><div style="font-size:28px;font-weight:800">'+wpm+' WPM</div><div class="mut">Accuracy '+acc+'% · Time '+Math.round(secs)+' sec'+(rec?' · 🎉 Naya record':'')+'</div></div>'}}
 ta.addEventListener('input',function(){if(!start){start=Date.now();timer=setInterval(upd,500)}upd()});ta.addEventListener('paste',function(e){e.preventDefault();toast('Paste mana hai 😄')});upd();V._tclear=function(){clearInterval(timer)}};
/* ---- gates / digital ---- */
var GT={tab:'gate',g:'AND',a:0,b:0,expr:'(A AND B) OR NOT C',nb:'10',nv:''};
var GATES={AND:{f:function(a,b){return a&b},sym:'A · B',d:'Output tabhi 1 hota hai jab dono input 1 ho. Jaise dono switch ON ho tabhi bulb jale (series connection).',two:1},
OR:{f:function(a,b){return a|b},sym:'A + B',d:'Output 1 hota hai jab koi bhi ek input 1 ho. Jaise parallel switches: koi ek ON ho to bulb jale.',two:1},
NOT:{f:function(a){return 1-a},sym:'Ā (A\')',d:'Input ka ulta deta hai. 0 ko 1 aur 1 ko 0. Ise inverter bhi kehte hain.',two:0},
NAND:{f:function(a,b){return 1-(a&b)},sym:'(A · B)\'',d:'AND ka ulta. Sirf tab 0 jab dono input 1. NAND ko universal gate kehte hain, isse har gate ban sakta hai.',two:1},
NOR:{f:function(a,b){return 1-(a|b)},sym:'(A + B)\'',d:'OR ka ulta. Sirf tab 1 jab dono input 0. NOR bhi universal gate hai.',two:1},
XOR:{f:function(a,b){return a^b},sym:'A ⊕ B',d:'Input alag-alag ho to 1, same ho to 0. Binary addition ke sum bit me use hota hai.',two:1},
XNOR:{f:function(a,b){return 1-(a^b)},sym:'(A ⊕ B)\'',d:'Input same ho to 1, alag ho to 0. Ise equality gate bhi kehte hain.',two:1}};
function parseExpr(src){var toks=src.replace(/\(/g,' ( ').replace(/\)/g,' ) ').replace(/([&|^~!+·*])/g,' $1 ').split(/\s+/).filter(Boolean).map(function(t){var u=t.toUpperCase();return {'&':'AND','*':'AND','·':'AND','|':'OR','+':'OR','^':'XOR','~':'NOT','!':'NOT'}[t]||u}),p=0,vars={};
 function peek(){return toks[p]}function nx(){return toks[p++]}
 function prim(){var t=nx();if(t===undefined)throw new Error('Expression adhoora hai');if(t==='('){var e=or();if(nx()!==')')throw new Error('Bracket band nahi hai');return e}if(t==='NOT'){var x=prim();return function(v){return 1-x(v)}}if(t==='0'||t==='1'){var c=+t;return function(){return c}}if(/^[A-F]$/.test(t)){vars[t]=1;return function(v){return v[t]}}throw new Error('Samajh nahi aaya: '+t)}
 function not(){return prim()}
 function and(){var l=not();while(peek()==='AND'||peek()==='NAND'){var o=nx(),r=not();(function(l0,r0,o0){l=function(v){var x=l0(v)&r0(v);return o0==='NAND'?1-x:x}})(l,r,o)}return l}
 function xor(){var l=and();while(peek()==='XOR'||peek()==='XNOR'){var o=nx(),r=and();(function(l0,r0,o0){l=function(v){var x=l0(v)^r0(v);return o0==='XNOR'?1-x:x}})(l,r,o)}return l}
 function or(){var l=xor();while(peek()==='OR'||peek()==='NOR'){var o=nx(),r=xor();(function(l0,r0,o0){l=function(v){var x=l0(v)|r0(v);return o0==='NOR'?1-x:x}})(l,r,o)}return l}
 var f=or();if(p<toks.length)throw new Error('Extra cheez: '+toks[p]);return {f:f,vars:Object.keys(vars).sort()}}
function bin(n,l){var s=n.toString(2);while(s.length<l)s='0'+s;return s}
V.gates=function(){setTop('Logic Gates & Digital','Gates, Boolean, number system');var tabs=[['gate','Gates'],['expr','Expression'],['num','Number System'],['ascii','ASCII'],['law','Boolean Laws']];
 var h='<div class="chips">'+tabs.map(function(t){return '<span class="chip'+(GT.tab===t[0]?' on':'')+'" data-tab="'+t[0]+'">'+t[1]+'</span>'}).join('')+'</div><div id="gb"></div>';main.innerHTML=h;main.querySelectorAll('[data-tab]').forEach(function(c){c.onclick=function(){GT.tab=c.dataset.tab;V.gates()}});
 var el=$('#gb');
 if(GT.tab==='gate'){var g=GATES[GT.g],a=GT.a,b=GT.b,o=g.two?g.f(a,b):g.f(a);
  var s='<div class="chips">'+Object.keys(GATES).map(function(k){return '<span class="chip'+(GT.g===k?' on':'')+'" data-g="'+k+'">'+k+'</span>'}).join('')+'</div>';
  s+='<div class="card"><div class="flex"><div><div class="mut">Input A</div><div class="sw"><button class="'+(a?'on':'')+'" data-sw="a">'+a+'</button></div></div>'+(g.two?'<div><div class="mut">Input B</div><div class="sw"><button class="'+(b?'on':'')+'" data-sw="b">'+b+'</button></div></div>':'')+'<span class="sp"></span><div style="text-align:center"><div class="mut">Output</div><div class="lamp '+(o?'on':'')+'">'+o+'</div></div></div><div class="hr"></div><div><b>'+GT.g+' gate</b> · Boolean: <code>'+esc(g.sym)+'</code></div><div class="mut" style="margin-top:6px">'+g.d+'</div></div>';
  s+='<table class="t"><tr>'+(g.two?'<th>A</th><th>B</th>':'<th>A</th>')+'<th>Output</th></tr>';
  (g.two?[[0,0],[0,1],[1,0],[1,1]]:[[0],[1]]).forEach(function(r){var res=g.two?g.f(r[0],r[1]):g.f(r[0]);s+='<tr class="'+((g.two?(r[0]===a&&r[1]===b):(r[0]===a))?'hl':'')+'"><td>'+r[0]+'</td>'+(g.two?'<td>'+r[1]+'</td>':'')+'<td><b>'+res+'</b></td></tr>'});s+='</table>';
  el.innerHTML=s;el.querySelectorAll('[data-g]').forEach(function(c){c.onclick=function(){GT.g=c.dataset.g;V.gates()}});el.querySelectorAll('[data-sw]').forEach(function(c){c.onclick=function(){GT[c.dataset.sw]=1-GT[c.dataset.sw];V.gates()}})}
 else if(GT.tab==='expr'){el.innerHTML='<div class="card"><div class="mut">Variables A–F, operators: AND OR NOT XOR NAND NOR XNOR (ya & | ~ ^ + *), brackets bhi chalenge.</div><input type="text" id="ex" value="'+esc(GT.expr)+'" autocapitalize="characters" autocomplete="off" style="margin:8px 0"><button class="btn w" id="exgo">Truth table banao</button></div><div id="exr"></div>';
  function run(){GT.expr=$('#ex').value;var r=$('#exr');try{var pe=parseExpr(GT.expr),vs=pe.vars;if(!vs.length)throw new Error('Kam se kam ek variable (A, B...) likho');if(vs.length>5)throw new Error('5 variable tak hi');var n=1<<vs.length,rows='',mins=[],ones=0;
   for(var i=0;i<n;i++){var v={};vs.forEach(function(x,j){v[x]=(i>>(vs.length-1-j))&1});var res=pe.f(v);if(res){mins.push(i);ones++}rows+='<tr><td>'+vs.map(function(x){return v[x]}).join('</td><td>')+'</td><td><b>'+res+'</b></td></tr>'}
   r.innerHTML='<table class="t"><tr>'+vs.map(function(x){return '<th>'+x+'</th>'}).join('')+'<th>Output</th></tr>'+rows+'</table><div class="card"><div>Sum of minterms: <code>Σm('+mins.join(', ')+')</code></div><div class="mut" style="margin-top:6px">'+(ones===n?'Ye expression hamesha 1 hai (tautology).':ones===0?'Ye expression hamesha 0 hai (contradiction).':'Output 1 total '+ones+' combinations me aata hai.')+'</div></div>'}catch(e){r.innerHTML='<div class="call warn"><span class="k">⚠️ Galti:</span>'+esc(e.message)+'</div>'}}
  $('#exgo').onclick=run;$('#ex').addEventListener('keydown',function(e){if(e.key==='Enter')run()});run()}
 else if(GT.tab==='num'){var bases=[['2','Binary'],['8','Octal'],['10','Decimal'],['16','Hex']];el.innerHTML='<div class="card"><div class="chips">'+bases.map(function(b){return '<span class="chip'+(GT.nb===b[0]?' on':'')+'" data-nb="'+b[0]+'">'+b[1]+'</span>'}).join('')+'</div><input type="text" id="nv" value="'+esc(GT.nv)+'" placeholder="Number likho" autocomplete="off" autocapitalize="characters"></div><div id="nr"></div>';
  function conv(){GT.nv=$('#nv').value.trim().toUpperCase();var r=$('#nr');if(!GT.nv){r.innerHTML='';return}var base=+GT.nb,dg='0123456789ABCDEF',v=BigInt(0),bb=BigInt(base),i;for(i=0;i<GT.nv.length;i++){var d=dg.indexOf(GT.nv[i]);if(d<0||d>=base){r.innerHTML='<div class="call warn"><span class="k">⚠️</span>'+esc(GT.nv[i])+' is base ke liye sahi digit nahi hai</div>';return}v=v*bb+BigInt(d)}
   r.innerHTML='<table class="t"><tr><th>System</th><th>Value</th></tr><tr><td>Binary (2)</td><td><code>'+v.toString(2)+'</code></td></tr><tr><td>Octal (8)</td><td><code>'+v.toString(8)+'</code></td></tr><tr><td>Decimal (10)</td><td><code>'+v.toString(10)+'</code></td></tr><tr><td>Hex (16)</td><td><code>'+v.toString(16).toUpperCase()+'</code></td></tr></table>'}
  $('#nv').addEventListener('input',conv);el.querySelectorAll('[data-nb]').forEach(function(c){c.onclick=function(){GT.nb=c.dataset.nb;V.gates()}});conv()}
 else if(GT.tab==='ascii'){var s='<div class="mut" style="margin-bottom:8px">Printable ASCII (32–126). Yaad rakho: A=65, a=97, 0=48.</div><table class="t"><tr><th>Char</th><th>Dec</th><th>Hex</th><th>Binary</th></tr>';for(var c=32;c<127;c++)s+='<tr><td><code>'+(c===32?'space':esc(String.fromCharCode(c)))+'</code></td><td>'+c+'</td><td>'+c.toString(16).toUpperCase()+'</td><td>'+bin(c,8)+'</td></tr>';el.innerHTML=s+'</table>'}
 else{var L=[['Identity','A + 0 = A','A · 1 = A'],['Null','A + 1 = 1','A · 0 = 0'],['Idempotent','A + A = A','A · A = A'],['Complement','A + A\' = 1','A · A\' = 0'],['Double negation','(A\')\' = A',''],['Commutative','A + B = B + A','A · B = B · A'],['Associative','A + (B + C) = (A + B) + C','A · (B · C) = (A · B) · C'],['Distributive','A · (B + C) = AB + AC','A + BC = (A + B)(A + C)'],['Absorption','A + AB = A','A · (A + B) = A'],['De Morgan 1','(A + B)\' = A\' · B\'',''],['De Morgan 2','(A · B)\' = A\' + B\'','']];
  el.innerHTML='<div class="mut" style="margin-bottom:8px">Boolean algebra ke important niyam (OR form aur AND form).</div><table class="t"><tr><th>Law</th><th>OR form</th><th>AND form</th></tr>'+L.map(function(r){return '<tr><td>'+r[0]+'</td><td><code>'+esc(r[1])+'</code></td><td><code>'+esc(r[2])+'</code></td></tr>'}).join('')+'</table><div class="call yaad"><span class="k">⭐ Yaad rakho:</span>NAND aur NOR universal gates hain. Half adder: Sum = A XOR B, Carry = A AND B.</div>'}};
/* ---- flowchart ---- */
var FL={tab:'sym',steps:[{t:'start',x:'Start'},{t:'input',x:'Read a, b'},{t:'process',x:'sum = a + b'},{t:'output',x:'Print sum'},{t:'end',x:'End'}]};
var FEX=[['Do numbers ka sum',[['start','Start'],['input','Read a, b'],['process','sum = a + b'],['output','Print sum'],['end','End']],'a = int(input())\nb = int(input())\nsum = a + b\nprint(sum)\n'],
['Even ya Odd',[['start','Start'],['input','Read n'],['decision','n % 2 == 0 ?',4,5],['output','Print Even'],['output','Print Odd'],['end','End']],'n = int(input())\nif n % 2 == 0:\n    print("Even")\nelse:\n    print("Odd")\n'],
['Teen me sabse bada',[['start','Start'],['input','Read a, b, c'],['decision','a > b and a > c ?',4,5],['output','Print a'],['decision','b > c ?',6,7],['output','Print b'],['output','Print c'],['end','End']],'a = int(input())\nb = int(input())\nc = int(input())\nif a > b and a > c:\n    print(a)\nelif b > c:\n    print(b)\nelse:\n    print(c)\n'],
['1 se n tak ka sum (loop)',[['start','Start'],['input','Read n'],['process','sum = 0, i = 1'],['decision','i <= n ?',5,7],['process','sum = sum + i, i = i + 1'],['process','Go back to check'],['output','Print sum'],['end','End']],'n = int(input())\nsum = 0\ni = 1\nwhile i <= n:\n    sum = sum + i\n    i = i + 1\nprint(sum)\n'],
['Factorial',[['start','Start'],['input','Read n'],['process','f = 1, i = 1'],['decision','i <= n ?',5,7],['process','f = f * i, i = i + 1'],['process','Go back to check'],['output','Print f'],['end','End']],'n = int(input())\nf = 1\ni = 1\nwhile i <= n:\n    f = f * i\n    i = i + 1\nprint(f)\n'],
['Pass ya Fail',[['start','Start'],['input','Read marks'],['decision','marks >= 33 ?',4,5],['output','Print Pass'],['output','Print Fail'],['end','End']],'marks = int(input())\nif marks >= 33:\n    print("Pass")\nelse:\n    print("Fail")\n']];
var FSYM=[['start','Terminator (oval)','Start ya End dikhata hai. Har flowchart isse shuru aur khatam hota hai.'],['input','Input / Output (parallelogram)','Data lena (Read) ya dikhana (Print).'],['process','Process (rectangle)','Calculation ya kaam, jaise sum = a + b.'],['decision','Decision (diamond)','Haan/Nahi wala sawal. Do raaste nikalte hain: Yes aur No.'],['arrow','Flow line (arrow)','Steps ka kram dikhata hai, kis ke baad kya.'],['conn','Connector (circle)','Bada chart kai page me ho to jodne ke liye.']];
function nodeSvg(t,x,y,w,h,txt){var c={start:'#6F55F5',end:'#6F55F5',input:'#1FA67A',output:'#1FA67A',process:'#3B82F6',decision:'#E0832B'}[t]||'#6F55F5',cx=x+w/2,cy=y+h/2,s='';
 if(t==='start'||t==='end')s='<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="'+h/2+'" fill="'+c+'33" stroke="'+c+'" stroke-width="2"/>';
 else if(t==='input'||t==='output')s='<polygon points="'+(x+14)+','+y+' '+(x+w)+','+y+' '+(x+w-14)+','+(y+h)+' '+x+','+(y+h)+'" fill="'+c+'33" stroke="'+c+'" stroke-width="2"/>';
 else if(t==='decision')s='<polygon points="'+cx+','+y+' '+(x+w)+','+cy+' '+cx+','+(y+h)+' '+x+','+cy+'" fill="'+c+'33" stroke="'+c+'" stroke-width="2"/>';
 else s='<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="4" fill="'+c+'33" stroke="'+c+'" stroke-width="2"/>';
 var lines=wrap(txt,t==='decision'?14:22);var ty=cy-(lines.length-1)*7+4;return s+lines.map(function(l,i){return '<text x="'+cx+'" y="'+(ty+i*14)+'" fill="#e9ebef" font-size="12" text-anchor="middle" font-family="sans-serif">'+esc(l)+'</text>'}).join('')}
function wrap(t,n){var w=String(t).split(' '),l=[],c='';w.forEach(function(x){if((c+' '+x).trim().length>n&&c){l.push(c);c=x}else c=(c+' '+x).trim()});if(c)l.push(c);return l.slice(0,3)}
function flowSvg(st){var W=300,NW=170,NH=44,GAP=34,X=40,pos=[],y=14;st.forEach(function(s,i){var h=s.t==='decision'?64:NH;pos.push({y:y,h:h});y+=h+GAP});var H=y,svg='',i;
 svg+='<defs><marker id="ar" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#9aa1ad"/></marker></defs>';
 st.forEach(function(s,i){var p=pos[i];svg+=nodeSvg(s.t,X,p.y,NW,p.h,s.x);svg+='<text x="'+(X-8)+'" y="'+(p.y+p.h/2+4)+'" fill="#9aa1ad" font-size="11" text-anchor="end" font-family="sans-serif">'+(i+1)+'</text>'});
 st.forEach(function(s,i){var p=pos[i],cx=X+NW/2;if(s.t==='end')return;
  if(s.t==='decision'){var yes=(s.yes||i+2)-1,no=(s.no||i+2)-1;var arrowTo=function(j,lab,off,col){if(j<0||j>=st.length)return '';var q=pos[j];if(j===i+1){return '<line x1="'+cx+'" y1="'+(p.y+p.h)+'" x2="'+cx+'" y2="'+(q.y-1)+'" stroke="'+col+'" stroke-width="1.6" marker-end="url(#ar)"/><text x="'+(cx+6)+'" y="'+(p.y+p.h+14)+'" fill="'+col+'" font-size="11" font-family="sans-serif">'+lab+'</text>'}
     var rx=X+NW+off,sy=p.y+p.h/2,ty=q.y+q.h/2;var d='M'+(X+NW)+','+sy+' L'+rx+','+sy+' L'+rx+','+ty+' L'+(X+NW+2)+','+ty;return '<path d="'+d+'" fill="none" stroke="'+col+'" stroke-width="1.6" marker-end="url(#ar)" stroke-linejoin="round"/><text x="'+(X+NW+4)+'" y="'+(sy-4)+'" fill="'+col+'" font-size="11" font-family="sans-serif">'+lab+'</text>'};
   svg+=arrowTo(yes,'Yes',16+((i*7)%3)*12,'#4CCB6A')+arrowTo(no,'No',34+((i*5)%3)*12,'#FF7B72');return}
  if(i+1<st.length){var q=pos[i+1];svg+='<line x1="'+cx+'" y1="'+(p.y+p.h)+'" x2="'+cx+'" y2="'+(q.y-1)+'" stroke="#9aa1ad" stroke-width="1.6" marker-end="url(#ar)"/>'}});
 return '<svg viewBox="0 0 '+W+' '+H+'" width="100%" xmlns="http://www.w3.org/2000/svg">'+svg+'</svg>'}
function algoText(st){return st.map(function(s,i){var n=(i+1)+'. ';switch(s.t){case 'start':return n+'START';case 'end':return n+'STOP';case 'input':return n+s.x.replace(/^read\s*/i,'READ ').replace(/^input\s*/i,'READ ');case 'output':return n+s.x.replace(/^print\s*/i,'PRINT ').replace(/^display\s*/i,'PRINT ');case 'decision':return n+'IF '+s.x.replace(/\s*\?$/,'')+' THEN go to step '+(s.yes||i+2)+' ELSE go to step '+(s.no||i+2);default:return n+s.x}}).join('\n')}
V.flow=function(){setTop('Flowchart / Algorithm','Symbols, examples, builder');var tabs=[['sym','Symbols'],['ex','Examples'],['build','Builder'],['rules','Rules']];var h='<div class="chips">'+tabs.map(function(t){return '<span class="chip'+(FL.tab===t[0]?' on':'')+'" data-tab="'+t[0]+'">'+t[1]+'</span>'}).join('')+'</div><div id="fb"></div>';main.innerHTML=h;main.querySelectorAll('[data-tab]').forEach(function(c){c.onclick=function(){FL.tab=c.dataset.tab;V.flow()}});var el=$('#fb');
 if(FL.tab==='sym'){var s='<div class="mut" style="margin-bottom:10px">Flowchart me alag kaam ke liye alag shape hoti hai.</div>';FSYM.forEach(function(f){var svg=f[0]==='arrow'?'<svg viewBox="0 0 120 50" width="110"><line x1="10" y1="25" x2="105" y2="25" stroke="#9aa1ad" stroke-width="2.5" marker-end="url(#ar)"/><defs><marker id="ar" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#9aa1ad"/></marker></defs></svg>':f[0]==='conn'?'<svg viewBox="0 0 120 50" width="110"><circle cx="60" cy="25" r="18" fill="#6F55F533" stroke="#6F55F5" stroke-width="2"/><text x="60" y="30" fill="#e9ebef" font-size="13" text-anchor="middle">A</text></svg>':'<svg viewBox="0 0 120 56" width="110">'+nodeSvg(f[0],8,6,104,44,f[0]==='start'?'Start':f[0]==='input'?'Read a':f[0]==='process'?'x = a + 1':'a > b ?')+'</svg>';s+='<div class="card flex">'+svg+'<div><b>'+f[1]+'</b><div class="mut">'+f[2]+'</div></div></div>'});el.innerHTML=s}
 else if(FL.tab==='ex'){var s='<div class="mut" style="margin-bottom:10px">Example chuno. Builder me khol ke badal bhi sakte ho.</div>';FEX.forEach(function(e,i){s+='<button class="row" data-ex="'+i+'"><span class="ic">🧩</span><span class="bd"><div class="nm">'+esc(e[0])+'</div><div class="sb">'+e[1].length+' steps</div></span><span class="go">›</span></button>'});el.innerHTML=s;el.querySelectorAll('[data-ex]').forEach(function(c){c.onclick=function(){var e=FEX[+c.dataset.ex];FL.steps=e[1].map(function(x){return {t:x[0],x:x[1],yes:x[2],no:x[3]}});FL.code=e[2];FL.name=e[0];FL.tab='build';V.flow()}})}
 else if(FL.tab==='build'){var st=FL.steps;var s='<div class="card"><div class="mut" style="margin-bottom:8px">Step jodo (tap karo):</div><div class="chips">'+[['start','Start'],['input','Input'],['process','Process'],['output','Output'],['decision','Decision'],['end','End']].map(function(x){return '<span class="chip" data-add="'+x[0]+'">+ '+x[1]+'</span>'}).join('')+'</div></div>';
  st.forEach(function(x,i){s+='<div class="card" style="padding:10px"><div class="flex"><b>'+(i+1)+'. '+x.t+'</b><span class="sp"></span><button class="btn s g" data-up="'+i+'">↑</button><button class="btn s g" data-dn="'+i+'">↓</button><button class="btn s g" data-del="'+i+'">✕</button></div><input type="text" data-tx="'+i+'" value="'+esc(x.x)+'" style="margin-top:8px">'+(x.t==='decision'?'<div class="flex" style="margin-top:8px"><span class="mut">Yes → step</span><input type="text" inputmode="numeric" data-yes="'+i+'" value="'+(x.yes||i+2)+'" style="width:70px"><span class="mut">No → step</span><input type="text" inputmode="numeric" data-no="'+i+'" value="'+(x.no||i+2)+'" style="width:70px"></div>':'')+'</div>'});
  s+='<h2 class="sec">Flowchart</h2><div class="fl" id="fsv">'+flowSvg(st)+'</div><h2 class="sec">Algorithm / Pseudocode</h2><pre class="cb" style="padding:12px;white-space:pre-wrap;font-family:ui-monospace,monospace;font-size:13px">'+esc(algoText(st))+'</pre><div class="call note"><span class="k">📝 Note:</span>Ye <b>pseudocode</b> hai, Python/C me seedha run nahi hota. Isliye copy karne par har line ke aage # lag jata hai. Chalne wale code ke liye neeche ka Python code button use karo.</div><button class="btn w g" data-a="fcopy">📋 Algorithm copy karo (comments ke saath)</button>';
  if(FL.code)s+='<button class="btn w" data-a="fcode" style="margin-top:10px">▶ Iska Python code Playground me kholo</button>';el.innerHTML=s;
  function redraw(){$('#fsv').innerHTML=flowSvg(FL.steps)}
  el.querySelectorAll('[data-add]').forEach(function(c){c.onclick=function(){var t=c.dataset.add;st.push({t:t,x:{start:'Start',end:'End',input:'Read x',output:'Print x',process:'x = x + 1',decision:'x > 0 ?'}[t]});V.flow()}});
  el.querySelectorAll('[data-del]').forEach(function(c){c.onclick=function(){st.splice(+c.dataset.del,1);V.flow()}});
  el.querySelectorAll('[data-up]').forEach(function(c){c.onclick=function(){var i=+c.dataset.up;if(i>0){var t=st[i];st[i]=st[i-1];st[i-1]=t;V.flow()}}});
  el.querySelectorAll('[data-dn]').forEach(function(c){c.onclick=function(){var i=+c.dataset.dn;if(i<st.length-1){var t=st[i];st[i]=st[i+1];st[i+1]=t;V.flow()}}});
  el.querySelectorAll('[data-tx]').forEach(function(c){c.addEventListener('input',function(){st[+c.dataset.tx].x=c.value;redraw()})});
  el.querySelectorAll('[data-yes]').forEach(function(c){c.addEventListener('input',function(){st[+c.dataset.yes].yes=+c.value||undefined;redraw()})});el.querySelectorAll('[data-no]').forEach(function(c){c.addEventListener('input',function(){st[+c.dataset.no].no=+c.value||undefined;redraw()})})}
 else{el.innerHTML='<div class="lesson"><h3>Algorithm kya hai?</h3><p>Kisi kaam ko karne ke <b>step-by-step</b> tarike ko algorithm kehte hain. Jaise chai banane ka tarika: paani garam karo, patti daalo, doodh aur cheeni daalo, chhan lo.</p><h3>Achhe algorithm ke gun</h3><ul><li><b>Input:</b> zero ya zyada input ho sakte hain.</li><li><b>Output:</b> kam se kam ek output zaroor ho.</li><li><b>Definiteness:</b> har step saaf aur ek hi matlab wala ho.</li><li><b>Finiteness:</b> kuch steps ke baad khatam ho jaye.</li><li><b>Effectiveness:</b> har step asaan aur karne layak ho.</li></ul><h3>Flowchart ke niyam</h3><ol><li>Start se shuru karo, End par khatam karo.</li><li>Flow upar se neeche, ya left se right.</li><li>Decision (diamond) se hamesha do raaste: Yes aur No.</li><li>Ek symbol me ek hi kaam likho, chhota text.</li><li>Arrows kabhi cross na karo agar bach sake.</li></ol><h3>Pseudocode</h3><p>Pseudocode algorithm ko English jaisi simple language me likhna hai (koi fixed syntax nahi). Jaise: <code>READ n</code>, <code>IF n % 2 = 0 THEN PRINT Even</code>.</p><div class="call yaad"><span class="k">⭐ Yaad rakho:</span>Algorithm pehle likhte hain, phir flowchart, phir program. Ye dono programming language par depend nahi karte.</div></div>'}};
/* ---------- router ---------- */
function route(){var h=location.hash.replace(/^#\/?/,''),p=h.split('/'),n=p[0]||'home',a=p.slice(1).join('/');if(V._tclear){V._tclear();V._tclear=null}
 if(!V[n]){n='home';a=''}try{V[n](a)}catch(e){main.innerHTML='<div class="empty">Kuch gadbad hui: '+esc(e.message)+'</div>'}if(n!=='lesson'&&n!=='note'&&n!=='error'&&n!=='problem')window.scrollTo(0,0)}
window.addEventListener('hashchange',route);
/* ---------- delegated clicks ---------- */
document.addEventListener('click',function(e){var t=e.target.closest('[data-go],[data-a]');if(!t)return;
 if(t.dataset.go){go(t.dataset.go);return}var a=t.dataset.a;
 if(a==='run'){var b=cbStore[+t.dataset.i];openCode(b.lang,b.code,b.title)}
 else if(a==='cp'){copy(cbStore[+t.dataset.i].code)}
 else if(a==='done'){var id=t.dataset.id;if(P.done[id])delete P.done[id];else P.done[id]=1;save();V.lesson(id)}
 else if(a==='pdone'){var id2=t.dataset.id;if(P.prob[id2])delete P.prob[id2];else P.prob[id2]=1;save();V.problem(id2)}
 else if(a==='try'){openCode(t.dataset.lang,V._starter,'Practice')}
 else if(a==='mq'||a==='qa'){var q=t.closest('.q'),ans=+q.dataset.qa,i=+t.dataset.i;if(q.dataset.done)return;q.dataset.done=1;q.querySelectorAll('.opt').forEach(function(o,j){o.disabled=true;if(j===ans)o.classList.add('ok');else if(j===i)o.classList.add('no')});q.querySelector('.ex').hidden=false;
  if(a==='qa'){var cur=QZ.pool[QZ.i],k=hsh(cur.q);if(i===ans){QZ.sc++;delete P.wrong[k]}else{QZ.wrong.push({q:cur.q,o:cur.o,a:cur.a,e:cur.e,mine:i});P.wrong[k]=1}save();var nb=$('#qnext');nb.hidden=false}}
 else if(a==='qnext'){QZ.i++;V.quizrun()}
 else if(a==='qstart'){var s=V._qsel,pool;if(s.t==='*')pool=D.mcq.slice();else if(s.t==='!w')pool=D.mcq.filter(function(q){return P.wrong[hsh(q.q)]});else pool=D.mcq.filter(function(q){return q.t===s.t});qStart(pool,s.t,s.n)}
 else if(a==='qretry'){var pw=QZ.wrong.map(function(w){return {t:'Revise',q:w.q,o:w.o,a:w.a,e:w.e}});qStart(pw,'!w',0)}
 else if(a==='sctest'){SCST.test=null;go('#/sctest')}
 else if(a==='sctest2'){SCST.test=null;V.sctest()}
 else if(a==='sa'){var q2=t.closest('.q'),ans2=+q2.dataset.qa,i2=+t.dataset.i;if(q2.dataset.done)return;q2.dataset.done=1;q2.querySelectorAll('.opt').forEach(function(o,j){o.disabled=true;if(j===ans2)o.classList.add('ok');else if(j===i2)o.classList.add('no')});if(i2===ans2)SCST.test.sc++;$('#qnext').hidden=false}
 else if(a==='snext'){SCST.test.i++;V.sctest()}
 else if(a==='gmode'){GST.fc=t.dataset.v==='1';GST.i=0;GST.show=false;V.glossary()}
 else if(a==='gnext'){GST.i++;GST.show=false;V._glist()}
 else if(a==='gprev'){GST.i=Math.max(0,GST.i-1);GST.show=false;V._glist()}
 else if(a==='treset'){V.typetest(t.dataset.n)}
 else if(a==='fcopy'){copy(algoText(FL.steps).split('\n').map(function(l){return '# '+l}).join('\n')+'\n')}
 else if(a==='fcode'){openCode('py',FL.code,FL.name)}});
window.csOpen=function(h){go(h)};
route();
})();
