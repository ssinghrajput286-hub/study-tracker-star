window.D=window.D||{};D.errors=[];
