window.D=window.D||{};D.glossary=[];
