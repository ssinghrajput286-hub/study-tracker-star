window.D=window.D||{};D.notes=[];
