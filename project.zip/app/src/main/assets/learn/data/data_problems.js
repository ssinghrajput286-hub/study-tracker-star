window.D=window.D||{};D.problems=[];
