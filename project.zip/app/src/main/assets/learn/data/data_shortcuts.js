window.D=window.D||{};D.shortcuts=[];
