window.D=window.D||{};D.typing=[];
