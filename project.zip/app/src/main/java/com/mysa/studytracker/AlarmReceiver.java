package com.mysa.studytracker;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String id = in.getStringExtra("id");
        String label = in.getStringExtra("label");
        String t = in.getStringExtra("t");
        boolean test = in.getBooleanExtra("test", false);
        if (label == null || label.length() == 0) label = "Padhai ka time";
        if (id == null) id = "test";
        show(c, id, label, t, test);
        if (!test) {
            // fired one is now in the past, so this plans the next week for it
            Reminders.scheduleAll(c);
        }
    }

    static void show(Context c, String id, String label, String t, boolean test) {
        Reminders.ensureChannel(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, Reminders.CHANNEL)
                : new Notification.Builder(c);
        String text = label + (t != null ? " (" + t + ")" : "");
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(test ? "Test alarm" : "Padhne ka time!")
                .setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_MAX);
            b.setSound(Reminders.alarmSound());
            b.setVibrate(new long[]{0, 600, 300, 600, 300, 600});
        }
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        nm.notify(id.hashCode(), n);
    }
}
