package com.mysa.studytracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Plans the alarms again after phone restart, app update, or time change. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        Reminders.scheduleAll(c);
    }
}
