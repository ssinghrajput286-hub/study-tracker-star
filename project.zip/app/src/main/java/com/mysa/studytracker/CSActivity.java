package com.mysa.studytracker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * CS (Computer Science) home. It holds folders:
 * Code-Playground (write and run code), Saved Code (programs you saved) and Note (flashcards).
 */
public class CSActivity extends Activity {

    private LinearLayout folders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.load(this);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(Ui.header(this, "CS", "Computer Science"));

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 24));

        body.addView(buildHero());

        TextView label = Ui.text(this, "FOLDERS", 12, Ui.MUTED, true);
        label.setLetterSpacing(0.1f);
        label.setPadding(Ui.dp(this, 4), 0, 0, Ui.dp(this, 10));
        body.addView(label);

        folders = new LinearLayout(this);
        folders.setOrientation(LinearLayout.VERTICAL);
        body.addView(folders);

        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    /** Maximalist hero: accent gradient, big title, decorative translucent circles. */
    private View buildHero() {
        FrameLayout hero = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Ui.BAR, Ui.BAR2});
        g.setCornerRadius(Ui.dp(this, 28));
        g.setStroke(Ui.dp(this, 1), 0x33FFFFFF);
        hero.setBackground(g);

        addCircle(hero, 140, 0x22FFFFFF, Gravity.TOP | Gravity.END, 0, -40, -30, 0);
        addCircle(hero, 90, 0x1AFFFFFF, Gravity.BOTTOM | Gravity.END, 0, 0, 60, -30);
        addCircle(hero, 56, 0x26FFFFFF, Gravity.BOTTOM | Gravity.START, 150, 0, 0, -18);

        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(Ui.dp(this, 22), Ui.dp(this, 26), Ui.dp(this, 22), Ui.dp(this, 26));
        TextView title = Ui.text(this, "Computer Science", 28, Color.WHITE, true);
        t.addView(title);
        TextView sub = Ui.text(this, "Code, learn and keep your notes in one place", 14, 0xE6FFFFFF, false);
        sub.setPadding(0, Ui.dp(this, 6), 0, 0);
        t.addView(sub);
        hero.addView(t, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 22);
        hero.setLayoutParams(lp);
        Ui.enter(hero, 0);
        return hero;
    }

    private void addCircle(FrameLayout parent, int sizeDp, int color, int gravity,
                           int ml, int mt, int mr, int mb) {
        View v = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        v.setBackground(d);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Ui.dp(this, sizeDp), Ui.dp(this, sizeDp), gravity);
        lp.setMargins(Ui.dp(this, ml), Ui.dp(this, mt), Ui.dp(this, mr), Ui.dp(this, mb));
        parent.addView(v, lp);
    }

    @Override
    protected void onResume() {
        super.onResume();
        folders.removeAllViews();   // counts change after saving, so rebuild each time
        int saved = CodeStore.count(this);
        addFolder("💻", 0xFF6F55F5, "Code-Playground",
                "Write code and run it", null,
                new Intent(this, PlaygroundActivity.class));
        addFolder("📚", 0xFF3B82F6, "Learn",
                "Lessons, quiz, shortcuts, typing and more", null,
                new Intent(this, LearnActivity.class));
        addFolder("💾", 0xFF1FA67A, "Saved Code",
                saved == 0 ? "Programs you save show up here"
                        : saved + (saved == 1 ? " saved program" : " saved programs"),
                String.valueOf(saved),
                new Intent(this, SavedCodeActivity.class));
        addFolder("📓", 0xFFE0832B, "Note",
                "Flashcards and playground settings", null,
                new Intent(this, PlaygroundSettingsActivity.class));
    }

    private void addFolder(String icon, int iconBg, String title, String sub, String badge,
                           final Intent target) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.clay(this, Ui.SURFACE, 20));
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 17));

        TextView ic = Ui.text(this, icon, 26, Color.WHITE, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(Ui.clay(this, iconBg, 16));
        row.addView(ic, new LinearLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 56)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 8), 0);
        texts.addView(Ui.text(this, title, 18, Ui.TEXT, true));
        TextView s = Ui.text(this, sub, 13, Ui.MUTED, false);
        s.setPadding(0, Ui.dp(this, 2), 0, 0);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (badge != null) {
            TextView b = Ui.chip(this, badge, Ui.SURFACE_2, Ui.TEXT);
            row.addView(b);
        }
        TextView arrow = Ui.text(this, "›", 26, Ui.MUTED, false);
        arrow.setPadding(Ui.dp(this, 10), 0, 0, 0);
        row.addView(arrow);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ui.haptic(v);
                startActivity(target);
            }
        });
        Ui.press(row);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 12);
        Ui.enter(row, folders.getChildCount() + 1);
        folders.addView(row, lp);
    }
}
