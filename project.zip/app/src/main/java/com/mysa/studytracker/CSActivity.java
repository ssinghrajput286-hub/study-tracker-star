package com.mysa.studytracker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * CS (Computer Science) home. It holds folders:
 * Code-Playground (write and run code), Saved Code (programs you saved) and Note (flashcards).
 */
public class CSActivity extends Activity {

    private LinearLayout folders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(Ui.header(this, "CS", "Computer Science"));

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 24));

        TextView label = Ui.text(this, "FOLDERS", 12, Ui.MUTED, true);
        label.setLetterSpacing(0.1f);
        label.setPadding(Ui.dp(this, 4), 0, 0, Ui.dp(this, 10));
        body.addView(label);

        folders = new LinearLayout(this);
        folders.setOrientation(LinearLayout.VERTICAL);
        body.addView(folders);

        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        folders.removeAllViews();   // counts change after saving, so rebuild each time
        int saved = CodeStore.count(this);
        addFolder("💻", 0xFF6F55F5, "Code-Playground",
                "Write code and run it", null,
                new Intent(this, PlaygroundActivity.class));
        addFolder("📚", 0xFF3B82F6, "Learn",
                "Lessons, quiz, shortcuts, typing and more", null,
                new Intent(this, LearnActivity.class));
        addFolder("💾", 0xFF1FA67A, "Saved Code",
                saved == 0 ? "Programs you save show up here"
                        : saved + (saved == 1 ? " saved program" : " saved programs"),
                String.valueOf(saved),
                new Intent(this, SavedCodeActivity.class));
        addFolder("📓", 0xFFE0832B, "Note",
                "Flashcards and playground settings", null,
                new Intent(this, PlaygroundSettingsActivity.class));
    }

    private void addFolder(String icon, int iconBg, String title, String sub, String badge,
                           final Intent target) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.card(this, Ui.SURFACE, 16));
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));

        TextView ic = Ui.text(this, icon, 26, Color.WHITE, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(Ui.rounded(this, iconBg, 14));
        row.addView(ic, new LinearLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 56)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 8), 0);
        texts.addView(Ui.text(this, title, 18, Ui.TEXT, true));
        TextView s = Ui.text(this, sub, 13, Ui.MUTED, false);
        s.setPadding(0, Ui.dp(this, 2), 0, 0);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (badge != null) {
            TextView b = Ui.chip(this, badge, Ui.SURFACE_2, Ui.TEXT);
            row.addView(b);
        }
        TextView arrow = Ui.text(this, "›", 26, Ui.MUTED, false);
        arrow.setPadding(Ui.dp(this, 10), 0, 0, 0);
        row.addView(arrow);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(target);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 12);
        folders.addView(row, lp);
    }
}
