package com.mysa.studytracker;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Saved programs, kept on the phone. They live in the "Saved Code" folder of CS. */
final class CodeStore {
    private static final String PREFS = "cs_saved";
    private static final String KEY = "items";

    private CodeStore() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String langName(String id) {
        switch (id) {
            case "py": return "Python";
            case "js": return "JavaScript";
            case "c": return "C";
            case "cpp": return "C++";
            case "java": return "Java";
            case "kt": return "Kotlin";
            case "go": return "Go";
            case "web": return "Web (HTML)";
            case "cs": return "C#";
            case "rb": return "Ruby";
            case "php": return "PHP";
            case "swift": return "Swift";
            case "r": return "R";
            case "rs": return "Rust";
            case "ts": return "TypeScript";
            default: return id;
        }
    }

    /** Newest first. */
    static JSONArray list(Context c) {
        try {
            return new JSONArray(prefs(c).getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static int count(Context c) {
        return list(c).length();
    }

    /** Saves a program. A program with the same name and language is replaced. */
    static void save(Context c, String name, String lang, String code) {
        try {
            JSONArray old = list(c);
            JSONArray next = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("id", "p" + System.currentTimeMillis());
            o.put("name", name);
            o.put("lang", lang);
            o.put("code", code);
            o.put("time", System.currentTimeMillis());
            next.put(o);
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                boolean same = name.equals(x.optString("name")) && lang.equals(x.optString("lang"));
                if (!same) next.put(x);
            }
            prefs(c).edit().putString(KEY, next.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static void delete(Context c, String id) {
        try {
            JSONArray old = list(c);
            JSONArray next = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                if (!id.equals(x.optString("id"))) next.put(x);
            }
            prefs(c).edit().putString(KEY, next.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
