package com.mysa.studytracker;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Saved programs, kept on the phone. They live in the "Saved Code" folder of CS. */
final class CodeStore {
    private static final String PREFS = "cs_saved";
    private static final String KEY = "items";
    private static final String FKEY = "folders";

    private CodeStore() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String langName(String id) {
        switch (id) {
            case "py": return "Python";
            case "js": return "JavaScript";
            case "c": return "C";
            case "cpp": return "C++";
            case "java": return "Java";
            case "kt": return "Kotlin";
            case "go": return "Go";
            case "web": return "Web (HTML)";
            case "cs": return "C#";
            case "rb": return "Ruby";
            case "php": return "PHP";
            case "swift": return "Swift";
            case "r": return "R";
            case "rs": return "Rust";
            case "ts": return "TypeScript";
            default: return id;
        }
    }

    /** Newest first. */
    static JSONArray list(Context c) {
        try {
            return new JSONArray(prefs(c).getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static int count(Context c) {
        return list(c).length();
    }

    /** Saves a program. A program with the same name and language is replaced (its folder is kept). */
    static void save(Context c, String name, String lang, String code) {
        put(c, name, lang, code, "", false);
    }

    /**
     * Saves a program into a folder. Only a program with the same name, language and folder
     * is replaced, so code saved from Learn never overwrites the user's own programs.
     */
    static void save(Context c, String name, String lang, String code, String folder) {
        String f = folder == null ? "" : folder.trim();
        if (f.length() > 0) addFolder(c, f);
        put(c, name, lang, code, f, true);
    }

    private static void put(Context c, String name, String lang, String code, String folder,
                            boolean matchFolder) {
        try {
            JSONArray old = list(c);
            JSONArray next = new JSONArray();
            String keepFolder = folder;
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                boolean same = name.equals(x.optString("name")) && lang.equals(x.optString("lang"))
                        && (!matchFolder || folder.equals(x.optString("folder")));
                if (same && !matchFolder) keepFolder = x.optString("folder");
            }
            JSONObject o = new JSONObject();
            o.put("id", "p" + System.currentTimeMillis());
            o.put("name", name);
            o.put("lang", lang);
            o.put("code", code);
            o.put("time", System.currentTimeMillis());
            if (keepFolder.length() > 0) o.put("folder", keepFolder);
            next.put(o);
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                boolean same = name.equals(x.optString("name")) && lang.equals(x.optString("lang"))
                        && (!matchFolder || folder.equals(x.optString("folder")));
                if (!same) next.put(x);
            }
            prefs(c).edit().putString(KEY, next.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    // ---------------- folders ----------------
    // A program without a "folder" field is unfiled. It still shows in "Sab" (all programs).

    private static JSONArray storedFolders(Context c) {
        try {
            return new JSONArray(prefs(c).getString(FKEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static int indexOfIgnoreCase(JSONArray a, String name) {
        for (int i = 0; i < a.length(); i++) {
            if (name.equalsIgnoreCase(a.optString(i))) return i;
        }
        return -1;
    }

    /** All folder names: the ones created by the user plus any a saved program points to. */
    static JSONArray folders(Context c) {
        JSONArray out = storedFolders(c);
        JSONArray items = list(c);
        for (int i = 0; i < items.length(); i++) {
            JSONObject x = items.optJSONObject(i);
            if (x == null) continue;
            String f = x.optString("folder");
            if (f.length() > 0 && indexOfIgnoreCase(out, f) < 0) out.put(f);
        }
        return out;
    }

    /** Returns false if the name is empty, "Sab" or already used. */
    static boolean addFolder(Context c, String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0 || n.equalsIgnoreCase("Sab")) return false;
        JSONArray all = folders(c);
        if (indexOfIgnoreCase(all, n) >= 0) return false;
        JSONArray s = storedFolders(c);
        s.put(n);
        prefs(c).edit().putString(FKEY, s.toString()).apply();
        return true;
    }

    /** Renames a folder and moves its programs along. False if the new name is not allowed. */
    static boolean renameFolder(Context c, String from, String to) {
        String n = to == null ? "" : to.trim();
        if (n.length() == 0 || n.equalsIgnoreCase("Sab")) return false;
        if (!from.equalsIgnoreCase(n) && indexOfIgnoreCase(folders(c), n) >= 0) return false;
        try {
            JSONArray s = storedFolders(c);
            JSONArray ns = new JSONArray();
            boolean found = false;
            for (int i = 0; i < s.length(); i++) {
                if (from.equalsIgnoreCase(s.optString(i))) {
                    ns.put(n);
                    found = true;
                } else {
                    ns.put(s.optString(i));
                }
            }
            if (!found) ns.put(n);
            prefs(c).edit().putString(FKEY, ns.toString()).apply();
            JSONArray old = list(c);
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                if (from.equalsIgnoreCase(x.optString("folder"))) x.put("folder", n);
            }
            prefs(c).edit().putString(KEY, old.toString()).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Removes the folder only. Its programs stay and become unfiled (still visible in "Sab"). */
    static void deleteFolder(Context c, String name) {
        try {
            JSONArray s = storedFolders(c);
            JSONArray ns = new JSONArray();
            for (int i = 0; i < s.length(); i++) {
                if (!name.equalsIgnoreCase(s.optString(i))) ns.put(s.optString(i));
            }
            prefs(c).edit().putString(FKEY, ns.toString()).apply();
            JSONArray old = list(c);
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                if (name.equalsIgnoreCase(x.optString("folder"))) x.remove("folder");
            }
            prefs(c).edit().putString(KEY, old.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** Moves one program into a folder ("" = no folder). */
    static void move(Context c, String id, String folder) {
        try {
            String f = folder == null ? "" : folder.trim();
            if (f.length() > 0) addFolder(c, f);
            JSONArray old = list(c);
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                if (id.equals(x.optString("id"))) {
                    if (f.length() > 0) x.put("folder", f);
                    else x.remove("folder");
                }
            }
            prefs(c).edit().putString(KEY, old.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static void delete(Context c, String id) {
        try {
            JSONArray old = list(c);
            JSONArray next = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject x = old.getJSONObject(i);
                if (!id.equals(x.optString("id"))) next.put(x);
            }
            prefs(c).edit().putString(KEY, next.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
