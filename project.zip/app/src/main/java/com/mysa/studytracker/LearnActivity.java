package com.mysa.studytracker;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

/**
 * CS > Learn. Lessons, quiz, shortcuts, glossary, practice, notes, logic gates, typing and
 * flowchart tools. The pages live in assets/learn and work offline.
 */
public class LearnActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.BG);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        web = new WebView(this);
        web.setBackgroundColor(Ui.BG);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setAllowFileAccess(false);
        st.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidLearn");
        web.loadUrl("file:///android_asset/learn/index.html");
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    /** The page calls these. */
    private class Bridge {
        @JavascriptInterface
        public void openCode(final String lang, final String code, final String name) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent in = new Intent(LearnActivity.this, PlaygroundActivity.class);
                    in.putExtra("lang", lang);
                    in.putExtra("code", code);
                    in.putExtra("name", name == null ? "" : name);
                    startActivity(in);
                }
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("learn", text));
                }
            });
        }

        @JavascriptInterface
        public void close() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        // The page goes back one screen itself; if it is already on the home screen, close.
        web.evaluateJavascript("(function(){return window.csBack?csBack():false})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        if (!"true".equals(v)) finish();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
