package com.mysa.studytracker;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/**
 * CS > Learn. Lessons, quiz, shortcuts, glossary, practice, notes, logic gates, typing and
 * flowchart tools. The pages live in assets/learn and work offline.
 */
public class LearnActivity extends Activity {

    private static final Object PY_LOCK = new Object();

    /** A string as a safe JavaScript string literal. */
    private static String jsq(String s) {
        return org.json.JSONObject.quote(s == null ? "" : s)
                .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
    }

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.load(this);
        // The page has a glass top bar, so the status bar blends with the page background.
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        web = new WebView(this);
        web.setBackgroundColor(Ui.BG);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setAllowFileAccess(false);
        st.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidLearn");
        web.loadUrl("file:///android_asset/learn/index.html");
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        applyBars("light".equals(getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE)
                .getString("theme", "dark")));
    }

    /** Status/navigation bar and WebView background follow the page theme. */
    @SuppressWarnings("deprecation")
    private void applyBars(boolean light) {
        int bg = light ? 0xFFF4F1FA : Ui.BG;
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        View decor = getWindow().getDecorView();
        int f = decor.getSystemUiVisibility();
        int lightFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        if (light) {
            f |= lightFlags;
        } else {
            f &= ~lightFlags;
        }
        decor.setSystemUiVisibility(f);
        if (web != null) web.setBackgroundColor(bg);
    }

    /** The page calls these. */
    private class Bridge {
        /** Look-and-feel settings saved by the native settings screen, as JSON (only keys that exist). */
        @JavascriptInterface
        public String getUi() {
            try {
                android.content.SharedPreferences p = getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE);
                org.json.JSONObject o = new org.json.JSONObject();
                if (p.contains("theme")) o.put("theme", p.getString("theme", "dark"));
                if (p.contains("accent")) o.put("accent", p.getString("accent", "violet"));
                if (p.contains("anim")) o.put("anim", p.getBoolean("anim", true));
                if (p.contains("haptics")) o.put("haptics", p.getBoolean("haptics", true));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        /** The page saves its look-and-feel choices here so native screens match. */
        @JavascriptInterface
        public void setTheme(final String theme, final String accent, final boolean anim, final boolean haptic) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).edit()
                            .putString("theme", theme == null ? "dark" : theme)
                            .putString("accent", accent == null ? "violet" : accent)
                            .putBoolean("anim", anim)
                            .putBoolean("haptics", haptic)
                            .apply();
                    Ui.load(LearnActivity.this);
                    applyBars("light".equals(theme));
                }
            });
        }

        @JavascriptInterface
        public void openCode(final String lang, final String code, final String name) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent in = new Intent(LearnActivity.this, PlaygroundActivity.class);
                    in.putExtra("lang", lang);
                    in.putExtra("code", code);
                    in.putExtra("name", name == null ? "" : name);
                    startActivity(in);
                }
            });
        }

        /**
         * Runs Python code with the given stdin through runner.py (background thread, 10 second limit)
         * and sends the printed text back to the page by calling window.pyDone(id, output, failed).
         */
        @JavascriptInterface
        public void runPy(final String reqId, final String code, final String stdin) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String out;
                    boolean failed = false;
                    try {
                        synchronized (PY_LOCK) {
                            if (!Python.isStarted()) {
                                Python.start(new AndroidPlatform(LearnActivity.this));
                            }
                            out = Python.getInstance().getModule("runner")
                                    .callAttr("run", code == null ? "" : code,
                                            stdin == null ? "" : stdin, 10).toString();
                        }
                    } catch (Throwable e) {
                        out = String.valueOf(e.getMessage());
                        failed = true;
                    }
                    final String js = "window.pyDone&&pyDone("
                            + jsq(reqId) + "," + jsq(out) + "," + failed + ")";
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web != null) web.evaluateJavascript(js, null);
                        }
                    });
                }
            }).start();
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("learn", text));
                }
            });
        }

        @JavascriptInterface
        public void close() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        // The page goes back one screen itself; if it is already on the home screen, close.
        web.evaluateJavascript("(function(){return window.csBack?csBack():false})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        if (!"true".equals(v)) finish();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
