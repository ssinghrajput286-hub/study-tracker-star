package com.mysa.studytracker;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_FILE = 11;
    private static final int REQ_CAM = 12;
    private static final int REQ_PERM_CAMERA_FILE = 21;
    private static final int REQ_PERM_CAMERA_WEB = 22;
    private static final int REQ_PERM_NOTIF = 23;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private Uri camUri;
    private PermissionRequest pendingWebPerm;

    private static final String BACK_JS =
            "(function(){var o=document.querySelector('#sheetWrap .ov');if(o){o.click();return true}"
                    + "var e=document.querySelector('#npEd [data-act=npClose]');if(e){e.click();return true}"
                    + "var b=document.querySelector('header.top [data-act=back]');if(b){b.click();return true}"
                    + "var h=document.querySelector('[data-act=tab][data-v=aaj]');if(h&&!h.classList.contains('on')){h.click();return true}"
                    + "return false})()";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    new android.window.OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            handleBack();
                        }
                    });
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                if (p.isCaptureEnabled()) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM_CAMERA_FILE);
                    } else {
                        launchCamera();
                    }
                    return true;
                }
                boolean imagesOnly = false;
                String[] acc = p.getAcceptTypes();
                if (acc != null && acc.length > 0) {
                    imagesOnly = true;
                    boolean any = false;
                    for (String a : acc) {
                        if (a == null || a.trim().length() == 0) continue;
                        any = true;
                        if (!a.trim().startsWith("image/")) imagesOnly = false;
                    }
                    if (!any) imagesOnly = false;
                }
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(imagesOnly ? "image/*" : "*/*");
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "File chuno"), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            req.grant(req.getResources());
                        } else {
                            pendingWebPerm = req;
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM_CAMERA_WEB);
                        }
                    }
                });
            }
        });

        web.setDownloadListener(new android.webkit.DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        Reminders.ensureChannel(this);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_PERM_NOTIF);
        }
        Reminders.scheduleAll(this);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("https://" + HOST + "/assets/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "shots");
            dir.mkdirs();
            File f = File.createTempFile("cam", ".jpg", dir);
            camUri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAM);
        } catch (Exception e) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = null;
            toast("Camera nahi khul paya");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCb != null) {
                Uri[] r = null;
                if (res == RESULT_OK) r = WebChromeClient.FileChooserParams.parseResult(res, data);
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        } else if (req == REQ_CAM) {
            if (fileCb != null) {
                fileCb.onReceiveValue(res == RESULT_OK && camUri != null ? new Uri[]{camUri} : null);
                fileCb = null;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (req == REQ_PERM_CAMERA_FILE) {
            if (ok) launchCamera();
            else {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = null;
                toast("Camera ki permission chahiye");
            }
        } else if (req == REQ_PERM_CAMERA_WEB) {
            if (pendingWebPerm != null) {
                if (ok) pendingWebPerm.grant(pendingWebPerm.getResources());
                else pendingWebPerm.deny();
                pendingWebPerm = null;
            }
        }
    }

    private void handleBack() {
        web.evaluateJavascript(BACK_JS, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show();
            }
        });
    }

    /** Functions the web page can call as window.AndroidBridge.xxx */
    public class Bridge {
        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public void setReminders(String json) {
            Reminders.save(MainActivity.this, json);
            Reminders.scheduleAll(MainActivity.this);
        }

        @JavascriptInterface
        public void requestNotifPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_PERM_NOTIF);
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean notifAllowed() {
            android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return nm.areNotificationsEnabled();
        }

        @JavascriptInterface
        public boolean exactAllowed() {
            if (Build.VERSION.SDK_INT < 31) return true;
            android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
            return am.canScheduleExactAlarms();
        }

        @JavascriptInterface
        public void openExactSettings() {
            try {
                Intent i;
                if (Build.VERSION.SDK_INT >= 31) {
                    i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()));
                } else {
                    i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                }
                startActivity(i);
            } catch (Exception e) {
                openAppSettings();
            }
        }

        @JavascriptInterface
        public void openBatterySettings() {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e) {
                openAppSettings();
            }
        }

        @JavascriptInterface
        public void openAppSettings() {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void testAlarm() {
            AlarmReceiver.show(MainActivity.this, "test", "Test alarm", null, true);
        }

        @JavascriptInterface
        public void shareFiles(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                File dir = new File(getCacheDir(), "share");
                dir.mkdirs();
                File[] old = dir.listFiles();
                if (old != null) for (File o : old) o.delete();
                ArrayList<Uri> uris = new ArrayList<Uri>();
                String mime = null;
                for (int k = 0; k < arr.length(); k++) {
                    JSONObject o = arr.getJSONObject(k);
                    String name = safeName(o.getString("n"));
                    byte[] bytes = Base64.decode(o.getString("d"), Base64.DEFAULT);
                    File f = new File(dir, name);
                    FileOutputStream fo = new FileOutputStream(f);
                    fo.write(bytes);
                    fo.close();
                    uris.add(FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f));
                    String m = o.optString("m", "application/octet-stream");
                    if (mime == null) mime = m;
                    else if (!mime.equals(m)) mime = "*/*";
                }
                Intent i;
                if (uris.size() == 1) {
                    i = new Intent(Intent.ACTION_SEND);
                    i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                } else {
                    i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                }
                i.setType(mime == null ? "*/*" : mime);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(i, "Share karo");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(chooser);
            } catch (Exception e) {
                toast("Share nahi ho paya");
            }
        }

        @JavascriptInterface
        public boolean saveFile(String name, String mime, String b64) {
            try {
                String fn = safeName(name);
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, fn);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/study tracker file saver");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (u == null) throw new Exception("no uri");
                    OutputStream os = getContentResolver().openOutputStream(u);
                    os.write(bytes);
                    os.close();
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    dir.mkdirs();
                    FileOutputStream fo = new FileOutputStream(new File(dir, fn));
                    fo.write(bytes);
                    fo.close();
                }
                toast("Downloads/study tracker file saver folder me save ho gaya: " + fn);
                return true;
            } catch (Exception e) {
                toast("File save nahi ho payi");
                return false;
            }
        }

        private String safeName(String n) {
            String r = n == null ? "file" : n.replaceAll("[\\\\/:*?\"<>|]", "_");
            return r.length() == 0 ? "file" : r;
        }
    }
}
