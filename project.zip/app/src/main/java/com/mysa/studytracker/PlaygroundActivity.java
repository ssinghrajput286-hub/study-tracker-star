package com.mysa.studytracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * VEERBHAGYA: the Code-Playground inside CS.
 * Python runs inside the app (Chaquopy). JavaScript runs in a hidden WebView.
 * C, C++, Java, Kotlin and Go run on a free public Judge0 server.
 */
public class PlaygroundActivity extends Activity {

    private static final String PREFS = "playground";
    private static final String KEY_LANG = "lang";
    private static final String KEY_FONT = "font_sp";
    private static final int FONT_MIN = 12;
    private static final int FONT_MAX = 28;
    private static final int FONT_DEFAULT = 17;

    private static final String DEFAULT_PY = "print(\"Hello, World!\")\n";
    private static final String DEFAULT_JS = "console.log(\"Hello, World!\");\n";

    // Languages in the picker. "py" and "js" run on the phone; the rest run on a Judge0 server.
    private static final String[] LANG_IDS = {"py", "js", "c", "cpp", "java", "kt", "go"};
    private static final String[] LANG_NAMES = {
            "Python", "JavaScript", "C", "C++", "Java", "Kotlin", "Go"};
    // Judge0 language numbers. Change here if a language fails with "language not found".
    private static final int[] JUDGE0_IDS = {0, 0, 50, 54, 62, 78, 60};
    private static final String[] STARTERS = {
            DEFAULT_PY,
            DEFAULT_JS,
            "#include <stdio.h>\n\nint main() {\n  printf(\"Hello, World!\\n\");\n  return 0;\n}\n",
            "#include <iostream>\n\nint main() {\n  std::cout << \"Hello, World!\" << std::endl;\n  return 0;\n}\n",
            "public class Main {\n  public static void main(String[] args) {\n    System.out.println(\"Hello, World!\");\n  }\n}\n",
            "fun main() {\n    println(\"Hello, World!\")\n}\n",
            "package main\n\nimport \"fmt\"\n\nfunc main() {\n\tfmt.Println(\"Hello, World!\")\n}\n"};

    private static final String JUDGE0_URL = "https://ce.judge0.com";
    private static final String NOTICE =
            "Online language. Your code is sent to a free public Judge0 server. "
                    + "Use it only for test and practice. Do not put passwords or personal notes in it. "
                    + "Needs internet.";

    private static final int C_KEYWORD = 0xFFC792EA;
    private static final int C_STRING = 0xFFA5D17F;
    private static final int C_NUMBER = 0xFFF2A66B;
    private static final int C_COMMENT = 0xFF6B7280;
    private static final int C_FUNCTION = 0xFF7FB4F5;

    private static final Set<String> PY_WORDS = words(
            "and as assert break class continue def del elif else except False finally for from "
                    + "global if import in is lambda None not or pass raise return True try while with yield");
    private static final Set<String> JS_WORDS = words(
            "async await break case catch class const continue default else export false finally "
                    + "for function if import in let new null return switch this throw true try typeof var while");
    private static final Set<String> C_WORDS = words(
            "auto break case char class const continue default do double else enum extern false "
                    + "float for goto if include int long namespace new private public return short signed "
                    + "sizeof static struct switch template this true typedef union unsigned using void "
                    + "while bool string std");
    private static final Set<String> JAVA_WORDS = words(
            "abstract boolean break case catch char class continue default do double else enum "
                    + "extends false final finally float for if implements import int long new null package "
                    + "private protected public return static super switch this throw true try void while");
    private static final Set<String> KT_WORDS = words(
            "as break class continue do else false for fun if in is null object return super this "
                    + "throw true try val var when while");
    private static final Set<String> GO_WORDS = words(
            "break case chan const continue default defer else for func go if import interface map "
                    + "package range return select struct switch type var");

    private static final Pattern PY_TOKENS = Pattern.compile(
            "(#[^\\n]*)|(\"(?:[^\"\\\\\\n]|\\\\.)*\"?|'(?:[^'\\\\\\n]|\\\\.)*'?)"
                    + "|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)");
    private static final Pattern SLASH_TOKENS = Pattern.compile(
            "(//[^\\n]*)|(\"(?:[^\"\\\\\\n]|\\\\.)*\"?|'(?:[^'\\\\\\n]|\\\\.)*'?)"
                    + "|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)");

    private static final String[] KEYS = {
            "TAB", "(", ")", "\"", "'", ":", "=", "[", "]", "{", "}",
            "<", ">", "/", ";", ".", ",", "#", "+", "-", "*", "%", "_", "&", "|", "!", "?", "@"
    };

    private EditText editor;
    private TextView gutter;
    private TextView output;
    private TextView runTime;
    private TextView langChip;
    private TextView subtitle;
    private TextView notice;
    private LinearLayout inputBox;
    private EditText stdin;
    private SharedPreferences prefs;
    private String lang = "py";
    private String lastName = "";
    private int fontSp = FONT_DEFAULT;
    private long startedAt;

    private static Set<String> words(String list) {
        return new HashSet<String>(Arrays.asList(list.split(" ")));
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.SURFACE_2);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        lang = prefs.getString(KEY_LANG, "py");
        if (indexOfLang(lang) < 0) lang = "py";
        fontSp = Math.max(FONT_MIN, Math.min(FONT_MAX, prefs.getInt(KEY_FONT, FONT_DEFAULT)));

        // Opened from CS > Saved Code: show that program.
        Intent in = getIntent();
        String openLang = in.getStringExtra("lang");
        if (openLang != null && indexOfLang(openLang) >= 0 && in.getStringExtra("code") != null) {
            lang = openLang;
            lastName = in.getStringExtra("name") == null ? "" : in.getStringExtra("name");
            prefs.edit().putString("code_" + lang, in.getStringExtra("code"))
                    .putString(KEY_LANG, lang).apply();
        }

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        langChip = Ui.chip(this, "", 0x33FFFFFF, Color.WHITE);
        langChip.setContentDescription("Change language");
        langChip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLanguagePicker();
            }
        });
        TextView gear = Ui.text(this, "⚙", 26, Color.WHITE, false);
        gear.setGravity(Gravity.CENTER);
        gear.setContentDescription("Settings and notes");
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PlaygroundActivity.this, PlaygroundSettingsActivity.class));
            }
        });
        LinearLayout header = Ui.header(this, "VEERBHAGYA", "Code-Playground", langChip, gear);
        subtitle = (TextView) header.findViewWithTag("sub");
        root.addView(header);

        notice = Ui.text(this, NOTICE, 12, Ui.WARN, false);
        notice.setBackgroundColor(0xFF3A3220);
        notice.setPadding(dp(14), dp(8), dp(14), dp(8));
        root.addView(notice);

        root.addView(buildActionRow());
        root.addView(buildInputBox());
        root.addView(buildEditor(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 3f));
        root.addView(buildKeyBar());
        root.addView(buildOutput(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 2f));

        setContentView(root);
        loadCode();
    }

    // ---------- Screen parts ----------

    private View buildActionRow() {
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setBackgroundColor(Ui.BG);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(6));

        addAction(row, "💾 Save", new Runnable() {
            @Override public void run() { showSaveDialog(); }
        });
        addAction(row, "↗ Share", new Runnable() {
            @Override public void run() { shareCode(); }
        });
        addAction(row, "⌨ Input", new Runnable() {
            @Override public void run() {
                inputBox.setVisibility(inputBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        addAction(row, "A−", new Runnable() {
            @Override public void run() { setFont(fontSp - 1); }
        });
        addAction(row, "A+", new Runnable() {
            @Override public void run() { setFont(fontSp + 1); }
        });
        addAction(row, "⌫ Clear", new Runnable() {
            @Override public void run() { confirmClear(); }
        });
        scroller.addView(row);
        return scroller;
    }

    private void addAction(LinearLayout row, String label, final Runnable action) {
        TextView c = Ui.chip(this, label, Ui.SURFACE_2, Ui.TEXT);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(8);
        row.addView(c, lp);
    }

    private View buildInputBox() {
        inputBox = new LinearLayout(this);
        inputBox.setOrientation(LinearLayout.VERTICAL);
        inputBox.setVisibility(View.GONE);
        inputBox.setPadding(dp(12), dp(4), dp(12), dp(8));
        inputBox.addView(Ui.text(this,
                "INPUT for your program (what input(), scanf or cin will read)", 11, Ui.MUTED, true));
        stdin = new EditText(this);
        stdin.setTextColor(Ui.TEXT);
        stdin.setTypeface(Typeface.MONOSPACE);
        stdin.setTextSize(15);
        stdin.setHint("Type the input here, one line per value");
        stdin.setHintTextColor(Ui.MUTED);
        stdin.setMinLines(2);
        stdin.setMaxLines(4);
        stdin.setGravity(Gravity.TOP | Gravity.START);
        stdin.setBackground(Ui.card(this, Ui.SURFACE, 12));
        stdin.setPadding(dp(12), dp(10), dp(12), dp(10));
        stdin.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        inputBox.addView(stdin, lp);
        return inputBox;
    }

    private View buildEditor() {
        FrameShell shell = new FrameShell(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(Ui.card(this, Ui.SURFACE, 14));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        gutter = new TextView(this);
        gutter.setTypeface(Typeface.MONOSPACE);
        gutter.setTextColor(Ui.MUTED);
        gutter.setGravity(Gravity.TOP | Gravity.END);
        gutter.setBackgroundColor(Ui.SURFACE_2);
        gutter.setPadding(dp(10), dp(12), dp(10), dp(12));
        gutter.setMinWidth(dp(40));
        row.addView(gutter, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        editor = new EditText(this);
        editor.setBackgroundColor(Color.TRANSPARENT);
        editor.setTextColor(Ui.TEXT);
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setPadding(dp(12), dp(12), dp(12), dp(12));
        editor.setHorizontallyScrolling(true);
        editor.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        editor.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(Editable s) {
                prefs.edit().putString("code_" + lang, s.toString()).apply();
                highlight(s);
                updateGutter(s);
            }
        });
        row.addView(editor, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        scroll.addView(row, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        shell.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        applyFont();
        return shell;
    }

    /** Adds a little margin around the editor card. */
    private static class FrameShell extends LinearLayout {
        FrameShell(Context c) {
            super(c);
            setOrientation(VERTICAL);
            int m = Ui.dp(c, 12);
            setPadding(m, Ui.dp(c, 4), m, Ui.dp(c, 8));
        }
    }

    private View buildKeyBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(Ui.SURFACE_2);

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        for (final String k : KEYS) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextColor(Ui.TEXT);
            b.setTextSize(17);
            b.setTypeface(Typeface.MONOSPACE);
            b.setBackgroundColor(Color.TRANSPARENT);
            b.setMinWidth(0);
            b.setMinimumWidth(dp(52));
            b.setFocusable(false);
            b.setFocusableInTouchMode(false);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    insertKey(k);
                }
            });
            keys.addView(b, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(56)));
        }
        scroller.addView(keys);
        row.addView(scroller, new LinearLayout.LayoutParams(0, dp(56), 1f));

        TextView run = Ui.chip(this, "RUN ▶", Ui.GREEN, 0xFF0B2A14);
        run.setTextSize(16);
        run.setPadding(dp(22), dp(10), dp(22), dp(10));
        run.setContentDescription("Run code");
        run.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runCode();
            }
        });
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.leftMargin = dp(6);
        rlp.rightMargin = dp(10);
        row.addView(run, rlp);
        return row;
    }

    private View buildOutput() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Ui.BG);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(16), dp(10), dp(12), dp(6));
        TextView title = Ui.text(this, "OUTPUT", 13, Ui.TEXT, true);
        title.setLetterSpacing(0.1f);
        head.addView(title);
        runTime = Ui.text(this, "", 12, Ui.MUTED, false);
        runTime.setPadding(dp(10), 0, 0, 0);
        head.addView(runTime, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView copy = Ui.chip(this, "Copy", Ui.SURFACE_2, Ui.TEXT);
        copy.setTextSize(12);
        copy.setPadding(dp(12), dp(5), dp(12), dp(5));
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("output", output.getText()));
                Toast.makeText(PlaygroundActivity.this, "Output copied", Toast.LENGTH_SHORT).show();
            }
        });
        head.addView(copy);
        box.addView(head);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(Ui.card(this, Ui.SURFACE, 14));
        output = new TextView(this);
        output.setTypeface(Typeface.MONOSPACE);
        output.setTextSize(15);
        output.setTextColor(Ui.MUTED);
        output.setTextIsSelectable(true);
        output.setPadding(dp(14), dp(12), dp(14), dp(12));
        output.setText("Press RUN to see the result here.");
        scroll.addView(output);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.leftMargin = dp(12);
        lp.rightMargin = dp(12);
        lp.bottomMargin = dp(10);
        box.addView(scroll, lp);
        return box;
    }

    // ---------- Language and saved code ----------

    private int indexOfLang(String id) {
        for (int i = 0; i < LANG_IDS.length; i++) {
            if (LANG_IDS[i].equals(id)) return i;
        }
        return -1;
    }

    private boolean isOnline() {
        return JUDGE0_IDS[indexOfLang(lang)] != 0;
    }

    private void loadCode() {
        int idx = indexOfLang(lang);
        langChip.setText(LANG_NAMES[idx] + " ▾");
        subtitle.setText("Code-Playground  ·  " + LANG_NAMES[idx]);
        notice.setVisibility(isOnline() ? View.VISIBLE : View.GONE);
        String saved = prefs.getString("code_" + lang, null);
        if (saved == null && "py".equals(lang)) {
            saved = prefs.getString("code", null);   // from the first version of the screen
        }
        editor.setText(saved != null ? saved : STARTERS[idx]);
        output.setTextColor(Ui.MUTED);
        output.setText("Press RUN to see the result here.");
        runTime.setText("");
    }

    private void showLanguagePicker() {
        new AlertDialog.Builder(this)
                .setTitle("Choose a language")
                .setItems(LANG_NAMES, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit().putString("code_" + lang, editor.getText().toString()).apply();
                        lang = LANG_IDS[which];
                        lastName = "";
                        prefs.edit().putString(KEY_LANG, lang).apply();
                        loadCode();
                    }
                })
                .show();
    }

    private Set<String> wordsFor(String id) {
        switch (id) {
            case "py": return PY_WORDS;
            case "js": return JS_WORDS;
            case "java": return JAVA_WORDS;
            case "kt": return KT_WORDS;
            case "go": return GO_WORDS;
            default: return C_WORDS;
        }
    }

    // ---------- Font size, line numbers, syntax colors ----------

    private void setFont(int sp) {
        fontSp = Math.max(FONT_MIN, Math.min(FONT_MAX, sp));
        prefs.edit().putInt(KEY_FONT, fontSp).apply();
        applyFont();
        Toast.makeText(this, "Text size " + fontSp, Toast.LENGTH_SHORT).show();
    }

    private void applyFont() {
        editor.setTextSize(fontSp);
        gutter.setTextSize(fontSp);
    }

    private void updateGutter(Editable s) {
        int lines = 1;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '\n') lines++;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            sb.append(i);
            if (i < lines) sb.append('\n');
        }
        gutter.setText(sb.toString());
    }

    private void highlight(Editable s) {
        ForegroundColorSpan[] old = s.getSpans(0, s.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan span : old) {
            s.removeSpan(span);
        }
        if (s.length() > 20000) return;   // keep typing smooth on very long code

        Set<String> words = wordsFor(lang);
        Matcher m = ("py".equals(lang) ? PY_TOKENS : SLASH_TOKENS).matcher(s);
        while (m.find()) {
            int color;
            if (m.group(1) != null) {
                color = C_COMMENT;
            } else if (m.group(2) != null) {
                color = C_STRING;
            } else if (m.group(3) != null) {
                color = C_NUMBER;
            } else {
                String word = m.group(4);
                if (words.contains(word)) {
                    color = C_KEYWORD;
                } else if (m.end() < s.length() && s.charAt(m.end()) == '(') {
                    color = C_FUNCTION;
                } else {
                    continue;
                }
            }
            s.setSpan(new ForegroundColorSpan(color), m.start(), m.end(),
                    Editable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    // ---------- Key bar ----------

    private void insertKey(String key) {
        int start = Math.max(editor.getSelectionStart(), 0);
        int end = Math.max(editor.getSelectionEnd(), start);
        String text;
        boolean pair = false;
        switch (key) {
            case "TAB": text = "  "; break;
            case "(": text = "()"; pair = true; break;
            case "[": text = "[]"; pair = true; break;
            case "{": text = "{}"; pair = true; break;
            case "\"": text = "\"\""; pair = true; break;
            case "'": text = "''"; pair = true; break;
            default: text = key;
        }
        editor.getText().replace(start, end, text);
        editor.setSelection(pair ? start + 1 : start + text.length());
    }

    // ---------- Save, share, clear ----------

    private void showSaveDialog() {
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Name, e.g. Add two numbers");
        name.setText(lastName);
        name.setSelection(name.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("Save in CS > Saved Code")
                .setView(name)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String n = name.getText().toString().trim();
                        if (n.isEmpty()) n = "Untitled";
                        lastName = n;
                        CodeStore.save(PlaygroundActivity.this, n, lang, editor.getText().toString());
                        Toast.makeText(PlaygroundActivity.this,
                                "Saved in CS > Saved Code", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void shareCode() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, editor.getText().toString());
        startActivity(Intent.createChooser(send, "Share code"));
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Clear all code?")
                .setMessage("The editor will be empty. Save it first if you want to keep it.")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        editor.setText("");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- Running code ----------

    private void showResult(String text, boolean isError) {
        output.setTextColor(isError ? Ui.ERR : Ui.TEXT);
        output.setText(text.isEmpty() ? "(no output)" : text);
        double secs = (System.nanoTime() - startedAt) / 1e9;
        runTime.setText(String.format(Locale.US, "%s in %.2f s", isError ? "Stopped" : "Ran", secs));
    }

    private void runCode() {
        final String code = editor.getText().toString();
        final String input = stdin.getText().toString();
        output.setTextColor(Ui.MUTED);
        output.setText("Running...");
        runTime.setText("");
        startedAt = System.nanoTime();
        if ("js".equals(lang)) {
            runJavaScript(code);
        } else if (isOnline()) {
            runOnline(code, input, JUDGE0_IDS[indexOfLang(lang)]);
        } else {
            runPython(code, input);
        }
    }

    private void runPython(final String code, final String input) {
        // Run off the main thread so the screen never freezes.
        new Thread(new Runnable() {
            @Override
            public void run() {
                String result;
                boolean failed = false;
                try {
                    result = Python.getInstance().getModule("runner")
                            .callAttr("run", code, input).toString();
                } catch (Exception e) {
                    result = String.valueOf(e.getMessage());
                    failed = true;
                }
                final String shown = result;
                final boolean isErr = failed;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showResult(shown, isErr);
                    }
                });
            }
        }).start();
    }

    private void runJavaScript(String code) {
        final WebView wv = new WebView(this);
        wv.getSettings().setJavaScriptEnabled(true);
        final String script =
                "(function(){var out=[];"
                        + "var f=function(a){return Array.prototype.slice.call(a).map(function(x){"
                        + "try{return (typeof x==='object'&&x!==null)?JSON.stringify(x):String(x)}"
                        + "catch(e){return String(x)}}).join(' ')};"
                        + "var c={log:function(){out.push(f(arguments))},"
                        + "error:function(){out.push(f(arguments))},"
                        + "warn:function(){out.push(f(arguments))}};"
                        + "try{(new Function('console'," + JSONObject.quote(code) + "))(c)}"
                        + "catch(e){out.push('');out.push(e.name+': '+e.message)}"
                        + "return out.join('\\n')})()";
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(script, new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        String text;
                        boolean failed;
                        try {
                            text = new JSONArray("[" + value + "]").getString(0);
                            failed = text.contains("Error: ");
                        } catch (Exception e) {
                            text = "Could not read the result.";
                            failed = true;
                        }
                        showResult(text, failed);
                        wv.destroy();
                    }
                });
            }
        });
        wv.loadDataWithBaseURL(null, "<html><body></body></html>", "text/html", "utf-8", null);
    }

    // ---------- Online languages (Judge0) ----------

    private static String b64(String s) {
        return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
    }

    private static String unb64(String s) {
        if (s == null || s.isEmpty() || "null".equals(s)) return "";
        return new String(Base64.decode(s, Base64.DEFAULT), StandardCharsets.UTF_8);
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toString("UTF-8");
    }

    private void runOnline(final String code, final String input, final int languageId) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String text;
                boolean failed = false;
                try {
                    // 1. send the code
                    JSONObject body = new JSONObject();
                    body.put("source_code", b64(code));
                    body.put("language_id", languageId);
                    body.put("stdin", b64(input));
                    URL create = new URL(JUDGE0_URL + "/submissions?base64_encoded=true&wait=false");
                    HttpURLConnection c = (HttpURLConnection) create.openConnection();
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(15000);
                    c.setRequestMethod("POST");
                    c.setRequestProperty("Content-Type", "application/json");
                    c.setDoOutput(true);
                    OutputStream os = c.getOutputStream();
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                    os.close();
                    int status = c.getResponseCode();
                    if (status == 429) {
                        throw new Exception("The free server is busy right now (too many requests). Wait a minute and try again.");
                    }
                    if (status >= 400) {
                        throw new Exception("The server refused the request (error " + status + ").");
                    }
                    String token = new JSONObject(readAll(c.getInputStream())).getString("token");

                    // 2. ask for the result until it is ready (up to about 30 seconds)
                    JSONObject result = null;
                    for (int i = 0; i < 30; i++) {
                        Thread.sleep(1000);
                        URL poll = new URL(JUDGE0_URL + "/submissions/" + token
                                + "?base64_encoded=true&fields=stdout,stderr,compile_output,message,status");
                        HttpURLConnection p = (HttpURLConnection) poll.openConnection();
                        p.setConnectTimeout(10000);
                        p.setReadTimeout(15000);
                        if (p.getResponseCode() >= 400) continue;
                        JSONObject r = new JSONObject(readAll(p.getInputStream()));
                        int id = r.getJSONObject("status").getInt("id");
                        if (id > 2) {   // 1 = in queue, 2 = running
                            result = r;
                            break;
                        }
                    }
                    if (result == null) {
                        throw new Exception("The server took too long. Try again.");
                    }

                    StringBuilder sb = new StringBuilder();
                    sb.append(unb64(result.optString("stdout", "")));
                    String compile = unb64(result.optString("compile_output", ""));
                    String stderr = unb64(result.optString("stderr", ""));
                    String message = unb64(result.optString("message", ""));
                    if (!compile.isEmpty()) sb.append(compile);
                    if (!stderr.isEmpty()) sb.append(stderr);
                    if (!message.isEmpty()) sb.append(message);
                    int statusId = result.getJSONObject("status").getInt("id");
                    failed = statusId != 3;
                    if (failed && sb.length() == 0) {
                        sb.append(result.getJSONObject("status").optString("description", "Error"));
                    }
                    text = sb.toString();
                } catch (java.net.UnknownHostException e) {
                    text = "No internet. Online languages need a connection.";
                    failed = true;
                } catch (Exception e) {
                    text = String.valueOf(e.getMessage());
                    failed = true;
                }
                final String shown = text;
                final boolean isErr = failed;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showResult(shown, isErr);
                    }
                });
            }
        }).start();
    }
}
