package com.mysa.studytracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * VEERBHAGYA: the Code-Playground inside CS.
 * Python runs inside the app (Chaquopy). JavaScript runs in a hidden WebView.
 * C, C++, Java, Kotlin and Go run on a free public Judge0 server.
 */
public class PlaygroundActivity extends Activity {

    private static final String PREFS = "playground";
    private static final String KEY_LANG = "lang";
    private static final String KEY_FONT = "font_sp";
    private static final int FONT_MIN = 12;
    private static final int FONT_MAX = 28;
    private static final int FONT_DEFAULT = 17;

    private static final String DEFAULT_PY = "print(\"Hello, World!\")\n";
    private static final String DEFAULT_JS = "console.log(\"Hello, World!\");\n";

    // Languages in the picker. "py", "js" and "web" run on the phone; the rest run on a Judge0 server.
    private static final String[] LANG_IDS = {
            "py", "js", "web", "c", "cpp", "cs", "java", "kt", "go", "rb", "php", "swift", "r", "rs", "ts"};
    private static final String[] LANG_NAMES = {
            "Python", "JavaScript", "Web (HTML)", "C", "C++", "C#", "Java", "Kotlin", "Go",
            "Ruby", "PHP", "Swift", "R", "Rust", "TypeScript"};
    // Judge0 language numbers, used if the server's language list cannot be read. 0 = runs on the phone.
    private static final int[] JUDGE0_FALLBACK = {0, 0, 0, 50, 54, 51, 62, 78, 60, 72, 68, 83, 80, 73, 74};
    // The start of each language's name in Judge0's list, used to find the right number.
    private static final String[] JUDGE0_PREFIX = {
            "", "", "", "C (GCC", "C++ (GCC", "C# (", "Java (", "Kotlin", "Go (", "Ruby", "PHP",
            "Swift", "R (", "Rust", "TypeScript"};
    private static final String[] STARTERS = {
            DEFAULT_PY,
            DEFAULT_JS,
            "<h1>Hello, World!</h1>\n<p>Edit this and press RUN.</p>\n",
            "#include <stdio.h>\n\nint main() {\n  printf(\"Hello, World!\\n\");\n  return 0;\n}\n",
            "#include <iostream>\n\nint main() {\n  std::cout << \"Hello, World!\" << std::endl;\n  return 0;\n}\n",
            "using System;\n\nclass Program {\n    static void Main() {\n        Console.WriteLine(\"Hello, World!\");\n    }\n}\n",
            "public class Main {\n  public static void main(String[] args) {\n    System.out.println(\"Hello, World!\");\n  }\n}\n",
            "fun main() {\n    println(\"Hello, World!\")\n}\n",
            "package main\n\nimport \"fmt\"\n\nfunc main() {\n\tfmt.Println(\"Hello, World!\")\n}\n",
            "puts \"Hello, World!\"\n",
            "<?php\necho \"Hello, World!\\n\";\n",
            "print(\"Hello, World!\")\n",
            "print(\"Hello, World!\")\n",
            "fn main() {\n    println!(\"Hello, World!\");\n}\n",
            "console.log(\"Hello, World!\");\n"};

    // The second address is tried if the first one fails.
    private static final String[] JUDGE0_HOSTS = {"https://ce.judge0.com", "https://api.judge0.com"};
    private static JSONArray judge0Languages;   // read once, then reused
    private static final String NOTICE =
            "Online language. Your code is sent to a free public Judge0 server. "
                    + "Use it only for test and practice. Do not put passwords or personal notes in it. "
                    + "Needs internet.";

    private static final int C_KEYWORD = 0xFFC792EA;
    private static final int C_STRING = 0xFFA5D17F;
    private static final int C_NUMBER = 0xFFF2A66B;
    private static final int C_COMMENT = 0xFF6B7280;
    private static final int C_FUNCTION = 0xFF7FB4F5;

    private static final Set<String> PY_WORDS = words(
            "and as assert break class continue def del elif else except False finally for from "
                    + "global if import in is lambda None not or pass raise return True try while with yield");
    private static final Set<String> JS_WORDS = words(
            "async await break case catch class const continue default else export false finally "
                    + "for function if import in let new null return switch this throw true try typeof var while");
    private static final Set<String> C_WORDS = words(
            "auto break case char class const continue default do double else enum extern false "
                    + "float for goto if include int long namespace new private public return short signed "
                    + "sizeof static struct switch template this true typedef union unsigned using void "
                    + "while bool string std");
    private static final Set<String> JAVA_WORDS = words(
            "abstract boolean break case catch char class continue default do double else enum "
                    + "extends false final finally float for if implements import int long new null package "
                    + "private protected public return static super switch this throw true try void while");
    private static final Set<String> KT_WORDS = words(
            "as break class continue do else false for fun if in is null object return super this "
                    + "throw true try val var when while");
    private static final Set<String> GO_WORDS = words(
            "break case chan const continue default defer else for func go if import interface map "
                    + "package range return select struct switch type var");

    private static final Set<String> CS_WORDS = words(
            "abstract as base bool break case catch char class const continue decimal default do double "
                    + "else enum false finally float for foreach if in int interface long namespace new null "
                    + "object out private protected public readonly ref return static string struct switch "
                    + "this throw true try using var void while");
    private static final Set<String> RB_WORDS = words(
            "alias and begin break case class def defined do else elsif end ensure false for if in module "
                    + "next nil not or redo rescue retry return self super then true undef unless until when "
                    + "while yield puts");
    private static final Set<String> PHP_WORDS = words(
            "abstract and array as break case catch class clone const continue default do echo else elseif "
                    + "empty extends false final finally for foreach function if implements include interface "
                    + "isset namespace new null or print private protected public require return static switch "
                    + "this throw true try use var while");
    private static final Set<String> SWIFT_WORDS = words(
            "as break case catch class continue default defer do else enum extension false for func guard "
                    + "if import in init let nil private public repeat return self static struct switch throw "
                    + "true try var where while");
    private static final Set<String> R_WORDS = words(
            "break else FALSE for function if in Inf NA NULL repeat return TRUE while");
    private static final Set<String> RS_WORDS = words(
            "as break const continue crate else enum false fn for if impl in let loop match mod move mut "
                    + "pub ref return self Self static struct super trait true type unsafe use where while");
    private static final Set<String> TS_WORDS = words(
            "any async await boolean break case catch class const continue default else enum export false "
                    + "finally for function if implements import in interface let new null number private "
                    + "public readonly return string switch this throw true try type typeof var while");

    private static final Pattern WEB_TOKENS = Pattern.compile(
            "(<!--[\\s\\S]*?-->)|(\"[^\"\\n]*\"?|'[^'\\n]*'?)|(\\b\\d+(?:\\.\\d+)?\\b)"
                    + "|(</?[A-Za-z][A-Za-z0-9-]*|/?>)");
    private static final Pattern PY_TOKENS = Pattern.compile(
            "(#[^\\n]*)|(\"(?:[^\"\\\\\\n]|\\\\.)*\"?|'(?:[^'\\\\\\n]|\\\\.)*'?)"
                    + "|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)");
    private static final Pattern SLASH_TOKENS = Pattern.compile(
            "(//[^\\n]*)|(\"(?:[^\"\\\\\\n]|\\\\.)*\"?|'(?:[^'\\\\\\n]|\\\\.)*'?)"
                    + "|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)");

    private static final String[] KEYS = {
            "TAB", "(", ")", "\"", "'", ":", "=", "[", "]", "{", "}",
            "<", ">", "/", ";", ".", ",", "#", "+", "-", "*", "%", "_", "&", "|", "!", "?", "@"
    };

    private EditText editor;
    private TextView gutter;
    private TextView output;
    private TextView runTime;
    private TextView langChip;
    private TextView subtitle;
    private TextView notice;
    private LinearLayout inputBox;
    private EditText stdin;
    private SharedPreferences prefs;
    private String lang = "py";
    private String lastName = "";
    private int fontSp = FONT_DEFAULT;
    private long startedAt;
    private ScrollView outScroll;
    private TextView examplesChip;
    private TextView fullChip;
    private WebView preview;        // shows the page for Web (HTML)
    private WebView jsView;         // hidden page that runs JavaScript
    private int runId = 0;          // changes on every run, so late results can be ignored
    private boolean running = false;
    private int errLine = 0;               // 1-based line of the last error, 0 = none
    private ScrollView editScroll;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private static Set<String> words(String list) {
        return new HashSet<String>(Arrays.asList(list.split(" ")));
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.SURFACE_2);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        lang = prefs.getString(KEY_LANG, "py");
        if (indexOfLang(lang) < 0) lang = "py";
        fontSp = Math.max(FONT_MIN, Math.min(FONT_MAX, prefs.getInt(KEY_FONT, FONT_DEFAULT)));

        // Opened from CS > Saved Code: show that program.
        Intent in = getIntent();
        String openLang = in.getStringExtra("lang");
        if (openLang != null && indexOfLang(openLang) >= 0 && in.getStringExtra("code") != null) {
            lang = openLang;
            lastName = in.getStringExtra("name") == null ? "" : in.getStringExtra("name");
            prefs.edit().putString("code_" + lang, in.getStringExtra("code"))
                    .putString(KEY_LANG, lang).apply();
        }

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        langChip = Ui.chip(this, "", 0x33FFFFFF, Color.WHITE);
        langChip.setContentDescription("Change language");
        langChip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLanguagePicker();
            }
        });
        TextView gear = Ui.text(this, "⚙", 26, Color.WHITE, false);
        gear.setGravity(Gravity.CENTER);
        gear.setContentDescription("Settings and notes");
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PlaygroundActivity.this, PlaygroundSettingsActivity.class));
            }
        });
        LinearLayout header = Ui.header(this, "VEERBHAGYA", "Code-Playground", langChip, gear);
        subtitle = (TextView) header.findViewWithTag("sub");
        root.addView(header);

        notice = Ui.text(this, NOTICE, 12, Ui.WARN, false);
        notice.setBackgroundColor(0xFF3A3220);
        notice.setPadding(dp(14), dp(8), dp(14), dp(8));
        root.addView(notice);

        root.addView(buildActionRow());
        root.addView(buildInputBox());
        root.addView(buildEditor(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 3f));
        root.addView(buildKeyBar());
        root.addView(buildOutput(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 2f));

        setContentView(root);
        loadCode();
    }

    // ---------- Screen parts ----------

    private View buildActionRow() {
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setBackgroundColor(Ui.BG);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(6));

        addAction(row, "💾 Save", new Runnable() {
            @Override public void run() { showSaveDialog(); }
        });
        addAction(row, "↗ Share", new Runnable() {
            @Override public void run() { shareCode(); }
        });
        addAction(row, "⌨ Input", new Runnable() {
            @Override public void run() {
                inputBox.setVisibility(inputBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        addAction(row, "A−", new Runnable() {
            @Override public void run() { setFont(fontSp - 1); }
        });
        addAction(row, "A+", new Runnable() {
            @Override public void run() { setFont(fontSp + 1); }
        });
        addAction(row, "⌫ Clear", new Runnable() {
            @Override public void run() { confirmClear(); }
        });
        examplesChip = addAction(row, "\u2605 Examples", new Runnable() {
            @Override public void run() { showExamples(); }
        });
        fullChip = addAction(row, "\u26F6 Full screen", new Runnable() {
            @Override public void run() { openFullScreen(); }
        });
        scroller.addView(row);
        return scroller;
    }

    private TextView addAction(LinearLayout row, String label, final Runnable action) {
        TextView c = Ui.chip(this, label, Ui.SURFACE_2, Ui.TEXT);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(8);
        row.addView(c, lp);
        return c;
    }

    private View buildInputBox() {
        inputBox = new LinearLayout(this);
        inputBox.setOrientation(LinearLayout.VERTICAL);
        inputBox.setVisibility(View.GONE);
        inputBox.setPadding(dp(12), dp(4), dp(12), dp(8));
        inputBox.addView(Ui.text(this,
                "INPUT for your program (what input(), scanf or cin will read)", 11, Ui.MUTED, true));
        stdin = new EditText(this);
        stdin.setTextColor(Ui.TEXT);
        stdin.setTypeface(Typeface.MONOSPACE);
        stdin.setTextSize(15);
        stdin.setHint("Type the input here, one line per value");
        stdin.setHintTextColor(Ui.MUTED);
        stdin.setMinLines(2);
        stdin.setMaxLines(4);
        stdin.setGravity(Gravity.TOP | Gravity.START);
        stdin.setBackground(Ui.card(this, Ui.SURFACE, 12));
        stdin.setPadding(dp(12), dp(10), dp(12), dp(10));
        stdin.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        inputBox.addView(stdin, lp);
        return inputBox;
    }

    private View buildEditor() {
        FrameShell shell = new FrameShell(this);

        ScrollView scroll = new ScrollView(this);
        editScroll = scroll;
        scroll.setFillViewport(true);
        scroll.setBackground(Ui.card(this, Ui.SURFACE, 14));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        gutter = new TextView(this);
        gutter.setTypeface(Typeface.MONOSPACE);
        gutter.setTextColor(Ui.MUTED);
        gutter.setGravity(Gravity.TOP | Gravity.END);
        gutter.setBackgroundColor(Ui.SURFACE_2);
        gutter.setPadding(dp(10), dp(12), dp(10), dp(12));
        gutter.setMinWidth(dp(40));
        row.addView(gutter, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        editor = new EditText(this);
        editor.setBackgroundColor(Color.TRANSPARENT);
        editor.setTextColor(Ui.TEXT);
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setPadding(dp(12), dp(12), dp(12), dp(12));
        editor.setHorizontallyScrolling(true);
        editor.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        editor.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(Editable s) {
                prefs.edit().putString("code_" + lang, s.toString()).apply();
                if (errLine != 0) clearErrorMark(s);
                highlight(s);
                updateGutter(s);
            }
        });
        row.addView(editor, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        scroll.addView(row, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        shell.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        applyFont();
        return shell;
    }

    /** Adds a little margin around the editor card. */
    private static class FrameShell extends LinearLayout {
        FrameShell(Context c) {
            super(c);
            setOrientation(VERTICAL);
            int m = Ui.dp(c, 12);
            setPadding(m, Ui.dp(c, 4), m, Ui.dp(c, 8));
        }
    }

    private View buildKeyBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(Ui.SURFACE_2);

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        for (final String k : KEYS) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextColor(Ui.TEXT);
            b.setTextSize(17);
            b.setTypeface(Typeface.MONOSPACE);
            b.setBackgroundColor(Color.TRANSPARENT);
            b.setMinWidth(0);
            b.setMinimumWidth(dp(52));
            b.setFocusable(false);
            b.setFocusableInTouchMode(false);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    insertKey(k);
                }
            });
            keys.addView(b, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(56)));
        }
        scroller.addView(keys);
        row.addView(scroller, new LinearLayout.LayoutParams(0, dp(56), 1f));

        TextView run = Ui.chip(this, "RUN ▶", Ui.GREEN, 0xFF0B2A14);
        run.setTextSize(16);
        run.setPadding(dp(22), dp(10), dp(22), dp(10));
        run.setContentDescription("Run code");
        run.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runCode();
            }
        });
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.leftMargin = dp(6);
        rlp.rightMargin = dp(10);
        row.addView(run, rlp);
        return row;
    }

    private View buildOutput() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Ui.BG);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(16), dp(10), dp(12), dp(6));
        TextView title = Ui.text(this, "OUTPUT", 13, Ui.TEXT, true);
        title.setLetterSpacing(0.1f);
        head.addView(title);
        runTime = Ui.text(this, "", 12, Ui.MUTED, false);
        runTime.setPadding(dp(10), 0, 0, 0);
        head.addView(runTime, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView copy = Ui.chip(this, "Copy", Ui.SURFACE_2, Ui.TEXT);
        copy.setTextSize(12);
        copy.setPadding(dp(12), dp(5), dp(12), dp(5));
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("output", output.getText()));
                Toast.makeText(PlaygroundActivity.this, "Output copied", Toast.LENGTH_SHORT).show();
            }
        });
        head.addView(copy);
        box.addView(head);

        ScrollView scroll = new ScrollView(this);
        outScroll = scroll;
        scroll.setBackground(Ui.card(this, Ui.SURFACE, 14));
        output = new TextView(this);
        output.setTypeface(Typeface.MONOSPACE);
        output.setTextSize(15);
        output.setTextColor(Ui.MUTED);
        output.setTextIsSelectable(true);
        output.setPadding(dp(14), dp(12), dp(14), dp(12));
        output.setText("Press RUN to see the result here.");
        scroll.addView(output);

        FrameLayout holder = new FrameLayout(this);
        holder.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        preview = new WebView(this);
        preview.getSettings().setJavaScriptEnabled(true);
        preview.getSettings().setAllowFileAccess(false);
        preview.setWebViewClient(new WebViewClient());
        preview.setWebChromeClient(new android.webkit.WebChromeClient());
        preview.setBackgroundColor(Color.WHITE);
        preview.setVisibility(View.GONE);
        holder.addView(preview, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.leftMargin = dp(12);
        lp.rightMargin = dp(12);
        lp.bottomMargin = dp(10);
        box.addView(holder, lp);
        return box;
    }

    // ---------- Language and saved code ----------

    private int indexOfLang(String id) {
        for (int i = 0; i < LANG_IDS.length; i++) {
            if (LANG_IDS[i].equals(id)) return i;
        }
        return -1;
    }

    private boolean isOnline() {
        return JUDGE0_FALLBACK[indexOfLang(lang)] != 0;
    }

    private void loadCode() {
        int idx = indexOfLang(lang);
        langChip.setText(LANG_NAMES[idx] + " ▾");
        subtitle.setText("Code-Playground  ·  " + LANG_NAMES[idx]);
        notice.setVisibility(isOnline() ? View.VISIBLE : View.GONE);
        String saved = prefs.getString("code_" + lang, null);
        if (saved == null && "py".equals(lang)) {
            saved = prefs.getString("code", null);   // from the first version of the screen
        }
        editor.setText(saved != null ? saved : STARTERS[idx]);
        output.setTextColor(Ui.MUTED);
        output.setText("Press RUN to see the result here.");
        runTime.setText("");
        runId++;            // forget any run that was still going
        running = false;
        outScroll.setVisibility(View.VISIBLE);
        preview.setVisibility(View.GONE);
        boolean web = "web".equals(lang);   // these two buttons are only for Web (HTML)
        examplesChip.setVisibility(web ? View.VISIBLE : View.GONE);
        fullChip.setVisibility(web ? View.VISIBLE : View.GONE);
    }

    private void showLanguagePicker() {
        new AlertDialog.Builder(this)
                .setTitle("Choose a language")
                .setItems(LANG_NAMES, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit().putString("code_" + lang, editor.getText().toString()).apply();
                        lang = LANG_IDS[which];
                        lastName = "";
                        prefs.edit().putString(KEY_LANG, lang).apply();
                        loadCode();
                    }
                })
                .show();
    }

    private Set<String> wordsFor(String id) {
        switch (id) {
            case "py": return PY_WORDS;
            case "js": return JS_WORDS;
            case "java": return JAVA_WORDS;
            case "kt": return KT_WORDS;
            case "go": return GO_WORDS;
            case "cs": return CS_WORDS;
            case "rb": return RB_WORDS;
            case "php": return PHP_WORDS;
            case "swift": return SWIFT_WORDS;
            case "r": return R_WORDS;
            case "rs": return RS_WORDS;
            case "ts": return TS_WORDS;
            default: return C_WORDS;
        }
    }

    // ---------- Font size, line numbers, syntax colors ----------

    private void setFont(int sp) {
        fontSp = Math.max(FONT_MIN, Math.min(FONT_MAX, sp));
        prefs.edit().putInt(KEY_FONT, fontSp).apply();
        applyFont();
        Toast.makeText(this, "Text size " + fontSp, Toast.LENGTH_SHORT).show();
    }

    private void applyFont() {
        editor.setTextSize(fontSp);
        gutter.setTextSize(fontSp);
    }

    private void updateGutter(Editable s) {
        int lines = 1;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '\n') lines++;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            sb.append(i);
            if (i < lines) sb.append('\n');
        }
        SpannableStringBuilder g = new SpannableStringBuilder(sb.toString());
        if (errLine >= 1 && errLine <= lines) {
            int st = 0;
            for (int i = 1; i < errLine; i++) st += String.valueOf(i).length() + 1;
            int en = st + String.valueOf(errLine).length();
            g.setSpan(new ForegroundColorSpan(Color.WHITE), st, en, Editable.SPAN_EXCLUSIVE_EXCLUSIVE);
            g.setSpan(new BackgroundColorSpan(0xFFE5484D), st, en, Editable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        gutter.setText(g);
    }

    // ---------- Error line (red row) and simple explanation ----------

    private void clearErrorMark(Editable s) {
        errLine = 0;
        BackgroundColorSpan[] old = s.getSpans(0, s.length(), BackgroundColorSpan.class);
        for (BackgroundColorSpan b : old) s.removeSpan(b);
        updateGutter(s);
    }

    /** Colors one row of the editor red and scrolls to it. */
    private void markErrorLine(int line) {
        Editable s = editor.getText();
        BackgroundColorSpan[] old = s.getSpans(0, s.length(), BackgroundColorSpan.class);
        for (BackgroundColorSpan b : old) s.removeSpan(b);
        errLine = 0;
        if (line >= 1) {
            int start = 0;
            for (int i = 1; i < line; i++) {
                int nl = s.toString().indexOf('\n', start);
                if (nl < 0) { start = -1; break; }
                start = nl + 1;
            }
            if (start >= 0) {
                int end = s.toString().indexOf('\n', start);
                if (end < 0) end = s.length();
                if (end == start && end < s.length()) end = start + 1;
                if (end > start) {
                    s.setSpan(new BackgroundColorSpan(0x66E5484D), start, end,
                            Editable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                errLine = line;
                final int ln = line;
                editor.post(new Runnable() {
                    @Override
                    public void run() {
                        if (editor.getLayout() != null && ln - 1 < editor.getLineCount()) {
                            int y = editor.getLayout().getLineTop(ln - 1);
                            editScroll.smoothScrollTo(0, Math.max(0, y - dp(80)));
                        }
                    }
                });
            }
        }
        updateGutter(s);
    }

    /** Finds the line number of the error in a traceback or compiler message, 0 if none. */
    private int findErrorLine(String t) {
        int line = 0;
        boolean py = t.contains("Traceback") || t.contains("SyntaxError") || t.contains("IndentationError");
        if (py) {
            Matcher p = Pattern.compile("File \"[^\"]*\", line (\\d+)").matcher(t);
            while (p.find()) {
                // the last frame that belongs to the user's file is the one that failed
                String frame = p.group();
                if (!frame.contains("runner.py") && !frame.contains("/lib/") && !frame.contains("site-packages")) {
                    line = Integer.parseInt(p.group(1));
                }
            }
            if (line == 0) {
                Matcher q = Pattern.compile("line (\\d+)").matcher(t);
                while (q.find()) line = Integer.parseInt(q.group(1));
            }
            return line;
        }
        Matcher g = Pattern.compile("(?m)^[^\\s:]+:(\\d+)(?::\\d+)?:\\s*(?:fatal )?error").matcher(t);
        if (g.find()) return Integer.parseInt(g.group(1));
        Matcher r = Pattern.compile("(?i)\\bline (\\d+)").matcher(t);
        if (r.find()) return Integer.parseInt(r.group(1));
        return 0;
    }

    /** A short Hinglish explanation of the usual errors. */
    private String explainError(String t, int line) {
        String why;
        if (t.contains("IndentationError") || t.contains("TabError")) {
            why = "Space/indent galat hai. Line ke aage ke spaces barabar rakho (if/for/def ke baad andar wali line me 2-4 space).";
        } else if (t.contains("SyntaxError")) {
            why = "Likhne ka tarika galat hai. Bracket ( ) band kiya? Quote \" \" band kiya? if/for/def ke aage ':' lagaya? Spelling check karo.";
        } else if (t.contains("NameError")) {
            why = "Ye naam pehle define nahi hua ya spelling alag hai. Agar text print karna hai to quotes me likho, jaise print(\"boy\").";
        } else if (t.contains("ZeroDivisionError")) {
            why = "Zero se divide ho raha hai. Bhagne wala number 0 nahi hona chahiye.";
        } else if (t.contains("IndexError")) {
            why = "List me itni position hai hi nahi. Index list ki length se chhota rakho (0 se shuru).";
        } else if (t.contains("KeyError")) {
            why = "Dictionary me ye key nahi mili. Key ki spelling check karo.";
        } else if (t.contains("TypeError")) {
            why = "Alag type ko mila diya, jaise text + number. str(number) ya int(text) use karo.";
        } else if (t.contains("ValueError")) {
            why = "Value ka format galat hai, jaise int(\"abc\"). Input sahi type ka do.";
        } else if (t.contains("AttributeError")) {
            why = "Is cheez me ye function/property hai hi nahi. Naam ki spelling check karo.";
        } else if (t.contains("ModuleNotFoundError") || t.contains("ImportError")) {
            why = "Ye library phone me nahi hai. Python ki basic libraries hi chalti hain.";
        } else if (t.contains("EOFError")) {
            why = "input() ko value chahiye thi. Upar 'Input' button se value likho.";
        } else if (t.toLowerCase().contains("error")) {
            why = "Code me galti hai. Laal line ko dhyan se dekho.";
        } else {
            return "";
        }
        return (line > 0 ? "\n\n❌ Line " + line + " me galti hai (laal rang me dikhayi gayi).\n" : "\n\n❌ Galti hai.\n")
                + "👉 " + why;
    }

    private void highlight(Editable s) {
        ForegroundColorSpan[] old = s.getSpans(0, s.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan span : old) {
            s.removeSpan(span);
        }
        if (s.length() > 20000) return;   // keep typing smooth on very long code

        Set<String> words = wordsFor(lang);
        boolean web = "web".equals(lang);
        boolean hash = "py".equals(lang) || "rb".equals(lang) || "r".equals(lang);
        Matcher m = (web ? WEB_TOKENS : (hash ? PY_TOKENS : SLASH_TOKENS)).matcher(s);
        while (m.find()) {
            int color;
            if (m.group(1) != null) {
                color = C_COMMENT;
            } else if (m.group(2) != null) {
                color = C_STRING;
            } else if (m.group(3) != null) {
                color = C_NUMBER;
            } else {
                String word = m.group(4);
                if (web || words.contains(word)) {
                    color = C_KEYWORD;
                } else if (m.end() < s.length() && s.charAt(m.end()) == '(') {
                    color = C_FUNCTION;
                } else {
                    continue;
                }
            }
            s.setSpan(new ForegroundColorSpan(color), m.start(), m.end(),
                    Editable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    // ---------- Key bar ----------

    private void insertKey(String key) {
        int start = Math.max(editor.getSelectionStart(), 0);
        int end = Math.max(editor.getSelectionEnd(), start);
        String text;
        boolean pair = false;
        switch (key) {
            case "TAB": text = "  "; break;
            case "(": text = "()"; pair = true; break;
            case "[": text = "[]"; pair = true; break;
            case "{": text = "{}"; pair = true; break;
            case "\"": text = "\"\""; pair = true; break;
            case "'": text = "''"; pair = true; break;
            default: text = key;
        }
        editor.getText().replace(start, end, text);
        editor.setSelection(pair ? start + 1 : start + text.length());
    }

    // ---------- Save, share, clear ----------

    private void showSaveDialog() {
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Name, e.g. Add two numbers");
        name.setText(lastName);
        name.setSelection(name.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("Save in CS > Saved Code")
                .setView(name)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String n = name.getText().toString().trim();
                        if (n.isEmpty()) n = "Untitled";
                        lastName = n;
                        CodeStore.save(PlaygroundActivity.this, n, lang, editor.getText().toString());
                        Toast.makeText(PlaygroundActivity.this,
                                "Saved in CS > Saved Code", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showExamples() {
        final String[] names = {"Snake game (touch buttons)", "Simple page"};
        new AlertDialog.Builder(this)
                .setTitle("Load an example (replaces your code)")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            try {
                                editor.setText(readAll(getAssets().open("playground/snake.html")));
                                lastName = "Snake game";
                            } catch (Exception e) {
                                Toast.makeText(PlaygroundActivity.this,
                                        "Could not load the example.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            editor.setText(STARTERS[indexOfLang("web")]);
                            lastName = "";
                        }
                    }
                })
                .show();
    }

    private void openFullScreen() {
        WebPreviewActivity.html = editor.getText().toString();
        startActivity(new Intent(this, WebPreviewActivity.class));
    }

    private void shareCode() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, editor.getText().toString());
        startActivity(Intent.createChooser(send, "Share code"));
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Clear all code?")
                .setMessage("The editor will be empty. Save it first if you want to keep it.")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        editor.setText("");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- Running code ----------

    private void showResult(String text, boolean isError) {
        running = false;
        outScroll.setVisibility(View.VISIBLE);
        preview.setVisibility(View.GONE);
        String low = text.toLowerCase();
        boolean looksBad = isError || text.contains("Traceback (most recent call last)")
                || text.contains("SyntaxError") || text.contains("IndentationError")
                || (!"py".equals(lang) && low.contains("error"));
        int bad = 0;
        String help = "";
        if (looksBad && !"web".equals(lang)) {
            bad = findErrorLine(text);
            help = explainError(text, bad);
        }
        markErrorLine(bad);
        output.setTextColor(looksBad ? Ui.ERR : Ui.TEXT);
        output.setText(text.isEmpty() ? "(no output)" : text + help);
        double secs = (System.nanoTime() - startedAt) / 1e9;
        runTime.setText(String.format(Locale.US, "%s in %.2f s", looksBad ? "Stopped" : "Ran", secs));
    }

    /** Shows a result, but only if it belongs to the run that is still current. */
    private void deliver(final int id, final String text, final boolean isError) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (id == runId) showResult(text, isError);
            }
        });
    }

    /** Stops waiting for a run that takes too long. */
    private void startWatchdog(final int id, final int seconds) {
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (id == runId && running) {
                    runId++;   // a late result is ignored
                    if (jsView != null) {
                        jsView.destroy();
                        jsView = null;
                    }
                    showResult("Stopped: the code ran for more than " + seconds + " seconds.", true);
                }
            }
        }, seconds * 1000L);
    }

    private void runCode() {
        if (running) {
            Toast.makeText(this, "Still running. Please wait.", Toast.LENGTH_SHORT).show();
            return;
        }
        final String code = editor.getText().toString();
        final String input = stdin.getText().toString();
        running = true;
        final int id = ++runId;
        startedAt = System.nanoTime();
        runTime.setText("");
        markErrorLine(0);
        if ("web".equals(lang)) {
            runWeb(code);
            return;
        }
        outScroll.setVisibility(View.VISIBLE);
        preview.setVisibility(View.GONE);
        output.setTextColor(Ui.MUTED);
        output.setText("Running...");
        if ("js".equals(lang)) {
            runJavaScript(id, code);
        } else if (isOnline()) {
            runOnline(id, code, input, indexOfLang(lang));
        } else {
            runPython(id, code, input);
        }
    }

    private void runWeb(String code) {
        outScroll.setVisibility(View.GONE);
        preview.setVisibility(View.VISIBLE);
        preview.loadDataWithBaseURL(null, code, "text/html", "utf-8", null);
        runTime.setText("Preview updated");
        running = false;
    }

    private void runPython(final int id, final String code, final String input) {
        startWatchdog(id, 15);
        // Run off the main thread so the screen never freezes.
        new Thread(new Runnable() {
            @Override
            public void run() {
                String result;
                boolean failed = false;
                try {
                    result = Python.getInstance().getModule("runner")
                            .callAttr("run", code, input).toString();
                } catch (Exception e) {
                    result = String.valueOf(e.getMessage());
                    failed = true;
                }
                deliver(id, result, failed);
            }
        }).start();
    }

    private void runJavaScript(final int id, String code) {
        startWatchdog(id, 8);
        final WebView wv = new WebView(this);
        jsView = wv;
        wv.getSettings().setJavaScriptEnabled(true);
        final String script =
                "(function(){var out=[],bad=false;"
                        + "var f=function(a){return Array.prototype.slice.call(a).map(function(x){"
                        + "try{return (typeof x==='object'&&x!==null)?JSON.stringify(x):String(x)}"
                        + "catch(e){return String(x)}}).join(' ')};"
                        + "var c={log:function(){out.push(f(arguments))},"
                        + "error:function(){out.push(f(arguments))},"
                        + "warn:function(){out.push(f(arguments))}};"
                        + "try{(new Function('console'," + JSONObject.quote(code) + "))(c)}"
                        + "catch(e){bad=true;out.push('');out.push(e.name+': '+e.message)}"
                        + "return JSON.stringify({t:out.join('\\n'),bad:bad})})()";
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(script, new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        String text;
                        boolean failed;
                        try {
                            JSONObject o = new JSONObject(new JSONArray("[" + value + "]").getString(0));
                            text = o.getString("t");
                            failed = o.getBoolean("bad");
                        } catch (Exception e) {
                            text = "Could not read the result.";
                            failed = true;
                        }
                        if (jsView == wv) {
                            jsView = null;
                            wv.destroy();
                        }
                        deliver(id, text, failed);
                    }
                });
            }
        });
        wv.loadDataWithBaseURL(null, "<html><body></body></html>", "text/html", "utf-8", null);
    }

    // ---------- Online languages (Judge0) ----------

    private static String b64(String s) {
        return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
    }

    private static String unb64(String s) {
        if (s == null || s.isEmpty() || "null".equals(s)) return "";
        return new String(Base64.decode(s, Base64.DEFAULT), StandardCharsets.UTF_8);
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toString("UTF-8");
    }

    /** Finds the server's own number for a language, so a changed list does not break it. */
    private int resolveJudge0Id(int idx) {
        int fallback = JUDGE0_FALLBACK[idx];
        String prefix = JUDGE0_PREFIX[idx];
        try {
            JSONArray list = judge0Languages;
            if (list == null) {
                HttpURLConnection c = (HttpURLConnection) new URL(JUDGE0_HOSTS[0] + "/languages").openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(10000);
                if (c.getResponseCode() != 200) return fallback;
                list = new JSONArray(readAll(c.getInputStream()));
                judge0Languages = list;
            }
            int firstMatch = -1;
            for (int i = 0; i < list.length(); i++) {
                JSONObject o = list.getJSONObject(i);
                String name = o.optString("name");
                int id = o.optInt("id");
                if (!name.startsWith(prefix)) continue;
                if (id == fallback) return fallback;
                if (firstMatch < 0 && !name.contains("JUnit") && !name.contains("Test")
                        && !name.contains("Multi") && !name.contains("Executable")) {
                    firstMatch = id;
                }
            }
            return firstMatch > 0 ? firstMatch : fallback;
        } catch (Exception e) {
            return fallback;
        }
    }

    private void runOnline(final int id, final String code, final String input, final int idx) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String text;
                boolean failed = false;
                try {
                    int languageId = resolveJudge0Id(idx);
                    JSONObject body = new JSONObject();
                    body.put("source_code", b64(code));
                    body.put("language_id", languageId);
                    body.put("stdin", b64(input));

                    // 1. send the code. Try up to 3 times, because the free server is often busy.
                    String host = null;
                    String token = null;
                    Exception last = new Exception("Could not reach the server. Try again.");
                    for (int attempt = 0; attempt < 3 && token == null; attempt++) {
                        String h = JUDGE0_HOSTS[attempt % JUDGE0_HOSTS.length];
                        try {
                            HttpURLConnection c = (HttpURLConnection) new URL(
                                    h + "/submissions?base64_encoded=true&wait=false").openConnection();
                            c.setConnectTimeout(10000);
                            c.setReadTimeout(15000);
                            c.setRequestMethod("POST");
                            c.setRequestProperty("Content-Type", "application/json");
                            c.setDoOutput(true);
                            OutputStream os = c.getOutputStream();
                            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                            os.close();
                            int status = c.getResponseCode();
                            if (status == 429 || status >= 500) {
                                last = new Exception(status == 429
                                        ? "The free server is busy right now (too many requests). Wait a minute and press RUN again."
                                        : "The free server had a problem (error " + status + "). Press RUN again.");
                                Thread.sleep(2000);
                                continue;
                            }
                            if (status >= 400) {
                                throw new Exception("The server refused the request (error " + status + ").");
                            }
                            token = new JSONObject(readAll(c.getInputStream())).getString("token");
                            host = h;
                        } catch (java.io.IOException e) {
                            last = e;
                            Thread.sleep(1500);
                        }
                    }
                    if (token == null) throw last;

                    // 2. ask for the result until it is ready (up to about 40 seconds)
                    JSONObject result = null;
                    for (int i = 0; i < 40; i++) {
                        Thread.sleep(1000);
                        try {
                            URL poll = new URL(host + "/submissions/" + token
                                    + "?base64_encoded=true&fields=stdout,stderr,compile_output,message,status");
                            HttpURLConnection p = (HttpURLConnection) poll.openConnection();
                            p.setConnectTimeout(10000);
                            p.setReadTimeout(15000);
                            if (p.getResponseCode() >= 400) continue;
                            JSONObject r = new JSONObject(readAll(p.getInputStream()));
                            if (r.getJSONObject("status").getInt("id") > 2) {   // 1 = in queue, 2 = running
                                result = r;
                                break;
                            }
                        } catch (java.io.IOException e) {
                            // a single failed check is fine, ask again
                        }
                    }
                    if (result == null) {
                        throw new Exception("The server took too long. Press RUN again.");
                    }

                    StringBuilder sb = new StringBuilder();
                    sb.append(unb64(result.optString("stdout", "")));
                    String compile = unb64(result.optString("compile_output", ""));
                    String stderr = unb64(result.optString("stderr", ""));
                    String message = unb64(result.optString("message", ""));
                    if (!compile.isEmpty()) sb.append(compile);
                    if (!stderr.isEmpty()) sb.append(stderr);
                    if (!message.isEmpty()) sb.append(message);
                    JSONObject st = result.getJSONObject("status");
                    int statusId = st.getInt("id");
                    failed = statusId != 3;
                    if (failed) {
                        if (sb.length() > 0 && sb.charAt(sb.length() - 1) != '\n') sb.append('\n');
                        sb.append("[").append(st.optString("description", "Error")).append("]");
                        if (statusId == 13) {
                            sb.append("\nThe server had an internal problem. Press RUN again.");
                        }
                        if (sb.indexOf("should be declared in a file named") >= 0) {
                            sb.append("\nHint: in Java, name the main class Main.");
                        }
                    }
                    text = sb.toString();
                } catch (java.net.UnknownHostException e) {
                    text = "No internet. Online languages need a connection.";
                    failed = true;
                } catch (java.net.SocketTimeoutException e) {
                    text = "The server did not answer in time. Press RUN again.";
                    failed = true;
                } catch (Exception e) {
                    text = String.valueOf(e.getMessage());
                    failed = true;
                }
                deliver(id, text, failed);
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (preview != null) preview.destroy();
        if (jsView != null) jsView.destroy();
        super.onDestroy();
    }
}
