package com.mysa.studytracker;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * Settings for the Code Playground. Holds the "Note" flashcards:
 * tap a card to flip it between question and answer, add new ones, delete old ones.
 */
public class PlaygroundSettingsActivity extends Activity {

    private static final String PREFS = "playground";
    private static final String KEY_NOTES = "notes";

    private SharedPreferences prefs;
    private LinearLayout list;
    private TextView count;
    private EditText questionInput;
    private EditText answerInput;
    private JSONArray cards = new JSONArray();
    private final Set<String> flipped = new HashSet<String>();

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.load(this);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.BG);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadCards();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(buildHeader());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(16), dp(16), dp(24));

        TextView about = new TextView(this);
        about.setText("About online languages\nPython, JavaScript and Web (HTML) run on your phone. C, C++, C#, Java, Kotlin, Go, Ruby, PHP, Swift, R, Rust and TypeScript run on a free public Judge0 server, so your code is sent over the internet. Use them only for test and practice. Do not put passwords or personal notes in your code. The free server can be slow or busy, and it may stop working without warning.");
        about.setTextColor(Ui.WARN);
        about.setTextSize(13);
        about.setBackground(Ui.rounded(this, 0xFF3A3220, 16));
        about.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams alp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        alp2.bottomMargin = dp(20);
        body.addView(about, alp2);

        body.addView(buildLookAndFeel());

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Note");
        title.setTextColor(Ui.TEXT);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        count = new TextView(this);
        count.setTextColor(Ui.MUTED);
        count.setTextSize(13);
        head.addView(count);
        body.addView(head);

        TextView sub = new TextView(this);
        sub.setText("Flashcards for things you want to remember. Tap a card to flip it.");
        sub.setTextColor(Ui.MUTED);
        sub.setTextSize(14);
        sub.setPadding(0, dp(4), 0, dp(12));
        body.addView(sub);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);

        body.addView(buildAddForm());
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        render();
    }

    private View buildHeader() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Ui.BAR, Ui.BAR2}));
        bar.setPadding(dp(8), 0, dp(16), 0);

        TextView back = new TextView(this);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setTextSize(24);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(56)));

        TextView title = new TextView(this);
        title.setText("Note & Settings");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title);
        return bar;
    }

    // ---------- Look & feel ----------

    private SharedPreferences uiPrefs() {
        return getSharedPreferences(Ui.PREFS, MODE_PRIVATE);
    }

    private View buildLookAndFeel() {
        final SharedPreferences up = uiPrefs();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(Ui.clay(this, Ui.SURFACE, 20));
        box.setPadding(dp(16), dp(16), dp(16), dp(19));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.bottomMargin = dp(20);
        box.setLayoutParams(blp);

        TextView h = new TextView(this);
        h.setText("Look & feel");
        h.setTextColor(Ui.TEXT);
        h.setTextSize(20);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(h);

        // Theme
        box.addView(label("THEME"));
        LinearLayout themes = new LinearLayout(this);
        themes.setOrientation(LinearLayout.HORIZONTAL);
        String cur = up.getString("theme", "dark");
        if (!"amoled".equals(cur)) cur = "dark";
        themes.addView(themeChip("Dark", "dark", cur));
        themes.addView(themeChip("AMOLED", "amoled", cur));
        box.addView(themes);

        // Accent
        box.addView(label("ACCENT COLOR"));
        LinearLayout accents = new LinearLayout(this);
        accents.setOrientation(LinearLayout.HORIZONTAL);
        String curAcc = up.getString("accent", "violet");
        String[] names = {"violet", "blue", "green", "orange", "pink"};
        for (int i = 0; i < names.length; i++) {
            accents.addView(accentDot(names[i], names[i].equals(curAcc)));
        }
        box.addView(accents);

        // Toggles
        box.addView(toggleRow("Animations", "anim"));
        box.addView(toggleRow("Haptics", "haptics"));
        return box;
    }

    private View themeChip(String labelText, final String value, String current) {
        boolean sel = value.equals(current);
        TextView t = new TextView(this);
        t.setText(labelText);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(sel ? Color.WHITE : Ui.TEXT);
        t.setContentDescription(labelText + " theme" + (sel ? ", selected" : ""));
        t.setBackground(sel ? Ui.clay(this, Ui.BAR, 16) : Ui.inset(this, 16));
        t.setPadding(dp(8), dp(2), dp(8), sel ? dp(5) : dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        Ui.press(t);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ui.haptic(v);
                uiPrefs().edit().putString("theme", value).apply();
                recreate();
            }
        });
        return t;
    }

    private View accentDot(final String name, boolean sel) {
        FrameLayout cell = new FrameLayout(this);
        cell.setContentDescription(name + " accent" + (sel ? ", selected" : ""));
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Ui.accentColor(name));
        d.setStroke(dp(sel ? 3 : 1), sel ? Color.WHITE : 0x33FFFFFF);
        View dot = new View(this);
        dot.setBackground(d);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER);
        cell.addView(dot, dlp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(48), dp(48));
        lp.rightMargin = dp(4);
        cell.setLayoutParams(lp);
        Ui.press(cell);
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ui.haptic(v);
                uiPrefs().edit().putString("accent", name).apply();
                recreate();
            }
        });
        return cell;
    }

    private View toggleRow(String labelText, final String key) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        rlp.topMargin = dp(8);
        row.setLayoutParams(rlp);

        TextView t = new TextView(this);
        t.setText(labelText);
        t.setTextColor(Ui.TEXT);
        t.setTextSize(16);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Toggle3D sw = new Toggle3D(this);
        sw.setContentDescription(labelText);
        sw.setChecked(uiPrefs().getBoolean(key, true));
        sw.setOnCheckedChangeListener(new Toggle3D.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(Toggle3D tg, boolean checked) {
                uiPrefs().edit().putBoolean(key, checked).apply();
            }
        });
        row.addView(sw, new LinearLayout.LayoutParams(dp(60), dp(48)));
        return row;
    }

    private View buildAddForm() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setBackground(Ui.clay(this, Ui.SURFACE, 20));
        form.setPadding(dp(16), dp(16), dp(16), dp(19));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(18);
        form.setLayoutParams(lp);

        form.addView(label("QUESTION"));
        questionInput = input("e.g. Which tool runs Python inside an Android app?", false);
        form.addView(questionInput);
        form.addView(label("ANSWER"));
        answerInput = input("e.g. Chaquopy", true);
        form.addView(answerInput);

        Button add = new Button(this);
        add.setText("Add card");
        add.setAllCaps(false);
        add.setTextColor(Color.WHITE);
        add.setTypeface(Typeface.DEFAULT_BOLD);
        add.setBackground(Ui.clay(this, Ui.BAR, 16));
        add.setMinHeight(dp(48));
        add.setPadding(dp(24), dp(4), dp(24), dp(8));
        Ui.press(add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCard();
            }
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(52));
        alp.topMargin = dp(12);
        form.addView(add, alp);
        return form;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Ui.MUTED);
        t.setTextSize(12);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, dp(8), 0, dp(4));
        return t;
    }

    private EditText input(String hint, boolean multiline) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Ui.MUTED);
        e.setTextColor(Ui.TEXT);
        e.setTextSize(15);
        e.setBackground(Ui.inset(this, 16));
        e.setMinHeight(dp(48));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(multiline
                ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE)
                : InputType.TYPE_CLASS_TEXT);
        if (multiline) e.setMinLines(3);
        return e;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    // ---------- Cards ----------

    private void loadCards() {
        String saved = prefs.getString(KEY_NOTES, null);
        try {
            if (saved != null) {
                cards = new JSONArray(saved);
                return;
            }
        } catch (Exception ignored) {
            // fall through to the starter cards
        }
        cards = new JSONArray();
        addSeed("Which tool runs Python inside an Android app, with no server?",
                "Chaquopy. It bundles Python into the app, so Python code runs offline.");
        addSeed("Which languages can run on the phone itself?",
                "Python (Chaquopy), JavaScript and Web (WebView), and C (Tiny C Compiler).");
        addSeed("Where do C++, Java, Kotlin and Go run?",
                "On a server. The app sends the code to the Judge0 API, which compiles it, runs it and returns the output.");
        addSeed("Why is C harder to run than Python?",
                "C is compiled. The code must become a program first, and Android 10+ blocks running programs from the app's writable folder.");
        saveCards();
    }

    private void addSeed(String q, String a) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", "s" + cards.length());
            o.put("q", q);
            o.put("a", a);
            cards.put(o);
        } catch (Exception ignored) {
        }
    }

    private void saveCards() {
        prefs.edit().putString(KEY_NOTES, cards.toString()).apply();
    }

    private void addCard() {
        String q = questionInput.getText().toString().trim();
        String a = answerInput.getText().toString().trim();
        if (q.isEmpty() || a.isEmpty()) {
            questionInput.setError(q.isEmpty() ? "Write a question" : null);
            answerInput.setError(a.isEmpty() ? "Write an answer" : null);
            return;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("id", "n" + System.currentTimeMillis());
            o.put("q", q);
            o.put("a", a);
            // newest card goes on top
            JSONArray next = new JSONArray();
            next.put(o);
            for (int i = 0; i < cards.length(); i++) next.put(cards.get(i));
            cards = next;
        } catch (Exception e) {
            return;
        }
        saveCards();
        questionInput.setText("");
        answerInput.setText("");
        render();
    }

    private void deleteCard(String id) {
        JSONArray next = new JSONArray();
        for (int i = 0; i < cards.length(); i++) {
            JSONObject o = cards.optJSONObject(i);
            if (o != null && !id.equals(o.optString("id"))) next.put(o);
        }
        cards = next;
        flipped.remove(id);
        saveCards();
        render();
    }

    private void render() {
        list.removeAllViews();
        count.setText(cards.length() + (cards.length() == 1 ? " card" : " cards"));
        if (cards.length() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No notes yet. Add your first question and answer below.");
            empty.setTextColor(Ui.MUTED);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(24), dp(16), dp(24));
            list.addView(empty);
            return;
        }
        for (int i = 0; i < cards.length(); i++) {
            final JSONObject o = cards.optJSONObject(i);
            if (o == null) continue;
            final String id = o.optString("id");
            boolean isFlipped = flipped.contains(id);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Ui.clay(this, isFlipped ? Ui.SURFACE_2 : Ui.SURFACE, 20));
            card.setPadding(dp(16), dp(14), dp(16), dp(11));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.bottomMargin = dp(10);
            card.setLayoutParams(clp);

            TextView tag = new TextView(this);
            tag.setText(isFlipped ? "ANSWER" : "QUESTION");
            tag.setTextColor(isFlipped ? Ui.BAR2 : Ui.MUTED);
            tag.setTextSize(11);
            tag.setLetterSpacing(0.1f);
            card.addView(tag);

            TextView text = new TextView(this);
            text.setText(isFlipped ? o.optString("a") : o.optString("q"));
            text.setTextColor(Ui.TEXT);
            text.setTextSize(isFlipped ? 15 : 17);
            text.setTypeface(isFlipped ? Typeface.DEFAULT : Typeface.DEFAULT_BOLD);
            text.setPadding(0, dp(6), 0, dp(10));
            card.addView(text);

            TextView del = new TextView(this);
            del.setText("Delete");
            del.setTextColor(Ui.MUTED);
            del.setTextSize(13);
            del.setGravity(Gravity.CENTER_VERTICAL);
            del.setMinHeight(dp(44));
            del.setPadding(0, dp(4), dp(24), dp(4));
            Ui.press(del);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ui.haptic(v);
                    deleteCard(id);
                }
            });
            card.addView(del);

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ui.haptic(v);
                    if (flipped.contains(id)) flipped.remove(id); else flipped.add(id);
                    render();
                }
            });
            Ui.press(card);
            Ui.enter(card, i);
            list.addView(card);
        }
    }
}
