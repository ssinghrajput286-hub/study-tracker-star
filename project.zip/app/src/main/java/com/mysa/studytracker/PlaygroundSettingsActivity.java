package com.mysa.studytracker;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * Settings for the Code Playground. Holds the "Note" flashcards:
 * tap a card to flip it between question and answer, add new ones, delete old ones.
 */
public class PlaygroundSettingsActivity extends Activity {

    private static final String PREFS = "playground";
    private static final String KEY_NOTES = "notes";

    private static final int BAR = 0xFF6F55F5;
    private static final int BG = 0xFF17191D;
    private static final int SURFACE = 0xFF1F2228;
    private static final int SURFACE_2 = 0xFF262A32;
    private static final int TEXT = 0xFFE6E8EC;
    private static final int MUTED = 0xFF9AA1AD;
    private static final int ERR = 0xFFFF7B72;

    private SharedPreferences prefs;
    private LinearLayout list;
    private TextView count;
    private EditText questionInput;
    private EditText answerInput;
    private JSONArray cards = new JSONArray();
    private final Set<String> flipped = new HashSet<String>();

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BAR);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadCards();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.addView(buildHeader());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(16), dp(16), dp(24));

        TextView about = new TextView(this);
        about.setText("About online languages\nPython, JavaScript and Web (HTML) run on your phone. C, C++, C#, Java, Kotlin, Go, Ruby, PHP, Swift, R, Rust and TypeScript run on a free public Judge0 server, so your code is sent over the internet. Use them only for test and practice. Do not put passwords or personal notes in your code. The free server can be slow or busy, and it may stop working without warning.");
        about.setTextColor(0xFFFFD27F);
        about.setTextSize(13);
        about.setBackground(rounded(0xFF3A3220, 12));
        about.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams alp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        alp2.bottomMargin = dp(20);
        body.addView(about, alp2);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Note");
        title.setTextColor(TEXT);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        count = new TextView(this);
        count.setTextColor(MUTED);
        count.setTextSize(13);
        head.addView(count);
        body.addView(head);

        TextView sub = new TextView(this);
        sub.setText("Flashcards for things you want to remember. Tap a card to flip it.");
        sub.setTextColor(MUTED);
        sub.setTextSize(14);
        sub.setPadding(0, dp(4), 0, dp(12));
        body.addView(sub);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);

        body.addView(buildAddForm());
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        render();
    }

    private View buildHeader() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(BAR);
        bar.setPadding(dp(8), 0, dp(16), 0);

        TextView back = new TextView(this);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setTextSize(24);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(56)));

        TextView title = new TextView(this);
        title.setText("Note & Settings");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title);
        return bar;
    }

    private View buildAddForm() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setBackground(rounded(SURFACE, 12));
        form.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(18);
        form.setLayoutParams(lp);

        form.addView(label("QUESTION"));
        questionInput = input("e.g. Which tool runs Python inside an Android app?", false);
        form.addView(questionInput);
        form.addView(label("ANSWER"));
        answerInput = input("e.g. Chaquopy", true);
        form.addView(answerInput);

        Button add = new Button(this);
        add.setText("Add card");
        add.setAllCaps(false);
        add.setTextColor(Color.WHITE);
        add.setTypeface(Typeface.DEFAULT_BOLD);
        add.setBackground(rounded(BAR, 8));
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCard();
            }
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        alp.topMargin = dp(12);
        form.addView(add, alp);
        return form;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(MUTED);
        t.setTextSize(12);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, dp(8), 0, dp(4));
        return t;
    }

    private EditText input(String hint, boolean multiline) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setBackground(rounded(BG, 8));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(multiline
                ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE)
                : InputType.TYPE_CLASS_TEXT);
        if (multiline) e.setMinLines(3);
        return e;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    // ---------- Cards ----------

    private void loadCards() {
        String saved = prefs.getString(KEY_NOTES, null);
        try {
            if (saved != null) {
                cards = new JSONArray(saved);
                return;
            }
        } catch (Exception ignored) {
            // fall through to the starter cards
        }
        cards = new JSONArray();
        addSeed("Which tool runs Python inside an Android app, with no server?",
                "Chaquopy. It bundles Python into the app, so Python code runs offline.");
        addSeed("Which languages can run on the phone itself?",
                "Python (Chaquopy), JavaScript and Web (WebView), and C (Tiny C Compiler).");
        addSeed("Where do C++, Java, Kotlin and Go run?",
                "On a server. The app sends the code to the Judge0 API, which compiles it, runs it and returns the output.");
        addSeed("Why is C harder to run than Python?",
                "C is compiled. The code must become a program first, and Android 10+ blocks running programs from the app's writable folder.");
        saveCards();
    }

    private void addSeed(String q, String a) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", "s" + cards.length());
            o.put("q", q);
            o.put("a", a);
            cards.put(o);
        } catch (Exception ignored) {
        }
    }

    private void saveCards() {
        prefs.edit().putString(KEY_NOTES, cards.toString()).apply();
    }

    private void addCard() {
        String q = questionInput.getText().toString().trim();
        String a = answerInput.getText().toString().trim();
        if (q.isEmpty() || a.isEmpty()) {
            questionInput.setError(q.isEmpty() ? "Write a question" : null);
            answerInput.setError(a.isEmpty() ? "Write an answer" : null);
            return;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("id", "n" + System.currentTimeMillis());
            o.put("q", q);
            o.put("a", a);
            // newest card goes on top
            JSONArray next = new JSONArray();
            next.put(o);
            for (int i = 0; i < cards.length(); i++) next.put(cards.get(i));
            cards = next;
        } catch (Exception e) {
            return;
        }
        saveCards();
        questionInput.setText("");
        answerInput.setText("");
        render();
    }

    private void deleteCard(String id) {
        JSONArray next = new JSONArray();
        for (int i = 0; i < cards.length(); i++) {
            JSONObject o = cards.optJSONObject(i);
            if (o != null && !id.equals(o.optString("id"))) next.put(o);
        }
        cards = next;
        flipped.remove(id);
        saveCards();
        render();
    }

    private void render() {
        list.removeAllViews();
        count.setText(cards.length() + (cards.length() == 1 ? " card" : " cards"));
        if (cards.length() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No notes yet. Add your first question and answer below.");
            empty.setTextColor(MUTED);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(24), dp(16), dp(24));
            list.addView(empty);
            return;
        }
        for (int i = 0; i < cards.length(); i++) {
            final JSONObject o = cards.optJSONObject(i);
            if (o == null) continue;
            final String id = o.optString("id");
            boolean isFlipped = flipped.contains(id);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(rounded(isFlipped ? SURFACE_2 : SURFACE, 12));
            card.setPadding(dp(16), dp(14), dp(16), dp(8));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.bottomMargin = dp(10);
            card.setLayoutParams(clp);

            TextView tag = new TextView(this);
            tag.setText(isFlipped ? "ANSWER" : "QUESTION");
            tag.setTextColor(isFlipped ? 0xFF9D8CFF : MUTED);
            tag.setTextSize(11);
            tag.setLetterSpacing(0.1f);
            card.addView(tag);

            TextView text = new TextView(this);
            text.setText(isFlipped ? o.optString("a") : o.optString("q"));
            text.setTextColor(TEXT);
            text.setTextSize(isFlipped ? 15 : 17);
            text.setTypeface(isFlipped ? Typeface.DEFAULT : Typeface.DEFAULT_BOLD);
            text.setPadding(0, dp(6), 0, dp(10));
            card.addView(text);

            TextView del = new TextView(this);
            del.setText("Delete");
            del.setTextColor(MUTED);
            del.setTextSize(13);
            del.setPadding(0, dp(4), dp(12), dp(8));
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteCard(id);
                }
            });
            card.addView(del);

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (flipped.contains(id)) flipped.remove(id); else flipped.add(id);
                    render();
                }
            });
            list.addView(card);
        }
    }
}
