package com.mysa.studytracker;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Private space: simple browser ya Telegram Web. App se bahar jaate hi band ho jata hai. */
public class PrivateActivity extends Activity {
    private static final int RQ_FILE = 77;
    private static final String CH = "private_alert_v1";

    private WebView web;
    private EditText urlBox;
    private boolean tg;
    private boolean inChild = false;
    private int lastUnread = 0;
    private ValueCallback<Uri[]> fileCb;
    private final Handler h = new Handler(Looper.getMainLooper());

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button mk(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        return b;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        tg = "tg".equals(getIntent().getStringExtra("mode"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF6F55F5);
        bar.setPadding(dp(4), dp(4), dp(4), dp(4));

        Button back = mk("←");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (web.canGoBack()) web.goBack();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setTextColor(Color.WHITE);
        urlBox.setHintTextColor(0xAAFFFFFF);
        urlBox.setHint("Search ya address likho");
        urlBox.setTextSize(15);
        urlBox.setBackgroundColor(0x33FFFFFF);
        urlBox.setPadding(dp(10), 0, dp(10), 0);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                load(urlBox.getText().toString());
                return true;
            }
        });
        if (tg) {
            TextView title = new TextView(this);
            title.setText("Private");
            title.setTextColor(Color.WHITE);
            title.setTextSize(16);
            bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        } else {
            bar.addView(urlBox, new LinearLayout.LayoutParams(0, dp(40), 1f));
        }

        Button close = mk("✕");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(close, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));
        root.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        String ua = s.getUserAgentString();
        if (ua != null) s.setUserAgentString(ua.replace("; wv", "").replace("Version/4.0 ", ""));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                return !(u.startsWith("http://") || u.startsWith("https://"));
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                if (!tg && u != null) urlBox.setText(u);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                if (p != null && p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                inChild = true;
                try {
                    startActivityForResult(Intent.createChooser(i, "File chuno"), RQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    inChild = false;
                    return false;
                }
                return true;
            }
        });

        if (state == null) web.loadUrl(tg ? "https://web.telegram.org/k/" : "https://duckduckgo.com/");
        else web.restoreState(state);
        if (tg) h.postDelayed(poll, 5000);
    }

    private void load(String q) {
        q = q == null ? "" : q.trim();
        if (q.length() == 0) return;
        String u;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) u = q;
        else if (q.contains(" ") || !q.contains(".")) u = "https://duckduckgo.com/?q=" + Uri.encode(q);
        else u = "https://" + q;
        web.loadUrl(u);
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (web != null) {
                web.evaluateJavascript("document.title", new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        check(v);
                    }
                });
            }
            h.postDelayed(this, 4000);
        }
    };

    private void check(String t) {
        if (t == null) return;
        int n = 0;
        Matcher m = Pattern.compile("\\((\\d+)\\)").matcher(t);
        if (m.find()) {
            try {
                n = Integer.parseInt(m.group(1));
            } catch (Exception e) {
                n = 0;
            }
        }
        if (n > lastUnread) alert();
        lastUnread = n;
    }

    private void alert() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CH, "Private", NotificationManager.IMPORTANCE_DEFAULT));
            }
            Intent i = new Intent(this, PrivateActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            PendingIntent pi = PendingIntent.getActivity(this, 5, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification nf = new Notification.Builder(this, CH)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("Study Tracker")
                    .setContentText("Naya update")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(9001, nf);
        } catch (Exception e) {
            // notification nahi ban paya, koi baat nahi
        }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq == RQ_FILE) {
            inChild = false;
            if (fileCb != null) {
                Uri[] r = null;
                if (rs == RESULT_OK && d != null) {
                    if (d.getClipData() != null) {
                        int n = d.getClipData().getItemCount();
                        r = new Uri[n];
                        for (int k = 0; k < n; k++) r[k] = d.getClipData().getItemAt(k).getUri();
                    } else if (d.getData() != null) {
                        r = new Uri[]{d.getData()};
                    }
                }
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!inChild && !isChangingConfigurations()) finish();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else finish();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacks(poll);
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
