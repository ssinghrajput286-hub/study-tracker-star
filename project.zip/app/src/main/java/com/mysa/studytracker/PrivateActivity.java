package com.mysa.studytracker;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Private space: simple browser ya Telegram Web. App se bahar jaate hi band ho jata hai. */
public class PrivateActivity extends Activity {
    private static final int RQ_FILE = 77;
    private static final int RQ_PERM = 78;
    private static final String CH = "private_alert_v1";

    private WebView web;
    private EditText urlBox;
    private boolean tg;
    private boolean inChild = false;
    private int lastUnread = 0;
    private ValueCallback<Uri[]> fileCb;
    // Camera/mic: sirf Telegram mode me, har baar Private space kholne par naya sawaal
    private PermissionRequest pendReq;
    private AlertDialog perDlg;
    private int camState = 0; // 0 = poochna hai, 1 = allow, -1 = is session me band
    private int micState = 0;
    private boolean pendCam, pendMic;
    private final Handler h = new Handler(Looper.getMainLooper());

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button mk(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        return b;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        tg = "tg".equals(getIntent().getStringExtra("mode"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF6F55F5);
        bar.setPadding(dp(4), dp(4), dp(4), dp(4));

        Button back = mk("←");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (web.canGoBack()) web.goBack();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setTextColor(Color.WHITE);
        urlBox.setHintTextColor(0xAAFFFFFF);
        urlBox.setHint("Search ya address likho");
        urlBox.setTextSize(15);
        urlBox.setBackgroundColor(0x33FFFFFF);
        urlBox.setPadding(dp(10), 0, dp(10), 0);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                load(urlBox.getText().toString());
                return true;
            }
        });
        if (tg) {
            TextView title = new TextView(this);
            title.setText("Private");
            title.setTextColor(Color.WHITE);
            title.setTextSize(16);
            bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        } else {
            bar.addView(urlBox, new LinearLayout.LayoutParams(0, dp(40), 1f));
        }

        Button close = mk("✕");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(close, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));
        root.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        String ua = s.getUserAgentString();
        if (ua != null) s.setUserAgentString(ua.replace("; wv", "").replace("Version/4.0 ", ""));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                return !(u.startsWith("http://") || u.startsWith("https://"));
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                if (!tg && u != null) urlBox.setText(u);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handlePerm(req);
                    }
                });
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest req) {
                if (req == pendReq) {
                    pendReq = null;
                    if (perDlg != null && perDlg.isShowing()) perDlg.dismiss();
                }
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                if (p != null && p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                inChild = true;
                try {
                    startActivityForResult(Intent.createChooser(i, "File chuno"), RQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    inChild = false;
                    return false;
                }
                return true;
            }
        });

        if (state == null) web.loadUrl(tg ? "https://web.telegram.org/k/" : "https://duckduckgo.com/");
        else web.restoreState(state);
        if (tg) h.postDelayed(poll, 5000);
    }

    private void safeDeny(PermissionRequest r) {
        try {
            r.deny();
        } catch (Exception e) {
            // request pehle hi khatam ho chuki
        }
    }

    private void handlePerm(PermissionRequest req) {
        if (!tg || web == null) {
            safeDeny(req);
            return;
        }
        String host = req.getOrigin() != null ? req.getOrigin().getHost() : null;
        if (!"web.telegram.org".equals(host)) {
            safeDeny(req);
            return;
        }
        boolean wantCam = false, wantMic = false;
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantCam = true;
            else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wantMic = true;
        }
        if (!wantCam && !wantMic) {
            safeDeny(req);
            return;
        }
        if (pendReq != null && pendReq != req) safeDeny(pendReq);
        if (perDlg != null && perDlg.isShowing()) perDlg.dismiss();
        pendReq = req;
        boolean askCam = wantCam && camState == 0;
        boolean askMic = wantMic && micState == 0;
        if (!askCam && !askMic) {
            finishPerm(req, wantCam, wantMic);
            return;
        }
        showAsk(req, wantCam, wantMic, askCam, askMic);
    }

    private void showAsk(final PermissionRequest req, final boolean wantCam, final boolean wantMic,
                         final boolean askCam, final boolean askMic) {
        String what = (wantCam && wantMic) ? "camera aur mic" : (wantCam ? "camera" : "mic");
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Telegram ko ijazat chahiye");
        b.setMessage("Telegram " + what + " use karna chahta hai. Ye ijazat sirf is Private session ke liye hai, band karte hi khatam.");
        final boolean both = askCam && askMic;
        String yes = both ? "Camera + Mic" : (askCam ? "Camera allow" : "Mic allow");
        b.setPositiveButton(yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                if (askCam) camState = 1;
                if (askMic) micState = 1;
                finishPerm(req, wantCam, wantMic);
            }
        });
        if (both) {
            b.setNeutralButton("Sirf camera", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    camState = 1;
                    micState = -1;
                    finishPerm(req, wantCam, wantMic);
                }
            });
        }
        b.setNegativeButton("Mana karo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                safeDeny(req);
                if (pendReq == req) pendReq = null;
            }
        });
        b.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface d) {
                safeDeny(req);
                if (pendReq == req) pendReq = null;
            }
        });
        perDlg = b.create();
        perDlg.show();
    }

    private void finishPerm(PermissionRequest req, boolean wantCam, boolean wantMic) {
        boolean useCam = wantCam && camState == 1;
        boolean useMic = wantMic && micState == 1;
        if (!useCam && !useMic) {
            safeDeny(req);
            if (pendReq == req) pendReq = null;
            return;
        }
        java.util.ArrayList<String> need = new java.util.ArrayList<String>();
        if (useCam && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA);
        }
        if (useMic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (!need.isEmpty()) {
            pendCam = useCam;
            pendMic = useMic;
            inChild = true;
            requestPermissions(need.toArray(new String[0]), RQ_PERM);
            return;
        }
        grantNow(req, useCam, useMic);
    }

    private void grantNow(PermissionRequest req, boolean cam, boolean mic) {
        java.util.ArrayList<String> g = new java.util.ArrayList<String>();
        if (cam) g.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE);
        if (mic) g.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE);
        try {
            req.grant(g.toArray(new String[0]));
        } catch (Exception e) {
            // request pehle hi khatam ho chuki
        }
        if (pendReq == req) pendReq = null;
    }

    @Override
    public void onRequestPermissionsResult(int rq, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rq, perms, res);
        if (rq != RQ_PERM) return;
        inChild = false;
        PermissionRequest req = pendReq;
        if (req == null) return;
        boolean camOk = pendCam && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean micOk = pendMic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (!camOk && !micOk) {
            safeDeny(req);
            pendReq = null;
            Toast.makeText(this, "Android Settings me app ko Camera/Mic permission do", Toast.LENGTH_LONG).show();
            return;
        }
        grantNow(req, camOk, micOk);
    }

    private void load(String q) {
        q = q == null ? "" : q.trim();
        if (q.length() == 0) return;
        String u;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) u = q;
        else if (q.contains(" ") || !q.contains(".")) u = "https://duckduckgo.com/?q=" + Uri.encode(q);
        else u = "https://" + q;
        web.loadUrl(u);
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (web != null) {
                web.evaluateJavascript("document.title", new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        check(v);
                    }
                });
            }
            h.postDelayed(this, 4000);
        }
    };

    private void check(String t) {
        if (t == null) return;
        int n = 0;
        Matcher m = Pattern.compile("\\((\\d+)\\)").matcher(t);
        if (m.find()) {
            try {
                n = Integer.parseInt(m.group(1));
            } catch (Exception e) {
                n = 0;
            }
        }
        if (n > lastUnread) alert();
        lastUnread = n;
    }

    private void alert() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CH, "Private", NotificationManager.IMPORTANCE_DEFAULT));
            }
            Intent i = new Intent(this, PrivateActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            PendingIntent pi = PendingIntent.getActivity(this, 5, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification nf = new Notification.Builder(this, CH)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("Study Tracker")
                    .setContentText("Naya update")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(9001, nf);
        } catch (Exception e) {
            // notification nahi ban paya, koi baat nahi
        }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq == RQ_FILE) {
            inChild = false;
            if (fileCb != null) {
                Uri[] r = null;
                if (rs == RESULT_OK && d != null) {
                    if (d.getClipData() != null) {
                        int n = d.getClipData().getItemCount();
                        r = new Uri[n];
                        for (int k = 0; k < n; k++) r[k] = d.getClipData().getItemAt(k).getUri();
                    } else if (d.getData() != null) {
                        r = new Uri[]{d.getData()};
                    }
                }
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!inChild && !isChangingConfigurations()) {
            try {
                if (web != null) web.loadUrl("about:blank");
            } catch (Exception e) {
                // koi baat nahi
            }
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else finish();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacks(poll);
        if (perDlg != null && perDlg.isShowing()) perDlg.dismiss();
        if (pendReq != null) {
            safeDeny(pendReq);
            pendReq = null;
        }
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
