package com.mysa.studytracker;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

/** Saves reminders sent from the web page and schedules real Android alarms for them. */
final class Reminders {
    static final String CHANNEL = "study_alarm_v1";
    private static final String PREF = "reminders";
    private static final String KEY_JSON = "json";
    private static final String KEY_CODES = "codes";

    private Reminders() {}

    static void save(Context c, String json) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_JSON, json).apply();
    }

    static String load(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_JSON, "[]");
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Study alarm", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Padhai ke reminder");
        Uri sound = alarmSound();
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        ch.setSound(sound, aa);
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 600, 300, 600, 300, 600});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    static Uri alarmSound() {
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        return u;
    }

    private static int codeFor(String id, int day) {
        return ((id.hashCode() & 0x3FFFFFF) * 8) + day;
    }

    private static PendingIntent pendingFor(Context c, String id, String label, String t, int day, int flags) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("com.mysa.studytracker.ALARM");
        i.putExtra("id", id);
        i.putExtra("label", label);
        i.putExtra("t", t);
        i.putExtra("d", day);
        return PendingIntent.getBroadcast(c, codeFor(id, day), i, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    static void cancelAll(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> codes = sp.getStringSet(KEY_CODES, new HashSet<String>());
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        for (String s : codes) {
            try {
                String[] p = s.split("\\|", 4);
                // p[0]=id p[1]=day p[2]=label p[3]=t
                PendingIntent pi = pendingFor(c, p[0], p[2], p[3], Integer.parseInt(p[1]), PendingIntent.FLAG_NO_CREATE);
                if (pi != null) {
                    am.cancel(pi);
                    pi.cancel();
                }
            } catch (Exception ignored) {
            }
        }
        sp.edit().remove(KEY_CODES).apply();
    }

    /** Cancels everything and schedules the next occurrence of every enabled reminder. */
    static synchronized void scheduleAll(Context c) {
        cancelAll(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Set<String> codes = new HashSet<String>();
        try {
            JSONArray arr = new JSONArray(load(c));
            for (int k = 0; k < arr.length(); k++) {
                JSONObject r = arr.getJSONObject(k);
                if (!r.optBoolean("on", true)) continue;
                String id = r.optString("id", "r" + k);
                String label = r.optString("label", "Padhai ka time");
                String t = r.optString("t", "06:00");
                JSONArray days = r.optJSONArray("days");
                if (days == null) continue;
                for (int j = 0; j < days.length(); j++) {
                    int day = days.getInt(j);
                    long when = nextTime(t, day);
                    schedule(c, am, id, label, t, day, when);
                    codes.add(id + "|" + day + "|" + label + "|" + t);
                }
            }
        } catch (Exception ignored) {
        }
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putStringSet(KEY_CODES, codes).apply();
    }

    /** day uses the web page numbering: 0 = Sunday ... 6 = Saturday. */
    static long nextTime(String t, int day) {
        String[] p = t.split(":");
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0]));
        cal.set(Calendar.MINUTE, Integer.parseInt(p[1]));
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.DAY_OF_WEEK, day + 1);
        if (cal.getTimeInMillis() <= System.currentTimeMillis() + 1500) {
            cal.add(Calendar.WEEK_OF_YEAR, 1);
        }
        return cal.getTimeInMillis();
    }

    private static void schedule(Context c, AlarmManager am, String id, String label, String t, int day, long when) {
        PendingIntent pi = pendingFor(c, id, label, t, day, PendingIntent.FLAG_UPDATE_CURRENT);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        try {
            if (exact) {
                PendingIntent show = PendingIntent.getActivity(c, 0,
                        new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, show), pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }
}
