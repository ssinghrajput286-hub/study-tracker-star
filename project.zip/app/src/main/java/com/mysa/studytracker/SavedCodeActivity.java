package com.mysa.studytracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** CS > Saved Code. Tap a program to open it in the Code-Playground. */
public class SavedCodeActivity extends Activity {

    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.load(this);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(Ui.header(this, "Saved Code", "CS › Saved Code"));

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 24));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        list.removeAllViews();
        JSONArray items = CodeStore.list(this);
        if (items.length() == 0) {
            TextView empty = Ui.text(this,
                    "Nothing saved yet.\nOpen Code-Playground and tap Save.", 15, Ui.MUTED, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(Ui.dp(this, 16), Ui.dp(this, 48), Ui.dp(this, 16), 0);
            list.addView(empty);
            return;
        }
        SimpleDateFormat fmt = new SimpleDateFormat("d MMM, HH:mm", Locale.getDefault());
        for (int i = 0; i < items.length(); i++) {
            final JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            final String id = o.optString("id");

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Ui.clay(this, Ui.SURFACE, 20));
            card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 11));

            card.addView(Ui.text(this, o.optString("name"), 18, Ui.TEXT, true));
            TextView meta = Ui.text(this, CodeStore.langName(o.optString("lang")) + "  ·  "
                    + fmt.format(new Date(o.optLong("time"))), 12, Ui.MUTED, false);
            meta.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 8));
            card.addView(meta);

            TextView preview = Ui.text(this, o.optString("code"), 13, Ui.TEXT, false);
            preview.setTypeface(Typeface.MONOSPACE);
            preview.setMaxLines(3);
            preview.setEllipsize(TextUtils.TruncateAt.END);
            preview.setBackground(Ui.inset(this, 12));
            preview.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
            card.addView(preview);

            TextView del = Ui.text(this, "Delete", 13, Ui.MUTED, false);
            del.setGravity(Gravity.CENTER_VERTICAL);
            del.setMinHeight(Ui.dp(this, 44));
            del.setPadding(0, Ui.dp(this, 4), Ui.dp(this, 24), Ui.dp(this, 4));
            Ui.press(del);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ui.haptic(v);
                    CodeStore.delete(SavedCodeActivity.this, id);
                    render();
                }
            });
            card.addView(del);

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent in = new Intent(SavedCodeActivity.this, PlaygroundActivity.class);
                    in.putExtra("lang", o.optString("lang"));
                    in.putExtra("code", o.optString("code"));
                    in.putExtra("name", o.optString("name"));
                    startActivity(in);
                }
            });
            Ui.press(card);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(this, 12);
            Ui.enter(card, i);
            list.addView(card, lp);
        }
    }
}
