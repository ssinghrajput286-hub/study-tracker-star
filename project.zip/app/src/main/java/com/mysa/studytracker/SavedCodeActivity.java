package com.mysa.studytracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** CS > Saved Code. Tap a program to open it in the Code-Playground. */
public class SavedCodeActivity extends Activity {

    private LinearLayout list;
    private LinearLayout chipRow;
    private LinearLayout folderActions;
    /** null = "Sab" (every saved program). */
    private String curFolder = null;
    private String query = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.load(this);
        getWindow().setStatusBarColor(Ui.BAR);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(Ui.header(this, "Saved Code", "CS › Saved Code"));

        EditText search = new EditText(this);
        search.setHint("Search (naam ya code)");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setBackground(Ui.inset(this, 14));
        search.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        search.setMinHeight(Ui.dp(this, 44));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) { }

            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.getDefault());
                renderList();
            }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.setMargins(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 4));
        root.addView(search, slp);

        HorizontalScrollView chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 4));
        chipScroll.addView(chipRow);
        root.addView(chipScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        folderActions = new LinearLayout(this);
        folderActions.setOrientation(LinearLayout.HORIZONTAL);
        folderActions.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
        root.addView(folderActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 24));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        // A folder that no longer exists (deleted, renamed) falls back to "Sab".
        if (curFolder != null && indexOfFolder(curFolder) < 0) curFolder = null;
        renderChips();
        renderList();
    }

    private int indexOfFolder(String name) {
        JSONArray f = CodeStore.folders(this);
        for (int i = 0; i < f.length(); i++) {
            if (name.equalsIgnoreCase(f.optString(i))) return i;
        }
        return -1;
    }

    private TextView pill(String label, boolean on, View.OnClickListener l) {
        TextView t = Ui.chip(this, label, on ? Ui.BAR : Ui.SURFACE_2, on ? 0xFFFFFFFF : Ui.TEXT);
        t.setMinHeight(Ui.dp(this, 44));
        t.setGravity(Gravity.CENTER);
        t.setOnClickListener(l);
        Ui.press(t);
        return t;
    }

    private void addPill(LinearLayout row, TextView t) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Ui.dp(this, 8);
        row.addView(t, lp);
    }

    private void renderChips() {
        chipRow.removeAllViews();
        addPill(chipRow, pill("Sab", curFolder == null, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                curFolder = null;
                render();
            }
        }));
        JSONArray fs = CodeStore.folders(this);
        for (int i = 0; i < fs.length(); i++) {
            final String name = fs.optString(i);
            addPill(chipRow, pill("\uD83D\uDCC1 " + name, name.equalsIgnoreCase(curFolder),
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            curFolder = name;
                            render();
                        }
                    }));
        }
        addPill(chipRow, pill("\uFF0B Naya folder", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askName("Naya folder", "", new NameCb() {
                    @Override
                    public void got(String n) {
                        if (CodeStore.addFolder(SavedCodeActivity.this, n)) {
                            curFolder = n;
                            render();
                        } else {
                            toast("Ye naam nahi chalega (khali, \"Sab\" ya pehle se hai)");
                        }
                    }
                });
            }
        }));

        folderActions.removeAllViews();
        if (curFolder != null) {
            final String cur = curFolder;
            TextView ren = Ui.text(this, "Rename", 14, Ui.TEXT, true);
            ren.setMinHeight(Ui.dp(this, 44));
            ren.setGravity(Gravity.CENTER_VERTICAL);
            ren.setPadding(0, 0, Ui.dp(this, 24), 0);
            Ui.press(ren);
            ren.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    askName("Folder ka naya naam", cur, new NameCb() {
                        @Override
                        public void got(String n) {
                            if (CodeStore.renameFolder(SavedCodeActivity.this, cur, n)) {
                                curFolder = n.trim();
                                render();
                            } else {
                                toast("Ye naam nahi chalega (khali, \"Sab\" ya pehle se hai)");
                            }
                        }
                    });
                }
            });
            TextView del = Ui.text(this, "Folder delete", 14, Ui.ERR, true);
            del.setMinHeight(Ui.dp(this, 44));
            del.setGravity(Gravity.CENTER_VERTICAL);
            Ui.press(del);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(SavedCodeActivity.this)
                            .setTitle("Folder \"" + cur + "\" delete karna hai?")
                            .setMessage("Sirf folder hatega. Andar ka code delete nahi hoga, wo \"Sab\" me rahega.")
                            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int w) {
                                    CodeStore.deleteFolder(SavedCodeActivity.this, cur);
                                    curFolder = null;
                                    render();
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                }
            });
            folderActions.addView(ren);
            folderActions.addView(del);
        }
    }

    private interface NameCb {
        void got(String name);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private void askName(String title, String initial, final NameCb cb) {
        final EditText in = new EditText(this);
        in.setSingleLine(true);
        in.setText(initial);
        in.setSelection(initial.length());
        FrameLayout box = new FrameLayout(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0);
        box.addView(in, lp);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        cb.got(in.getText().toString());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Lets the user pick a folder for one program. */
    private void askMove(final String id) {
        JSONArray fs = CodeStore.folders(this);
        final String[] names = new String[fs.length()];
        final String[] labels = new String[fs.length() + 2];
        labels[0] = "(Koi folder nahi)";
        for (int i = 0; i < fs.length(); i++) {
            names[i] = fs.optString(i);
            labels[i + 1] = "\uD83D\uDCC1 " + names[i];
        }
        labels[labels.length - 1] = "\uFF0B Naya folder\u2026";
        new AlertDialog.Builder(this)
                .setTitle("Folder me daalo")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            CodeStore.move(SavedCodeActivity.this, id, "");
                            render();
                        } else if (which == labels.length - 1) {
                            askName("Naya folder", "", new NameCb() {
                                @Override
                                public void got(String n) {
                                    String t = n.trim();
                                    if (t.length() == 0 || t.equalsIgnoreCase("Sab")) {
                                        toast("Ye naam nahi chalega");
                                        return;
                                    }
                                    int k = indexOfFolder(t);
                                    CodeStore.move(SavedCodeActivity.this, id,
                                            k >= 0 ? CodeStore.folders(SavedCodeActivity.this).optString(k) : t);
                                    render();
                                }
                            });
                        } else {
                            CodeStore.move(SavedCodeActivity.this, id, names[which - 1]);
                            render();
                        }
                    }
                })
                .show();
    }

    private void renderList() {
        list.removeAllViews();
        JSONArray all = CodeStore.list(this);
        JSONArray items = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o == null) continue;
            if (curFolder != null && !curFolder.equalsIgnoreCase(o.optString("folder"))) continue;
            if (query.length() > 0
                    && !o.optString("name").toLowerCase(Locale.getDefault()).contains(query)
                    && !o.optString("code").toLowerCase(Locale.getDefault()).contains(query)) continue;
            items.put(o);
        }
        if (items.length() == 0) {
            String msg;
            if (all.length() == 0) {
                msg = "Nothing saved yet.\nOpen Code-Playground and tap Save.";
            } else if (query.length() > 0) {
                msg = "Is search se kuch nahi mila.";
            } else {
                msg = "Is folder me abhi kuch nahi hai.\nCode ke card par \"Move\" dabao.";
            }
            TextView empty = Ui.text(this, msg, 15, Ui.MUTED, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(Ui.dp(this, 16), Ui.dp(this, 48), Ui.dp(this, 16), 0);
            list.addView(empty);
            return;
        }
        SimpleDateFormat fmt = new SimpleDateFormat("d MMM, HH:mm", Locale.getDefault());
        for (int i = 0; i < items.length(); i++) {
            final JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            final String id = o.optString("id");

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Ui.clay(this, Ui.SURFACE, 20));
            card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 11));

            card.addView(Ui.text(this, o.optString("name"), 18, Ui.TEXT, true));
            String fol = o.optString("folder");
            TextView meta = Ui.text(this, CodeStore.langName(o.optString("lang")) + "  ·  "
                    + fmt.format(new Date(o.optLong("time")))
                    + (fol.length() > 0 ? "  ·  \uD83D\uDCC1 " + fol : ""), 12, Ui.MUTED, false);
            meta.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 8));
            card.addView(meta);

            TextView preview = Ui.text(this, o.optString("code"), 13, Ui.TEXT, false);
            preview.setTypeface(Typeface.MONOSPACE);
            preview.setMaxLines(3);
            preview.setEllipsize(TextUtils.TruncateAt.END);
            preview.setBackground(Ui.inset(this, 12));
            preview.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
            card.addView(preview);

            TextView del = Ui.text(this, "Delete", 13, Ui.MUTED, false);
            del.setGravity(Gravity.CENTER_VERTICAL);
            del.setMinHeight(Ui.dp(this, 44));
            del.setPadding(0, Ui.dp(this, 4), Ui.dp(this, 24), Ui.dp(this, 4));
            Ui.press(del);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ui.haptic(v);
                    CodeStore.delete(SavedCodeActivity.this, id);
                    render();
                }
            });
            TextView mv = Ui.text(this, "Move", 13, Ui.TEXT, true);
            mv.setGravity(Gravity.CENTER_VERTICAL);
            mv.setMinHeight(Ui.dp(this, 44));
            mv.setPadding(0, Ui.dp(this, 4), Ui.dp(this, 24), Ui.dp(this, 4));
            Ui.press(mv);
            mv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ui.haptic(v);
                    askMove(id);
                }
            });
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.addView(mv);
            actions.addView(del);
            card.addView(actions);

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent in = new Intent(SavedCodeActivity.this, PlaygroundActivity.class);
                    in.putExtra("lang", o.optString("lang"));
                    in.putExtra("code", o.optString("code"));
                    in.putExtra("name", o.optString("name"));
                    startActivity(in);
                }
            });
            Ui.press(card);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(this, 12);
            Ui.enter(card, i);
            list.addView(card, lp);
        }
    }
}
