package com.mysa.studytracker;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

/** 3D-style on/off switch: inset track, glossy thumb, accent glow when on. */
public class Toggle3D extends View {

    /** Called when the user (or setChecked with notify) changes the state. */
    public interface OnCheckedChangeListener {
        void onCheckedChanged(Toggle3D t, boolean checked);
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private boolean checked;
    private float progress;          // 0 = off, 1 = on
    private ValueAnimator anim;
    private OnCheckedChangeListener listener;

    private final float trackW;
    private final float trackH;
    private final float thumbD;
    private final int minSize;

    public Toggle3D(Context c) {
        super(c);
        trackW = Ui.dp(c, 52);
        trackH = Ui.dp(c, 30);
        thumbD = Ui.dp(c, 26);
        minSize = Ui.dp(c, 48);
        setClickable(true);
        setFocusable(true);
        super.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ui.haptic(Toggle3D.this);
                setChecked(!checked, true);
            }
        });
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean value) {
        setChecked(value, false);
    }

    private void setChecked(boolean value, boolean fromUser) {
        if (value == checked) return;
        checked = value;
        float target = checked ? 1f : 0f;
        if (anim != null) anim.cancel();
        if (isAttachedToWindow() && Ui.animOn(getContext())) {
            anim = ValueAnimator.ofFloat(progress, target);
            anim.setDuration(200);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    progress = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        } else {
            progress = target;
            invalidate();
        }
        if (fromUser && listener != null) listener.onCheckedChanged(this, checked);
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener l) {
        listener = l;
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = Math.max(minSize, Math.round(trackW) + getPaddingLeft() + getPaddingRight());
        int h = Math.max(minSize, Math.round(trackH) + getPaddingTop() + getPaddingBottom());
        setMeasuredDimension(resolveSize(w, widthSpec), resolveSize(h, heightSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float left = cx - trackW / 2f;
        float top = cy - trackH / 2f;
        float r = trackH / 2f;

        // inset track
        rect.set(left, top, left + trackW, top + trackH);
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(blend(0xFF0A0B0E, Ui.BAR, progress * 0.55f));
        canvas.drawRoundRect(rect, r, r, paint);
        // inner top shade (inset feel)
        paint.setShader(new LinearGradient(0, top, 0, top + trackH,
                0x66000000, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, r, r, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(getContext(), 1));
        paint.setColor(0x1AFFFFFF);
        canvas.drawRoundRect(rect, r, r, paint);
        paint.setStyle(Paint.Style.FILL);

        // thumb position
        float pad = (trackH - thumbD) / 2f;
        float minX = left + pad + thumbD / 2f;
        float maxX = left + trackW - pad - thumbD / 2f;
        float tx = minX + (maxX - minX) * progress;
        float tr = thumbD / 2f;

        // soft glow when on (concentric translucent circles, no blur)
        if (progress > 0.01f) {
            int base = Ui.BAR2 & 0x00FFFFFF;
            for (int i = 3; i >= 1; i--) {
                int alpha = Math.round(26 * progress);
                paint.setColor((alpha << 24) | base);
                canvas.drawCircle(tx, cy, tr + i * Ui.dp(getContext(), 3), paint);
            }
        }

        // thumb shadow
        paint.setColor(0x55000000);
        canvas.drawCircle(tx, cy + Ui.dp(getContext(), 2), tr, paint);

        // thumb body with vertical gradient
        int topC = blend(0xFFFFFFFF, Ui.BAR2, progress * 0.35f);
        int botC = blend(0xFFB9BEC9, Ui.BAR, progress * 0.45f);
        paint.setShader(new LinearGradient(0, cy - tr, 0, cy + tr, topC, botC, Shader.TileMode.CLAMP));
        canvas.drawCircle(tx, cy, tr, paint);
        paint.setShader(null);
    }

    private static int blend(int from, int to, float t) {
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        int a = Math.round(Color.alpha(from) + (Color.alpha(to) - Color.alpha(from)) * t);
        int r = Math.round(Color.red(from) + (Color.red(to) - Color.red(from)) * t);
        int g = Math.round(Color.green(from) + (Color.green(to) - Color.green(from)) * t);
        int b = Math.round(Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t);
        return Color.argb(a, r, g, b);
    }

    @Override
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        info.setClassName("android.widget.Switch");
        info.setCheckable(true);
        info.setChecked(checked);
    }
}
