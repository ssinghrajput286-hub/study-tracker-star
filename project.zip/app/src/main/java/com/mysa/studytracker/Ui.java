package com.mysa.studytracker;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared colors and small view helpers for the CS screens. */
final class Ui {
    static final int BAR = 0xFF6F55F5;      // same purple as the Study Tracker header
    static final int BAR2 = 0xFF9D6CFF;
    static final int BG = 0xFF14161A;
    static final int SURFACE = 0xFF1E2127;
    static final int SURFACE_2 = 0xFF272B33;
    static final int LINE = 0xFF343944;
    static final int TEXT = 0xFFE9EBEF;
    static final int MUTED = 0xFF9AA1AD;
    static final int GREEN = 0xFF4CCB6A;
    static final int ERR = 0xFFFF7B72;
    static final int WARN = 0xFFFFD27F;

    private Ui() { }

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rounded(Context c, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable card(Context c, int color, int radiusDp) {
        GradientDrawable d = rounded(c, color, radiusDp);
        d.setStroke(dp(c, 1), LINE);
        return d;
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** A small rounded button-like label, used in toolbars. */
    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = text(c, s, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(rounded(c, bg, 20));
        t.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        return t;
    }

    /**
     * Purple gradient header with a back arrow, a title, a small subtitle
     * and any number of views on the right. The subtitle view has the tag "sub".
     */
    static LinearLayout header(final Activity a, String title, String subtitle, View... right) {
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{BAR, BAR2});
        bar.setBackground(g);
        bar.setPadding(dp(a, 4), dp(a, 6), dp(a, 8), dp(a, 6));

        TextView back = text(a, "←", 26, Color.WHITE, false);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.finish();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(a, 52), dp(a, 56)));

        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text(a, title, 22, Color.WHITE, true));
        TextView sub = text(a, subtitle, 12, 0xD9FFFFFF, false);
        sub.setTag("sub");
        titles.addView(sub);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        for (View v : right) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = dp(a, 6);
            bar.addView(v, lp);
        }
        return bar;
    }
}
