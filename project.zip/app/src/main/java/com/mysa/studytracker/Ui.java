package com.mysa.studytracker;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.provider.Settings;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared colors and small view helpers for the CS screens. */
final class Ui {
    static int BAR = 0xFF6F55F5;      // accent primary (same purple as the Study Tracker header)
    static int BAR2 = 0xFF9D6CFF;     // accent secondary
    static int BG = 0xFF14161A;
    static int SURFACE = 0xFF1E2127;
    static int SURFACE_2 = 0xFF272B33;
    static int LINE = 0xFF343944;
    static int TEXT = 0xFFE9EBEF;
    static int MUTED = 0xFF9AA1AD;
    static int GREEN = 0xFF4CCB6A;
    static int ERR = 0xFFFF7B72;
    static int WARN = 0xFFFFD27F;

    // Subject colors (MASTER.md)
    static final int SUBJ_PY = 0xFF3B82F6;
    static final int SUBJ_C = 0xFF1FA67A;
    static final int SUBJ_JAVA = 0xFFE0832B;
    static final int SUBJ_WEB = 0xFFDB2777;
    static final int SUBJ_SQL = 0xFF8B5CF6;

    static final String PREFS = "ui_prefs";

    /** Reads theme and accent from SharedPreferences "ui_prefs" and updates the color constants. */
    static void load(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String theme = p.getString("theme", "dark");
            String accent = p.getString("accent", "violet");
            if ("amoled".equals(theme)) {
                BG = 0xFF000000;
                SURFACE = 0xFF0B0C0F;
                SURFACE_2 = 0xFF15171C;
                LINE = 0xFF23262D;
            } else {
                BG = 0xFF14161A;
                SURFACE = 0xFF1E2127;
                SURFACE_2 = 0xFF272B33;
                LINE = 0xFF343944;
            }
            if ("blue".equals(accent)) {
                BAR = 0xFF2563EB; BAR2 = 0xFF7AA7FF;
            } else if ("green".equals(accent)) {
                BAR = 0xFF047857; BAR2 = 0xFF34D399;
            } else if ("orange".equals(accent)) {
                BAR = 0xFFC2410C; BAR2 = 0xFFFB923C;
            } else if ("pink".equals(accent)) {
                BAR = 0xFFDB2777; BAR2 = 0xFFFF6FAE;
            } else {
                BAR = 0xFF6F55F5; BAR2 = 0xFF9D6CFF;
            }
        } catch (Exception ignored) {
            // keep current values
        }
    }

    /** Accent color for a given name (used by the settings color picker). */
    static int accentColor(String name) {
        if ("blue".equals(name)) return 0xFF2563EB;
        if ("green".equals(name)) return 0xFF047857;
        if ("orange".equals(name)) return 0xFFC2410C;
        if ("pink".equals(name)) return 0xFFDB2777;
        return 0xFF6F55F5;
    }

    private static boolean prefBool(Context c, String key) {
        try {
            return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(key, true);
        } catch (Exception e) {
            return true;
        }
    }

    /** True when motion is allowed (system animator scale not 0 and "Animations" pref not off). */
    static boolean animOn(Context c) {
        try {
            float scale = Settings.Global.getFloat(c.getContentResolver(),
                    Settings.Global.ANIMATOR_DURATION_SCALE, 1f);
            if (scale == 0f) return false;
        } catch (Exception ignored) {
            // assume on
        }
        return prefBool(c, "anim");
    }

    private static int shade(int color, float f) {
        int a = Color.alpha(color);
        int r = Math.min(255, Math.max(0, Math.round(Color.red(color) * f)));
        int g = Math.min(255, Math.max(0, Math.round(Color.green(color) * f)));
        int b = Math.min(255, Math.max(0, Math.round(Color.blue(color) * f)));
        return Color.argb(a, r, g, b);
    }

    private static int lighten(int color, float amount) {
        int a = Color.alpha(color);
        int r = Math.round(Color.red(color) + (255 - Color.red(color)) * amount);
        int g = Math.round(Color.green(color) + (255 - Color.green(color)) * amount);
        int b = Math.round(Color.blue(color) + (255 - Color.blue(color)) * amount);
        return Color.argb(a, r, g, b);
    }

    /** Clay: darker soft bottom layer + rounded fill with top light + faint light stroke. */
    static Drawable clay(Context c, int color, int radiusDp) {
        GradientDrawable shadow = new GradientDrawable();
        shadow.setColor(shade(color, 0.55f));
        shadow.setCornerRadius(dp(c, radiusDp));

        GradientDrawable main = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{lighten(color, 0.07f), color});
        main.setCornerRadius(dp(c, radiusDp));
        main.setStroke(dp(c, 1), 0x1AFFFFFF);

        LayerDrawable ld = new LayerDrawable(new Drawable[]{shadow, main});
        ld.setLayerInset(1, 0, 0, 0, dp(c, 3));
        return ld;
    }

    /** Glass: translucent surface + light stroke. No real blur on native. */
    static GradientDrawable glass(Context c, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor((SURFACE & 0x00FFFFFF) | 0xA0000000);
        d.setCornerRadius(dp(c, radiusDp));
        d.setStroke(dp(c, 1), 0x1AFFFFFF);
        return d;
    }

    /** Neumorphic-like inset: darker fill with a thin stroke. */
    static GradientDrawable inset(Context c, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(shade(BG, 0.8f));
        d.setCornerRadius(dp(c, radiusDp));
        d.setStroke(dp(c, 1), LINE);
        return d;
    }

    /** Squish on press. Never consumes the touch, so click listeners still fire. */
    static void press(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (!animOn(view.getContext())) return false;
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(120).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                }
                return false;
            }
        });
    }

    /** Fade + slide-up entrance, staggered by index (30ms, capped at 8). */
    static void enter(View v, int index) {
        if (!animOn(v.getContext())) return;
        int i = Math.min(Math.max(index, 0), 8);
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 10));
        v.animate().alpha(1f).translationY(0f).setDuration(220).setStartDelay(30L * i).start();
    }

    /** Light haptic tick unless the user turned haptics off. */
    static void haptic(View v) {
        if (!prefBool(v.getContext(), "haptics")) return;
        try {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        } catch (Exception ignored) {
            // ignore
        }
    }

    private Ui() { }

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rounded(Context c, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable card(Context c, int color, int radiusDp) {
        GradientDrawable d = rounded(c, color, radiusDp);
        d.setStroke(dp(c, 1), LINE);
        return d;
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** A small rounded button-like label, used in toolbars. */
    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = text(c, s, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(rounded(c, bg, 20));
        t.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        return t;
    }

    /**
     * Purple gradient header with a back arrow, a title, a small subtitle
     * and any number of views on the right. The subtitle view has the tag "sub".
     */
    static LinearLayout header(final Activity a, String title, String subtitle, View... right) {
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{(BAR & 0x00FFFFFF) | 0xF2000000, (BAR2 & 0x00FFFFFF) | 0xF2000000});
        float rr = dp(a, 22);
        g.setCornerRadii(new float[]{0f, 0f, 0f, 0f, rr, rr, rr, rr});
        bar.setBackground(g);
        bar.setPadding(dp(a, 4), dp(a, 6), dp(a, 8), dp(a, 10));

        TextView back = text(a, "←", 26, Color.WHITE, false);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.finish();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(a, 52), dp(a, 56)));

        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text(a, title, 22, Color.WHITE, true));
        TextView sub = text(a, subtitle, 12, 0xD9FFFFFF, false);
        sub.setTag("sub");
        titles.addView(sub);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        for (View v : right) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = dp(a, 6);
            bar.addView(v, lp);
        }
        return bar;
    }
}
