import io
import sys
import traceback


def run(code, stdin_text=""):
    """Run the user's Python code and return everything it printed.

    stdin_text is what input() will read, one line per call.
    Errors come back as a normal Python traceback, like in a real terminal.
    """
    buffer = io.StringIO()
    old_out, old_err, old_in = sys.stdout, sys.stderr, sys.stdin
    sys.stdout = sys.stderr = buffer
    sys.stdin = io.StringIO(stdin_text)
    try:
        exec(compile(code, "<playground>", "exec"), {"__name__": "__main__"})
    except BaseException:
        traceback.print_exc()
    finally:
        sys.stdout, sys.stderr, sys.stdin = old_out, old_err, old_in
    return buffer.getvalue()
