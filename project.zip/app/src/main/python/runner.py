import ctypes
import io
import sys
import threading
import traceback

MAX_OUTPUT = 100000


class _Capture(io.StringIO):
    """Collects what the program prints, and stops runaway output."""

    def __init__(self):
        super().__init__()
        self.size = 0
        self.over = False

    def write(self, text):
        if self.over:
            return len(text)
        self.size += len(text)
        if self.size > MAX_OUTPUT:
            self.over = True
            raise RuntimeError("Output is too long (over %d characters). Stopped." % MAX_OUTPUT)
        return super().write(text)


def run(code, stdin_text="", timeout=10):
    """Run the user's Python code and return everything it printed.

    stdin_text is what input() will read, one line per call.
    Errors come back as a normal Python traceback, like in a real terminal.
    Code that runs longer than `timeout` seconds is stopped.
    """
    buffer = _Capture()
    old_out, old_err, old_in = sys.stdout, sys.stderr, sys.stdin
    sys.stdout = sys.stderr = buffer
    sys.stdin = io.StringIO(stdin_text)

    finished = threading.Event()
    thread_id = threading.get_ident()

    def stop():
        if not finished.is_set():
            ctypes.pythonapi.PyThreadState_SetAsyncExc(
                ctypes.c_ulong(thread_id), ctypes.py_object(TimeoutError))

    timer = threading.Timer(timeout, stop)
    timer.daemon = True
    timer.start()
    timed_out = False
    try:
        exec(compile(code, "<playground>", "exec"), {"__name__": "__main__"})
    except TimeoutError:
        timed_out = True
    except BaseException:
        traceback.print_exc()
    finally:
        finished.set()
        timer.cancel()
        sys.stdout, sys.stderr, sys.stdin = old_out, old_err, old_in

    text = buffer.getvalue()
    if buffer.over:
        text += "\n[Output was cut because it was too long]\n"
    if timed_out:
        text += "\nTimeoutError: the code ran for more than %d seconds and was stopped.\n" % timeout
    return text
