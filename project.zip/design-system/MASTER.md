# Study Tracker Design System (MASTER)

Ek hi design system poore app ke liye: Learn (WebView, CSS) aur native screens (Java, `Ui.java`) dono isi ko follow karte hain.
3 layer: Primitive (raw value) -> Semantic (kaam ke naam) -> Component (button, tile...).

## Style ka role (har style ki apni jagah, random mix nahi)
| Style | Kahan lagta hai | Kyun |
|---|---|---|
| Glass (translucent + halka blur) | Top bar, bottom nav, sidebar/drawer, sheets | Sirf chhoti "chrome" jagah, taaki lag na aaye |
| Clay (soft, phoola hua, layered shadow) | Tiles, cards, primary buttons | Mulayam, tactile, boring feel hatata hai |
| Neumorphic (soft inset) | Search box, input, progress track, toggle track | Dhansa hua feel, sirf non-text jagah par (contrast safe) |
| Skeuomorphic | Keycaps (shortcuts), logic-gate switch/lamp, code "paper" header | Jahan asli cheez ka matlab hai |
| Maximalist | Sirf Home hero card aur celebration (confetti) | Ek jagah bhaari, baaki jagah saaf padhne layak |

## Primitive tokens
Theme (dark default):
- bg `#14161A` | surface `#1E2127` | surface2 `#272B33` | line `#343944` | text `#E9EBEF` | muted `#9AA1AD`
AMOLED: bg `#000000` | surface `#0B0C0F` | surface2 `#15171C` | line `#23262D`
Light (Learn only): bg `#F4F1FA` | surface `#FFFFFF` | surface2 `#ECE8F6` | line `#DCD6EA` | text `#262233` | muted `#5E586E`
Status: ok `#4CCB6A` | err `#FF7B72` | warn `#FFD27F`

Accent (user chunta hai, `accent` key). Primary rang white text ke saath 4.5:1 contrast rakhta hai:
| name | primary | primary2 |
|---|---|---|
| violet (default) | `#6F55F5` | `#9D6CFF` |
| blue | `#2563EB` | `#7AA7FF` |
| green | `#047857` | `#34D399` |
| orange | `#C2410C` | `#FB923C` |
| pink | `#DB2777` | `#FF6FAE` |

Subject colors: Python `#3B82F6`, C `#1FA67A`, Java `#E0832B`, Web `#DB2777`, SQL `#8B5CF6`

Radius: pill 999 | tile 22 | card 20 | button 16 | input 16 | sheet 28
Spacing (dp/px): 4, 8, 12, 16, 20, 24
Touch target: minimum 44 (zyada tar 48)

## Semantic tokens
`--bg --sf --sf2 --ln --tx --mu --pr --pr2 --ok --er --wn` (Learn CSS variables)
`Ui.BG Ui.SURFACE Ui.SURFACE_2 Ui.LINE Ui.TEXT Ui.MUTED Ui.BAR Ui.BAR2` (native; `BAR`=primary, `BAR2`=primary2)

## Component tokens
- Clay tile/card: outer shadow `0 10px 24px rgba(0,0,0,.35)`, top highlight `inset 0 2px 0 rgba(255,255,255,.07)`, bottom shade `inset 0 -5px 10px rgba(0,0,0,.22)`
- Glass bar: `rgba(surface, .62)` + 1px border `rgba(255,255,255,.10)` + `backdrop-filter: blur(14px) saturate(140%)`; blur off ho to solid surface
- Neumorphic inset: `inset 3px 3px 7px rgba(0,0,0,.45), inset -2px -2px 6px rgba(255,255,255,.04)`
- Pill pagination: active pill width 22 height 8, baaki 8x8 dots, accent gradient
- 3D toggle: track 52x30 inset, thumb 26 circle with gradient + shadow, ON = accent glow
- Press: scale `.96`, 120ms; haptic light (agar user ne on rakha ho)

## Motion tokens
fast 120ms | base 220ms | slow 360ms | ease `cubic-bezier(.2,.8,.2,1)`
Screen enter: fade + 10px translateY. Tile list: stagger 30ms (max 8 items).
`prefers-reduced-motion` ya Settings me "Animations off" ho to sab motion band (sirf color change).
Animate sirf `transform` aur `opacity` (layout nahi).

## Performance rules (smoothness ke liye)
1. `backdrop-filter` sirf top bar, bottom nav, drawer par. Poore page par kabhi nahi.
2. Settings me "Glass blur" toggle: off karne par solid surface.
3. Shadow layers 3 se zyada nahi.
4. Data scripts first paint ke BAAD load hon (splash dikhta rahe).
5. Native: koi bada blur nahi (translucent only), animations `ViewPropertyAnimator` se.

## Accessibility
- Text contrast >= 4.5:1 (neumorphism sirf bina text wali jagah par)
- Focus ring visible, buttons ka aria-label
- Touch target >= 44
- Reduced motion respect

## Persistence contract (Learn <-> native)
Learn Bridge `AndroidLearn.setTheme(theme, accent)` -> SharedPreferences `ui_prefs`: `theme` ("dark" | "amoled" | "light"), `accent` ("violet" | "blue" | "green" | "orange" | "pink").
Native `Ui.load(Context)` yehi padhta hai. Native "light" ko dark maanta hai (native screens abhi dark-only hain).
